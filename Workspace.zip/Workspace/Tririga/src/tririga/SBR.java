package tririga;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;




public class SBR {

	
	public static WebDriver driver;
	
	ExtentReports extent;
	static ExtentTest test;
	private static final String BASE_URL = "https://shell-test.tririga.com/";
	
	
	
	
	@Test
	public void testAdd() throws InterruptedException, IOException {
		
		//Opening Browser
		  System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver.exe");
	      driver = new ChromeDriver();
	      driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		  driver.manage().deleteAllCookies();
	      driver.manage().window().maximize();
	      extent=new ExtentReports("C:\\Automation\\Reports\\TestResults.html",true);
	      test=extent.startTest("SBR");
	      test.log(LogStatus.INFO, "SBR Test Started.");
		  driver.navigate().to(BASE_URL);
		  test.log(LogStatus.INFO, "URL Entered.");
		  Thread.sleep(2000);
	      
	      login();
	      testSBRReportSimpulationPositive();
	      logout();
	      extent.endTest(test);
	      extent.flush();
	   }
	
	
	
	public static void login() throws InterruptedException, IOException {
		Thread.sleep(2000);
		driver.switchTo().frame(0);
		Thread.sleep(3000);
		driver.switchTo().frame("loginMain");
		Thread.sleep(3000);
		ReadFromExcel readdata= new ReadFromExcel();
		String UserName=readdata.GetData("C:\\Automation\\IO Sheet\\input.xlsx", "Sheet1", 1, 0);
		String Password=readdata.GetData("C:\\Automation\\IO Sheet\\input.xlsx", "Sheet1", 1, 1);
		driver.findElement(By.xpath("//input[@id='USERNAME']")).sendKeys(UserName);
		test.log(LogStatus.INFO, "Username Entered.");
		driver.findElement(By.xpath("//input[@id='PASSWORD']")).sendKeys(Password);
		test.log(LogStatus.INFO, "Password Entered.");
		driver.findElement(By.xpath("//*[@id='loginSubmit']/input")).click();
		test.log(LogStatus.INFO, "Clicked on Submit.");
		Thread.sleep(10000);
	}


	public static void logout() throws InterruptedException {
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='auto-sign-out-button']")).click();
		test.log(LogStatus.INFO, "Clicked on Logout.");
		Thread.sleep(2000);
		driver.quit();
	}
	
	
	public void testSBRReportSimpulationPositive() throws InterruptedException {
		driver.findElement(By.xpath(".//a[@role='menuitem' and contains(.,'My Report')]")).click();
		test.log(LogStatus.INFO, "Clicked on My Report.");
		Thread.sleep(10000);
		driver.switchTo().frame(3);
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//a[contains(.,'Community')]")).click();
		test.log(LogStatus.INFO, "Clicked on Community.");
		Thread.sleep(2000);
		WebElement element = driver
				.findElement(By.xpath("//form/table[2]/tbody/tr/td/div[4]/table/thead/tr[2]/td[3]/input"));
		element.sendKeys("SBR Simulation Report");
		System.out
				.println(driver.findElement(By.xpath("//form/table[2]/tbody/tr/td/div[2]/table/tbody/tr/td[1]/a[1]")));
		driver.findElement(By.xpath("//form/table[2]/tbody/tr/td/div[2]/table/tbody/tr/td[1]/a[2]/span")).click();
		Thread.sleep(10000);
		test.log(LogStatus.INFO, "Checking for Entered Result.");
		Integer rowCount = driver.findElements(By.xpath("//form/table[2]/tbody/tr/td/div[4]/table/thead/tr")).size();
		Assert.assertEquals(Integer.valueOf(3), rowCount);
		test.log(LogStatus.PASS, "Result Verified.");

	}
	
	
}
	

