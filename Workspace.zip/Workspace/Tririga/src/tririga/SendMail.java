package tririga;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;    
import javax.mail.internet.*;

import org.junit.Test;

public class SendMail {
	@Test
	//public static void send(String from,String password,String to,String sub,String msg){ 
	public  void send(){
        //Get properties object    
        Properties props = new Properties();    
        props.put("mail.smtp.host", "smtp.gmail.com");    
        props.put("mail.smtp.socketFactory.port", "465");    
        props.put("mail.smtp.socketFactory.class",    
                  "javax.net.ssl.SSLSocketFactory");    
        props.put("mail.smtp.auth", "true");    
        props.put("mail.smtp.port", "587");    
        //get Session   
        Session session = Session.getDefaultInstance(props,    
         new javax.mail.Authenticator() {    
         protected PasswordAuthentication getPasswordAuthentication() {    
         return new PasswordAuthentication("vishwajeetagrahari@gmail.com","Vishu1293$");  
         }    
        });    
        //compose message    
        try {    
         MimeMessage message = new MimeMessage(session);    
         message.addRecipient(Message.RecipientType.TO,new InternetAddress("raos.vudatha@gmail.com"));    
         message.setSubject("Tririga Automation");    
         //message.setText("Checking Mail through Automation."); 
         
         
         //Attachment
         BodyPart messagebodypart = new MimeBodyPart();
         messagebodypart.setText("Checking Mail through Automation.");
         
         Multipart multipart=new MimeMultipart();
         multipart.addBodyPart(messagebodypart);
         
         messagebodypart = new MimeBodyPart();
         String foldername="C:\\Automation\\Reports\\";
         File filefolder=new File(foldername);
         File[] list=filefolder.listFiles();
         String filename=list[0].getAbsolutePath();
         DataSource source=new FileDataSource(filename);
         
         messagebodypart.setDataHandler(new DataHandler(source));
         messagebodypart.setFileName(filename);
         
         
         multipart.addBodyPart(messagebodypart);
         message.setContent(multipart);
         //send message  
         
         
         
         
         
         
         
         Transport.send(message);    
         System.out.println("message sent successfully");    
        } catch (MessagingException e) {throw new RuntimeException(e);}    
           
  }  
}  
 

