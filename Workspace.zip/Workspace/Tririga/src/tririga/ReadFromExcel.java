package tririga;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFromExcel {
	
	String filein="C:\\Automation\\IO Sheet\\input.xlsx";
	String fileout="C:\\Automation\\IO Sheet\\output.xlsx";
	
	
	public String GetData(String file,String Sheetname,int row,int collumn) throws IOException{
		File ReadFile=new File(filein);
		FileInputStream fis=new FileInputStream(ReadFile);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet(Sheetname);
		String data=sheet.getRow(row).getCell(collumn).getStringCellValue();
		wb.close();
		return data;
	}
	
	public void writedata(String file,String sheetname,int collumn,String data) throws IOException{
		
		File writeFile=new File(file);
		FileInputStream fis=new FileInputStream(writeFile);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet(sheetname);
		int rowcount=sheet.getLastRowNum();
		Row row=sheet.createRow(rowcount+1);
		Cell cell=row.createCell(collumn);
		cell.setCellValue(data);
		FileOutputStream fileout= new FileOutputStream(file);
		wb.write(fileout);
		fileout.flush();
		fileout.close();
		
	}

}
