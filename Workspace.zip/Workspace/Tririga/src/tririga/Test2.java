package tririga;
import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;
public class Test2 {
	
	
	@Test
	public void test2() throws IOException{
		System.out.println("In Test2");
		ReadFromExcel readdata= new ReadFromExcel();
		
		String data=readdata.GetData("C:\\Automation\\IO Sheet\\input.xlsx", "Sheet1", 0, 0);
		System.out.println(data);
		readdata.writedata("C:\\Automation\\IO Sheet\\output.xlsx", "Sheet1", 0, "Name2");
	}
}
