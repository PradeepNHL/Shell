package Lease;
import org.junit.Test;
import Test.TestClass;
public class FIDocNumberTest 
{
//login via xl user name and password
		@Test
		public void GetfidocNumber() throws Exception 
  {
		String sDirPath = System.getProperty("user.dir");
		String dataFilePath  = sDirPath + "/TestData/uat4_dat.xlsx";
		System.out.println(dataFilePath);
		dataFilePath = dataFilePath.toLowerCase();
		TestClass.GetFiDocNumber("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");	
  }	
		
}
