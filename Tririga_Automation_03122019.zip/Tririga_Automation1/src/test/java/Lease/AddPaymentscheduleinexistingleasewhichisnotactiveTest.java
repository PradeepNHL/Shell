package Lease;
import java.io.File;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Test.TestClass;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import Test.TestClass;
public class AddPaymentscheduleinexistingleasewhichisnotactiveTest 
{
  @Test
	 public void AddPaymentscheduleinleasewhichisnotactive() throws Exception 
	 {
		    String sDirPath = System.getProperty("user.dir");
			String dataFilePath  = sDirPath + "/TestData/uat4_dat.xlsx";
			System.out.println(dataFilePath);
	    //  dataFilePath = GenericLib.sFSTTestDataFilePath; 
			dataFilePath = dataFilePath.toLowerCase();
		//	ExcelDataConfig excel= new ExcelDataConfig("C:\\POI\\TestData\\TestData.xlsx");
			TestClass.addpaymentscheduleinlease("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");    // Till now working fine			
	 }
  @AfterClass
	 public static void logout() throws Exception 
	  {
		  TestClass.LogoutTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_01"); 
	  }
}
