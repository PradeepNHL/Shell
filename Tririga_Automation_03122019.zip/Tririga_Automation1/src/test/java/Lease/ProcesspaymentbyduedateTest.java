package Lease;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Test.TestClass;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import Test.TestClass;

public class ProcesspaymentbyduedateTest {
	//login via xl user name and password
		@Test
		public void ProcesspaymentByduedate() throws Exception 
		{
		String sDirPath = System.getProperty("user.dir");
		String dataFilePath  = sDirPath + "/TestData/uat4_dat.xlsx";
		System.out.println(dataFilePath);
		dataFilePath = dataFilePath.toLowerCase();
		
		TestClass.ProcessPaymentbyduedate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_05");
		
		}
}
