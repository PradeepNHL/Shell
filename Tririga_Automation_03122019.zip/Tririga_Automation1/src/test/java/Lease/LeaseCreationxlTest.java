package Lease;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Test.TestClass;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class LeaseCreationxlTest  
{
//	public LeaseCreationxl(WebDriver driver) {
//		super(driver);
//		// TODO Auto-generated constructor stub
//	}	
	@Test
	 public void Test3LeaseCreationxl() throws Exception 
	{
		 String sDirPath = System.getProperty("user.dir");
			String dataFilePath  = sDirPath + "/TestData/uat4_dat.xlsx";
			System.out.println(dataFilePath);
			//dataFilePath = GenericLib.sFSTTestDataFilePath; 
			dataFilePath = dataFilePath.toLowerCase();
		//	ExcelDataConfig excel= new ExcelDataConfig("C:\\POI\\TestData\\TestData.xlsx");
			TestClass.LeaseCreation("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");  // Till now working fine	
		
			//All Lease Contracts
			
//			TestClass test = new TestClass(driver);
//			WebDriverWait wait = new WebDriverWait(driver,90);
//	        WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
//		    lease.click();				
		}
}
