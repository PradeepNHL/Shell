package Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import org.junit.Assert;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;



public class TestClass
{
	
 public TestClass(WebDriver driver)
	{
		this.driver = driver;		
	}
	static public String sDirPath = System.getProperty("user.dir");
	//System.out.println(sDirPath);
	public static String sUAT4TestDataFilePath =  "/testdata/uat4/uat4_data.xlsx";	
	
	File File =new File("G:\\Sumeru\\uat4_data.xlsx");
	//boolean FlagAccountVisible=false;
	public final static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private static final boolean True = false;
	public boolean Login_tririga(WebDriver d,String UserName,String Password)
	{
		try
		 {
			 Thread.sleep(50000);
			 int size = d.findElements(By.tagName("iframe")).size();
		     d.switchTo().frame(0);
		     d.switchTo().frame("loginMain");
			 d.findElement(By.xpath("//*[@id='USERNAME']")).sendKeys(UserName);		
			 d.findElement(By.name("PASSWORD")).sendKeys(Password);
			 d.findElement(By.id("loginSubmit")).click();
			 return true;
		 }
			 catch(Exception ex)
			 {
				  System.out.println(ex.getMessage());
				  return false;
			 }
	}	
		 public boolean VerifyLoginSuccessfull(WebDriver d)
    {
		   try
			{
				 //String title=d.findElement(By.xpath("//a[@class='gb_b gb_hb gb_R']")).getAttribute("title");
				 String title=d.getTitle();
				 System.out.println(title);
				 if(title.contains("TRIRIGA"))
				 {
					  System.out.println("Test is Passed,User got logged in successfully");
					  return true;
				 }		 
				 else	 
				 {
					 System.out.println("Test is failed,user not got logged in successfully");
					 return false;
				 }	 
			 }
			 catch(Exception ex)
			 {
				 System.out.println(ex.getMessage());
				 return false;
			 }	   
	}	  
		 // New code 
		 static public String dataFilePath = System.getProperty("user.dir");
		 //static String dataFilePath;
			//private static  WebDriver driver;
		   static  WebDriver driver;
		    WebElement element;
		    static String USERNAME = "USERNAME";
			static String PASSWORD = "PASSWORD";
			static String TEST_CASE_NO = "TEST_CASE_NO";
			static String CONTRACTNAME ="CONTRACTNAME";
		    static String LEASETYPE = "LEASETYPE";
		    static String SECONDARYLEASETYPE ="SECONDARYLEASETYPE";  
		    static String  CONTRACTSTATUS ="CONTRACTSTATUS";
		    static String COMMENCEMENTDATE ="COMMENCEMENTDATE";
		    static String LEASEEXPIRATIONDATE="LEASEEXPIRATIONDATE";
		    static String BUSINESSUNIT ="BUSINESSUNIT";
		    //process payment
		    static String PROCESSPAYMENTNAME="PROCESSPAYMENTNAME";
		    static String LEASEID="LEASEID";
		    //Issued processpayment
		    static String ISSUEDPROCESSPAYMENTNAME="ISSUEDPROCESSPAYMENTNAME";
		    //process payment by due date
		     static String DUEDATE ="DUEDATE";
		     //Process payment by payment type
		     static String PAYMENTTYPE="PAYMENTTYPE";
		     //type process payment id
		     static String PROCESSID="PROCESSID";
		    //DCH USR
		    static String DCHUSER ="DCHUSER"; 
		    //PA user
		    static String PA="PA";
		    //PA validate
		    static String PAVALIDATE="PAVALIDATE";
		    //PM
		    static String PROPERTYMANAGER="PROPERTYMANAGER";
		    //tenant
		    static String TENANTORGANISATION="TENANTORGANISATION";
		    //landlord
		    static String LANDLORDORGANISATION="LANDLORDORGANISATION";
		    //Remit TO
		    static String REMITTO ="REMITTO";
		    //postingdate
		    static String POSTINGDATE="POSTINGDATE";
		    //documnet date
		    static String DOCUMENTDATE="DOCUMENTDATE";
		    //payment type
		    static String PAYMENTTYPE1="PAYMENTTYPE1";
		    //Invoice type
		    static String INVOICETYPE="INVOICETYPE";
		    //Frequency
		    static String FREQUENCY="FREQUENCY";
		    //Payment due on 
		    static String PAYMENTDUEON="PAYMENTDUEON";
		    //fullpayment start date
		    static String FULLPAYMENTSTARTDATE="FULLPAYMENTSTARTDATE";
		    //numberofschedule
		    static String NUMBEROFSCHEDULES="NUMBEROFSCHEDULES";
		    //monthsperschedules
		    static String MONTHSPERSCHEDULE="MONTHSPERSCHEDULE";
		    //AMOUNTPERBASIS
		    static String AMOUNTPERBASIS="AMOUNTPERBASIS";
		    //TAXgroup
		    static String TAXGROUP="TAXGROUP";
		    //Payment method
		    static String PAYMENTMETHOD="PAYMENTMETHOD";
		    ///Dfrafted Lease id
		    static String DRAFTEDLEASEID="DRAFTEDLEASEID";
		    //Type active active lease id
		    static String ACTIVELEASE="ACTIVELEASE";
		    
		    @FindBy(id = "USERNAME")
		   	private static WebElement eleUserNameTxtFld;

		   	public static WebElement getEleUserNameTxtFld() 
		   	{
		   		return eleUserNameTxtFld;
		   	}

		   	@FindBy(name = "PASSWORD")
		   	private static WebElement elePasswordTxtFld;

		   	public static WebElement getElePasswordTxtFld() 
		   	{
		   		return elePasswordTxtFld;
		   	}
		   	@FindBy(id = "loginSubmit")  
		   	private static WebElement eleLoginSubmitBtn;
		   	
		   	public static WebElement getEleLoginSubmitBtn() 
		   	{
				return eleLoginSubmitBtn;
			}
public static void LoginTest(String filepath, String sheetname, String testcaseID)throws Exception
		{
					//Thread.sleep(9000);
					int username = TestClass.getColumnIndex(filepath, sheetname, USERNAME);
					System.out.println("user name idex is" +username);
					int password = TestClass.getColumnIndex(filepath, sheetname, PASSWORD);
					System.out.println("password idex is" +password);
					String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			
				//////new code
		System.setProperty("webdriver.chrome.driver","C:\\Iguru\\I guru\\ChromeDriver\\ChromeDriver.exe");
		 
		             // WebDriver driver = new ChromeDriver();
				      driver = new ChromeDriver();
				      
				      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				      driver.manage().deleteAllCookies();
				      driver.manage().window().maximize();
				      driver.get("https://shell-test.tririga.com");
				      
				   //   Thread.sleep(50000); removed
						 int size = driver.findElements(By.tagName("iframe")).size();
					     driver.switchTo().frame(0);
					     driver.switchTo().frame("loginMain");
					     System.out.println(driver.getTitle());
					////closing for new code
					
					TestClass.type(driver.findElement(By.id("USERNAME")), sData[username], " USERNAME text field ", driver);     
			     	
					TestClass.type(driver.findElement(By.name("PASSWORD")), sData[password], " PASSWORD text field ", driver);
					//TestClass.clickElement(getEleLoginSubmitBtn(), driver, " Login Button");
					TestClass.clickElement(driver.findElement(By.id("loginSubmit")), driver, " Login Button");
					
					//Verification after login
					//WebElement UserAfterlogin=driver.findElement(By.xpath("//div[text(),'Rekha']"));
					WebElement UserAfterlogin=driver.findElement(By.xpath("//div[@class='gwt-Label main-page-links-text GDNOS4QBMM']")); 
					String USR= UserAfterlogin.getText();
					System.out.println(USR);
					// if(USR.contains(sData[username]))
						 if(USR.contains("Welcome"))
					 {
						  System.out.println("Test is Passed,User got logged in successfully"); 
					 }		 
					 else	 
					 {
						 System.out.println("Test is failed,user not got logged in successfully");
					 }						
		 }

//LogoutScript
public static void LogoutTest(String filepath, String sheetname, String testcaseID)throws Exception
{	
	       //Check how many wondows are open
           Set<String> allWindows=driver.getWindowHandles();
           Iterator<String> it=allWindows.iterator();
           String main=it.next();
           String sub=it.next();
     	   System.out.println(main);
           System.out.println(sub);
           driver.switchTo().window(main);
           driver.manage().window().maximize();
//	
				 //logout code 	   
				 int size = driver.findElements(By.tagName("iframe")).size();
			    // driver.switchTo().frame(0);
			     Thread.sleep(9000);
			    // driver.switchTo().frame("loginMain");
			     System.out.println(driver.getTitle());
				 waitTillPageLoad(driver, 30);
				 Thread.sleep(9000);
				 WebElement Logout = driver.findElement(By.xpath("//a[@id='auto-sign-out-button']"));
			     TestClass.clickElement(Logout, driver, "Logout button");
			     System.out.println(driver.getTitle());
 }

///code to check status for payment processed
  public static void ProcessPaymentstatus(String filepath, String sheetname, String testcaseID)throws Exception
  {
	  	// login code
		TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_04");
		//Navigating to Home page. Processing Payments
		
	    driver.switchTo().defaultContent();
	    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
	    //driver.findElement(By.xpath("//a[text()='Home']")).click();
	    Thread.sleep(3000);
	    driver.switchTo().defaultContent();
	    Thread.sleep(3000);
	    //click on process payment
	   // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
	    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
	   
		Thread.sleep(5000);
	    driver.switchTo().frame("data-auto-parent-content-frame");
	    driver.switchTo().frame("objectsFrame");
	    driver.switchTo().frame("listFrame");
	    Thread.sleep(6000);
	  /// check validation
	 // WebElement PostingName=driver.findElement(By.xpath("//div[@name='th-child'] [contains(text(),'Name')]")); 
	// WebElement typepostingname=driver.findElement(By.xpath("//input[@id='filterValue5']"));
	    
	    TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_04");
	    
	   // typepostingname.sendKeys("Test process payment automation6");
	    Thread.sleep(7000);
	    Actions act7=new Actions(driver);
	    act7.sendKeys(Keys.ENTER).build().perform();
	    Thread.sleep(6000);
	    
	    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
	    Thread.sleep(2000);
	    System.out.print(allelements.size()); 
	    Thread.sleep(9000);	     
	    for(int i=1;i<allelements.size();i++)
	    {
	    	 Thread.sleep(4000);	 
	    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
	    	 System.out.println(Status.getText());	
	    	 String  statustext= Status.getText();
	    	 if(statustext.equalsIgnoreCase("Issued"))
			 {
				  System.out.println("Test is Passed,Payment Posted and status is issued"); 
			 }		 
			 else	 
			 {
				 System.out.println("Test is failed,Payment posted and status is not");
			 }		
	    }	
  }  
public static void ProcessPaymentLeaseid(String filepath, String sheetname, String testcaseID)throws Exception
{	
	TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
	
	//Navigating to Home page. Processing Payments
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
    //driver.findElement(By.xpath("//a[text()='Home']")).click();
    Thread.sleep(3000);

    driver.switchTo().defaultContent();
    Thread.sleep(3000);
    //click on process payment
   // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
    Thread.sleep(3000);
    
    //driver.switchTo().defaultContent();
    //click on add button
    System.out.println("Creating Payment Process");
    Thread.sleep(9000);
    WebElement frm2=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm2);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(4000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "click on add");
   // driver.findElement(By.xpath("//span[text()='Add']")).click();
    Thread.sleep(4000);
    
    //find all windows list and switch on that
    Set<String> allWindows3=driver.getWindowHandles();
    Iterator<String> it3=allWindows3.iterator();
   String main=it3.next();
   String  sub=it3.next();
    
    //System.out.println(main);
    //System.out.println(sub);
    
    driver.switchTo().window(sub);                
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
   
    TestClass.TypeProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
    //driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Find_651']")), driver, "click on find");
    //driver.findElement(By.xpath("//div[@id='Find_651']")).click();
    Thread.sleep(6000);
    
    //driver.switchTo().window(sub);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("frameMain");        
    driver.switchTo().frame("contentFrame");
    
   // driver.findElement(By.xpath("//input[@id='filterValue2']")).sendKeys(ContractName);// Lease Name
    TestClass.TypeLeaseid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
   // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718"); //Lease id
    Thread.sleep(7000);
    Actions act6=new Actions(driver);
    act6.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(6000);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("frameMain");    
    driver.switchTo().frame("contentFrame");
    
    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_0']")), driver, "click on row one");
   
   // driver.findElement(By.xpath("//td[@id='row_id_0']")).click();
    Thread.sleep(6000);   
    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_1']")), driver, "click on row two");
    Thread.sleep(6000); 
   // driver.findElement(By.xpath("//td[@id='row_id_1']")).click();
    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_2']")), driver, "click on row three");
    Thread.sleep(6000); 
    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_3']")), driver, "click on row four");
    
    Thread.sleep(4000);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("frameMain");    
    driver.switchTo().frame("contentFrame");
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='OK']")), driver, "click on okay");
    
   // driver.findElement(By.xpath("//span[text()='OK']")).click();
    Thread.sleep(5000);
    
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "click on create draft");
   // driver.findElement(By.xpath("//span[text()='Create Draft']")).click();
    Thread.sleep(3000);
    System.out.println("Payment Process Draft created");
    
  ////////////// Write code to get process id///////////////////////////////////
    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
   Thread.sleep(9000);
   WebElement processid= driver.findElement(By.xpath("//span[@id='attr_seq_1094']"));
   Thread.sleep(2000);
   String Processid = processid.getText();
   
   waitTillPageLoad(driver, 30); 
   Thread.sleep(4000);
   System.out.println("Process id is" +Processid); 
    
//////////////////////////////////////////Save in XL///////////////////////////////////////////////////////////
   Thread.sleep(10000);
   TestClass.setCellData("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03","PROCESSID",Processid);
   
    Thread.sleep(5000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")), driver, "click on create draft");
   // driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")).click();  //working till here
    System.out.println("Payment issued");
    
   //driver.switchTo().defaultContent();
   // driver.switchTo().frame("contentFrame");
   // driver.switchTo().defaultContent();
    
    driver.switchTo().defaultContent();
    driver.switchTo().window(main);  // going back to main wintdow
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
    //driver.findElement(By.xpath("//a[text()='Home']")).click();
    Thread.sleep(9000);
 
    //click on process payment
   // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
    //new code added to validate payment is issued or not
   // driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
    Thread.sleep(10000);
    driver.switchTo().frame("data-auto-parent-content-frame");
    Thread.sleep(5000);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(5000);
    driver.switchTo().frame("listFrame");
    Thread.sleep(6000);
 ///check validation
 // WebElement PostingName=driver.findElement(By.xpath("//div[@name='th-child'] [contains(text(),'Name')]")); 
 // WebElement typepostingname=driver.findElement(By.xpath("//input[@id='filterValue5']"));
 // TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
    TestClass.TypeIssuedProcessid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
   // TestClass.
   // typepostingname.sendKeys("Test process payment automation6");
    Thread.sleep(7000);
    Actions act7=new Actions(driver);
    act7.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(6000);
    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
    Thread.sleep(2000);
    System.out.print(allelements.size()); 
    Thread.sleep(9000);	     
    for(int i=1;i<allelements.size();i++)
    {
    	 Thread.sleep(4000);	 
    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
    	 System.out.println(Status.getText());	
    	 String  statustext= Status.getText();
    	 if(statustext.equalsIgnoreCase("Issued"))
		 {
			  System.out.println("Test is Passed,(\"Payment Posted\");"); 
		 }		 
		 else	 
		 {
			 System.out.println("Test is failed,(\"Payment is not Posted\");");
		 }		
    }	
}  
//// process parameters by multiple parameters like due date/payment type and lease id///////////////////////
public static void ProcessPaymentbymultipleparameters(String filepath, String sheetname, String testcaseID)throws Exception
{	
	TestClass.LoginTest("C:\\Tririga\\Test_data.xlsx","Tririga","TC_01");
	//TestClass.ProcessPaymentstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");
	//Navigating to Home page. Processing Payments
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
    //driver.findElement(By.xpath("//a[text()='Home']")).click();
    Thread.sleep(3000);
    driver.switchTo().defaultContent();
    Thread.sleep(3000);
    //click on process payment
   // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
    Thread.sleep(3000);
    
    //driver.switchTo().defaultContent();
    //click on add button
    System.out.println("Creating Payment Process");
    Thread.sleep(9000);
    WebElement frm2=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm2);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(8000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "click on add");
   // driver.findElement(By.xpath("//span[text()='Add']")).click();
    Thread.sleep(4000);
    
    //find all windows list and switch on that
    Set<String> allWindows3=driver.getWindowHandles();
    Iterator<String> it3=allWindows3.iterator();
    String main=it3.next();
    String  sub=it3.next();
    //System.out.println(main);
    //System.out.println(sub);
    
    driver.switchTo().window(sub);                
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    
    //Type processpayment
    Thread.sleep(7000);
    TestClass.TypeProcessPaymentName("C:\\Tririga\\Test_data.xlsx","Tririga","TC_01");
    Thread.sleep(7000);
    //Type posting date
    TestClass.TypePostingdate("C:\\Tririga\\Test_data.xlsx","Tririga","TC_01");
    //driver.findElement(By.xpath("//input[@id='attr_seq_1255']")).sendKeys("10/08/2019");
    Thread.sleep(9000);
    //Type document date
    TestClass.TypeDocumentdate("C:\\Tririga\\Test_data.xlsx","Tririga","TC_01");
    //driver.findElement(By.xpath("//input[@id='attr_seq_1256']")).sendKeys("10/08/2019");
    //driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    
    //loop for multiple payment posting keep for loop for different set of data
    
   // String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
    FileInputStream fis = new FileInputStream("C:\\Tririga\\Test_data.xlsx");
	Workbook wb = (Workbook) WorkbookFactory.create(fis);
	Sheet sht = wb.getSheet("Tririga");
	int iRowNumb = sht.getLastRowNum();
	System.out.println("number of rows in xl " +iRowNumb);
    
   for(int K=1;K<=iRowNumb;K++)
   {   
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	Thread.sleep(10000);   
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Find_651']")), driver, "click on find");
    //driver.findElement(By.xpath("//div[@id='Find_651']")).click();
    Thread.sleep(6000);
    //driver.switchTo().window(sub);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    Thread.sleep(30000);
    driver.switchTo().frame("frameMain");        
    driver.switchTo().frame("contentFrame");
    
  //(By.xpath("//*[.='"+UserName+"']"));
// driver.findElement(By.xpath("//input[@id='filterValue2']")).sendKeys(ContractName);// Lease Name
// TestClass.TypeLeaseid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");  
    Thread.sleep(2000);
    TestClass.TypeDuedate("C:\\Tririga\\Test_data.xlsx","Tririga",sht.getRow(K).getCell(0).getStringCellValue());   // added k for loop
    Thread.sleep(1000);
    TestClass.TypeLeaseid("C:\\Tririga\\Test_data.xlsx","Tririga",sht.getRow(K).getCell(0).getStringCellValue());   //added k for loop
    Thread.sleep(1000);
    TestClass.TypePaymenttype("C:\\Tririga\\Test_data.xlsx","Tririga",sht.getRow(K).getCell(0).getStringCellValue()); // added k for loop
  
    //String data0 = sheet1.getRow(i).getCell(0).getStringCellValue();
	//System.out.println("Test data row"+i+" is "+data0);
    //File src=new File("C:\\POI\\TestData\\TestData.xlsx");
	//String path = System.getProperty("user.dir");
	//System.out.println(path);
  //  FileInputStream fis = new FileInputStream(src);
	//XSSFWorkbook wb=new XSSFWorkbook(fis);
//	XSSFSheet sheet1 =wb.getSheetAt(0);
//	String data0=sheet1.getRow(0).getCell(0).getStringCellValue();
//	System.out.println("Data from Excel is " +data0);
//	String data1=sheet1.getRow(0).getCell(1).getStringCellValue();
//	System.out.println("Data from Excel is " +data1);
//	wb.close();  
    //String data0 = sheet1.getRow(i).getCell(0).getStringCellValue();
   //TypePaymenttype
   //xpath for payment type 
   // driver.findElement(By.xpath("//input[@id='filterValue5']"))   
   // xpath for due date      // //input[@id='filterValue0' and @value='Before']
   // xpath for due date        // driver.findElement(By.xpath("//input[@id='filterValue0']"))
   // xpath for lease id 
   // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718"); //Lease id
    Thread.sleep(7000);
    Actions act6=new Actions(driver);
    act6.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(5000);
   // List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
   // System.out.println(elements.size()); 
    
  //List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//input[@name='sNo']"));
    List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
   
    System.out.println(elements.size()); 
    for(int j=0;j<elements.size();j++)
    {
    	 Thread.sleep(8000);	 
    	 WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']")).get(j);
    	 System.out.println(rowcount.getText());	
    	 String  Text= rowcount.getText();
    	 System.out.println(Text);
    	 TestClass.clickElement(rowcount, driver, "click on rows");
    	// rowcount.click();
    } 
//    Thread.sleep(5000);
//    driver.switchTo().defaultContent();
//    driver.switchTo().frame("contentFrame");
//    driver.switchTo().frame("childFrame");
//    driver.switchTo().frame("frameMain");    
//    driver.switchTo().frame("contentFrame");
//    Thread.sleep(9000); 
//    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_0']")), driver, "click on row one");
//   // driver.findElement(By.xpath("//td[@id='row_id_0']")).click();
//    Thread.sleep(6000);   
//    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_1']")), driver, "click on row two");
//    Thread.sleep(6000); 
//   // driver.findElement(By.xpath("//td[@id='row_id_1']")).click();
//    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_2']")), driver, "click on row three");
//    Thread.sleep(6000); 
//    TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_3']")), driver, "click on row four"); 
    Thread.sleep(5000);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("frameMain");    
    driver.switchTo().frame("contentFrame");
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='OK']")), driver, "click on okay");
   }  
   //closing multiple payment loop for
   // driver.findElement(By.xpath("//span[text()='OK']")).click();
    Thread.sleep(5000);  
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "click on create draft");
   // driver.findElement(By.xpath("//span[text()='Create Draft']")).click();
    Thread.sleep(3000);
    System.out.println("Payment Process Draft created");
    Thread.sleep(3000);
//////////////// To get process id===================================================////////////////////////////////////////
    Thread.sleep(50000);
    driver.switchTo().frame("contentFrame");
    WebElement processid =driver.findElement(By.xpath("//span[@id='attr_seq_1094']"));
    String PROCESSID=processid.getText();
    System.out.println(PROCESSID);
    driver.switchTo().defaultContent();
   
    Thread.sleep(10000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")), driver, "click on issue");
   // driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")).click();  //working till here
    System.out.println("Payment issued");
    
   //driver.switchTo().defaultContent();
   // driver.switchTo().frame("contentFrame");
   // driver.switchTo().defaultContent();
    
    driver.switchTo().defaultContent();
    driver.switchTo().window(main);  // going back to main wintdow
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
    //driver.findElement(By.xpath("//a[text()='Home']")).click();
    Thread.sleep(9000);
    //click on process payment
   // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
    
    //new code added to validate payment is issued or not
   // driver.switchTo().defaultContent();
    // go to process payment
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
   
    Thread.sleep(10000);
    driver.switchTo().frame("data-auto-parent-content-frame");
    Thread.sleep(5000);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(5000);
    driver.switchTo().frame("listFrame");
    Thread.sleep(6000);
    
/// check validation
// WebElement PostingName=driver.findElement(By.xpath("//div[@name='th-child'] [contains(text(),'Name')]")); 
// WebElement typepostingname=driver.findElement(By.xpath("//input[@id='filterValue5']"));
      
    //Type issuedProcessPaymnet name
   // TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\Test_data.xlsx","Tririga","TC_01");
    //Type process id
    
    driver.findElement(By.xpath("//input[@id='filterValue4']")).sendKeys(PROCESSID);
   // typepostingname.sendKeys("Test process payment automation6");
    Thread.sleep(7000);
    Actions act7=new Actions(driver);
    act7.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(6000);
    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
    Thread.sleep(2000);
    System.out.println(allelements.size()); 
    Thread.sleep(9000);	     
    for(int i=1;i<allelements.size();i++)
    {
    	 Thread.sleep(8000);	 
    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
    	 System.out.println(Status.getText());	
    	 String  statustext= Status.getText();
    	
   if(statustext.equalsIgnoreCase("Issued"))
		   {
			  System.out.println("Test is Passed,Payment Posted"); 
		   }		 
	else	 
		  {
			 System.out.println("Test is failed,Payment is not Posted");
		  }		
    }	 
}   

//process payment by payment type
    public static void ProcessPaymentbyPaymenttype(String filepath, String sheetname, String testcaseID)throws Exception
    {	
    	TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_06");
    	//TestClass.ProcessPaymentstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");
    	
    	//Navigating to Home page. Processing Payments
        driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
        //driver.findElement(By.xpath("//a[text()='Home']")).click();
        Thread.sleep(3000);
        driver.switchTo().defaultContent();
        Thread.sleep(3000);
        //click on process payment
       // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
        Thread.sleep(3000);
        
        //driver.switchTo().defaultContent();
        //click on add button
        System.out.println("Creating Payment Process");
        Thread.sleep(9000);
        WebElement frm2=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
        driver.switchTo().frame(frm2);
        driver.switchTo().frame("objectsFrame");
        Thread.sleep(4000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "click on add");
       // driver.findElement(By.xpath("//span[text()='Add']")).click();
        Thread.sleep(4000);
        
        //find all windows list and switch on that
        Set<String> allWindows3=driver.getWindowHandles();
        Iterator<String> it3=allWindows3.iterator();
       String main=it3.next();
       String  sub=it3.next();
        //System.out.println(main);
        //System.out.println(sub);
        
        driver.switchTo().window(sub);                
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
       
        TestClass.TypeProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_06");
        //driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Find_651']")), driver, "click on find");
        //driver.findElement(By.xpath("//div[@id='Find_651']")).click();
        Thread.sleep(6000);
        
        //driver.switchTo().window(sub);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");        
        driver.switchTo().frame("contentFrame");
        
     //  driver.findElement(By.xpath("//input[@id='filterValue2']")).sendKeys(ContractName);// Lease Name
    //   TestClass.TypeLeaseid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");
        
        TestClass.TypePaymenttype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_06");
        
        //TypePaymenttype
        //xpath for payment type 
       // driver.findElement(By.xpath("//input[@id='filterValue5']"))   
  //xpath for due date      // //input[@id='filterValue0' and @value='Before']
// xpath for due date        // driver.findElement(By.xpath("//input[@id='filterValue0']"))
     
       //  xpath for lease id 
       // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718"); //Lease id
        Thread.sleep(7000);
        Actions act6=new Actions(driver);
        act6.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");    
        driver.switchTo().frame("contentFrame");
        Thread.sleep(9000); 
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_0']")), driver, "click on row one");
       // driver.findElement(By.xpath("//td[@id='row_id_0']")).click();
        Thread.sleep(6000);   
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_1']")), driver, "click on row two");
        Thread.sleep(6000); 
       // driver.findElement(By.xpath("//td[@id='row_id_1']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_2']")), driver, "click on row three");
        Thread.sleep(6000); 
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_3']")), driver, "click on row four");
        
        Thread.sleep(5000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");    
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='OK']")), driver, "click on okay");
        
       // driver.findElement(By.xpath("//span[text()='OK']")).click();
        Thread.sleep(5000);
        
        driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "click on create draft");
       // driver.findElement(By.xpath("//span[text()='Create Draft']")).click();
        Thread.sleep(3000);
        System.out.println("Payment Process Draft created");
        
        driver.switchTo().defaultContent();
        
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")), driver, "click on create draft");
       // driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")).click();  //working till here
        System.out.println("Payment issued");
        
       //driver.switchTo().defaultContent();
       // driver.switchTo().frame("contentFrame");
       // driver.switchTo().defaultContent();
        
        driver.switchTo().defaultContent();
        driver.switchTo().window(main);  // going back to main wintdow
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
        //driver.findElement(By.xpath("//a[text()='Home']")).click();
        Thread.sleep(9000);
     
        //click on process payment
       // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
        
        //new code added to validate payment is issued or not
       // driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
        
        Thread.sleep(10000);
        driver.switchTo().frame("data-auto-parent-content-frame");
        Thread.sleep(5000);
        driver.switchTo().frame("objectsFrame");
        Thread.sleep(5000);
        driver.switchTo().frame("listFrame");
        Thread.sleep(6000);
    /// check validation
    // WebElement PostingName=driver.findElement(By.xpath("//div[@name='th-child'] [contains(text(),'Name')]")); 
   // WebElement typepostingname=driver.findElement(By.xpath("//input[@id='filterValue5']"));
        
        TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_06");
       // typepostingname.sendKeys("Test process payment automation6");
        Thread.sleep(7000);
        Actions act7=new Actions(driver);
        act7.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
        Thread.sleep(2000);
        System.out.println(allelements.size()); 
        Thread.sleep(9000);	     
        for(int i=1;i<allelements.size();i++)
        {
        	 Thread.sleep(8000);	 
        	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
        	 System.out.println(Status.getText());	
        	 String  statustext= Status.getText();
        	 if(statustext.equalsIgnoreCase("Issued"))
    		 {
    			  System.out.println("Test is Passed,Payment Posted"); 
    		 }		 
    		 else	 
    		 {
    			 System.out.println("Test is failed,Payment is not Posted");
    		 }		
        }	
}   
//process payment by Due date
    public static void ProcessPaymentbyduedate(String filepath, String sheetname, String testcaseID)throws Exception
    {	
    	TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_05");
    	//Navigating to Home page. Processing Payments
        driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
        //driver.findElement(By.xpath("//a[text()='Home']")).click();
        Thread.sleep(3000);

        driver.switchTo().defaultContent();
        Thread.sleep(3000);
        //click on process payment
       // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
        Thread.sleep(3000);
        
        //driver.switchTo().defaultContent();
        //click on add button
        System.out.println("Creating Payment Process");
        Thread.sleep(9000);
        WebElement frm2=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
        driver.switchTo().frame(frm2);
        driver.switchTo().frame("objectsFrame");
        Thread.sleep(4000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "click on add");
       // driver.findElement(By.xpath("//span[text()='Add']")).click();
        Thread.sleep(4000);
        
        //find all windows list and switch on that
       Set<String> allWindows3=driver.getWindowHandles();
       Iterator<String> it3=allWindows3.iterator();
       String main=it3.next();
       String  sub=it3.next();
        
        //System.out.println(main);
        //System.out.println(sub);
        
        driver.switchTo().window(sub);                
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
       
        TestClass.TypeProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_05"); // Use name in xl which nt yet used
        //driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Find_651']")), driver, "click on find");
        //driver.findElement(By.xpath("//div[@id='Find_651']")).click();
        Thread.sleep(6000);
        
        //driver.switchTo().window(sub);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");        
        driver.switchTo().frame("contentFrame");
        
     // driver.findElement(By.xpath("//input[@id='filterValue2']")).sendKeys(ContractName);// Lease Name
    //   TestClass.TypeLeaseid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_03");        
        TestClass.TypeDuedate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_05");
        
//xpath for due date //input[@id='filterValue0' and @value='Before']
// xpath for due date        // driver.findElement(By.xpath("//input[@id='filterValue0']"))
// driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718"); //Lease id
        Thread.sleep(7000);
        Actions act6=new Actions(driver);
        act6.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");    
        driver.switchTo().frame("contentFrame");
        
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_0']")), driver, "click on row one");
// driver.findElement(By.xpath("//td[@id='row_id_0']")).click();
        Thread.sleep(6000);   
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_1']")), driver, "click on row two");
        Thread.sleep(6000); 
       // driver.findElement(By.xpath("//td[@id='row_id_1']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_2']")), driver, "click on row three");
        Thread.sleep(6000); 
        TestClass.clickElement(driver.findElement(By.xpath("//td[@id='row_id_3']")), driver, "click on row four");
        
        Thread.sleep(4000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");    
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='OK']")), driver, "click on okay");
        
       // driver.findElement(By.xpath("//span[text()='OK']")).click();
        Thread.sleep(5000);
        
        driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "click on create draft");
       // driver.findElement(By.xpath("//span[text()='Create Draft']")).click();
        Thread.sleep(3000);
        System.out.println("Payment Process Draft created");
        
        driver.switchTo().defaultContent();
        
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")), driver, "click on create draft");
       // driver.findElement(By.xpath("//span[text()='Issue' and @tabindex='0']")).click();  //working till here
        System.out.println("Payment issued");
        
       //driver.switchTo().defaultContent();
       // driver.switchTo().frame("contentFrame");
       // driver.switchTo().defaultContent();
        
        driver.switchTo().defaultContent();
        driver.switchTo().window(main);  // going back to main wintdow
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
        //driver.findElement(By.xpath("//a[text()='Home']")).click();
        Thread.sleep(9000);
     
        //click on process payment
       // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
        
        //new code added to validate payment is issued or not
       // driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
        
        Thread.sleep(10000);
        driver.switchTo().frame("data-auto-parent-content-frame");
        Thread.sleep(5000);
        driver.switchTo().frame("objectsFrame");
        Thread.sleep(5000);
        driver.switchTo().frame("listFrame");
        Thread.sleep(6000);
        /// check validation
       // WebElement PostingName=driver.findElement(By.xpath("//div[@name='th-child'] [contains(text(),'Name')]")); 
    // WebElement typepostingname=driver.findElement(By.xpath("//input[@id='filterValue5']"));
        
        TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_05");
        
       // typepostingname.sendKeys("Test process payment automation6");
        Thread.sleep(7000);
        Actions act7=new Actions(driver);
        act7.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
        Thread.sleep(2000);
        System.out.println(allelements.size()); 
        Thread.sleep(9000);	     
        for(int i=1;i<allelements.size();i++)
        {
        	 Thread.sleep(4000);	 
        	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
        	 System.out.println(Status.getText());	
        	 String  statustext= Status.getText();
        	 if(statustext.equalsIgnoreCase("Issued"))
    		 {
    			  System.out.println("Test is Passed,(\"Payment Posted\");"); 
    		 }		 
    		 else	 
    		 {
    			 System.out.println("Test is failed,(\"Payment is not Posted\");");
    		 }		
        }	
}    
  public static void GetFiDocNumber(String filepath, String sheetname, String testcaseID)throws Exception
   {	
    	//TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");	
    	TestClass.ProcessPaymentstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");
    	TestClass.TypeProcessPaymnentid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");
    	//TestClass.clickElement(element, driver, elementName);
    	TestClass.clickElement(driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(3), driver, "Home page");
    	
        Thread.sleep(4000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("innerFrame663");
        Thread.sleep(4000);
   
    	
//    	//Navigating to Home page. Processing Payments
//        driver.switchTo().defaultContent();
//        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Home']")), driver, "Home page");
//        //driver.findElement(By.xpath("//a[text()='Home']")).click();
//        Thread.sleep(3000);
//        driver.switchTo().defaultContent();
//        Thread.sleep(3000);
//        //click on process payment
//       // driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")).click();
//        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='large-quick-link-4296']")), driver, "process payment");
//        Thread.sleep(5000);
//	    driver.switchTo().frame("data-auto-parent-content-frame");
//	    driver.switchTo().frame("objectsFrame");
//	    driver.switchTo().frame("listFrame");
//	    Thread.sleep(6000);
//	    
//        //driver.switchTo().defaultContent();    
//        TestClass.TypeIssuedProcessPaymentName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_07");
//        
//       // typepostingname.sendKeys("Test process payment automation6");
//        Thread.sleep(7000);
//        Actions act7=new Actions(driver);
//        act7.sendKeys(Keys.ENTER).build().perform();
//        Thread.sleep(6000);
//    	
//        List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
//        Thread.sleep(2000);
//        System.out.println(allelements.size()); 
//        Thread.sleep(9000);	     
//        for(int i=1;i<allelements.size();i++)
//       {
//        	 Thread.sleep(4000);	 
//        	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
//        	 System.out.println(Status.getText());	
//        	 String  statustext= Status.getText();
//        	 if(statustext.equalsIgnoreCase("Issued"))
//    		 {
//    			  System.out.println("Test is Passed,(\"Payment Posted\");"); 
//    		 }		 
//    		 else	 
//    		 {
//    			 System.out.println("Test is failed,(\"Payment is not Posted\");");
//    		 }		
//       }	
//       WebElement processid = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(3);
//        processid.click();
//        Thread.sleep(4000);
//        driver.switchTo().defaultContent();
//        driver.switchTo().frame("innerFrame663");
//        Thread.sleep(4000);
//        
//        WebElement elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(17);
//        elements.click();
//        
 
    }  
public static void TypeLeaseName(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000); 
			int contractname = TestClass.getColumnIndex(filepath, sheetname, CONTRACTNAME);
			System.out.println("Contract name index" +contractname);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.id("attr_seq_1163")), sData[contractname], "ContractName", driver);
}  
//Type Income Lease type
public static void TypeIncomeLeaseType(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int leasetype = TestClass.getColumnIndex(filepath, sheetname, LEASETYPE);
			System.out.println("Income Lease type index" +leasetype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//span[text()='Income Lease']")), sData[leasetype], "Lease type", driver);
}  

public static void TypeLeaseType(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int leasetype = TestClass.getColumnIndex(filepath, sheetname, LEASETYPE);
			System.out.println("Lease type index" +leasetype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1308']")), sData[leasetype], "Lease type", driver);
}   

//secondary lease type for income lease
public static void TypesecondaryleaseTypeforincomelease(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int seocndaryleasetype = TestClass.getColumnIndex(filepath, sheetname, SECONDARYLEASETYPE);
			System.out.println("Secondary lease type index" +seocndaryleasetype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			Thread.sleep(30000);
			TestClass.type(driver.findElement(By.xpath("//span[text()='Tenant Lease']")), sData[seocndaryleasetype], "SecondaryLease type", driver);
}  

public static void TypesecondaryleaseType(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(20000);
			int seocndaryleasetype = TestClass.getColumnIndex(filepath, sheetname, SECONDARYLEASETYPE);
			System.out.println("Secondary lease type index" +seocndaryleasetype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			Thread.sleep(20000);	
			TestClass.type(driver.findElement(By.xpath("//span[text()='Landlord Lease']")), sData[seocndaryleasetype], "Lease type", driver);
}  

//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
//By.xpath("//span[text()='Landlord Lease']")) ---  used before
public static void Typecontractstatus(String filepath, String sheetname, String testcaseID)throws Exception
{
		Thread.sleep(5000);
	      
			int contractstatus = TestClass.getColumnIndex(filepath, sheetname,  CONTRACTSTATUS);
			System.out.println("Contract status index" +contractstatus);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//span[text()='Active']")), sData[contractstatus], "Lease type", driver);
}  
//dates
public static void TypeCommencementDate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int commencementdate = TestClass.getColumnIndex(filepath, sheetname,  COMMENCEMENTDATE);
			System.out.println("commencement dae index is" + commencementdate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1182']")), sData[commencementdate], "Lease commencementdate", driver);
			
			// driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");			
} 

//expiry date
public static void TypeExpirationdate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int leaseexpirationdate = TestClass.getColumnIndex(filepath, sheetname,  LEASEEXPIRATIONDATE);
			System.out.println("Expiration date index is" +leaseexpirationdate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1172']")), sData[leaseexpirationdate], "Lease expiration date", driver);
			
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

////Business unit
public static void TypeBusinessunit(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(8000);
			int businessunit = TestClass.getColumnIndex(filepath, sheetname,  BUSINESSUNIT);
			System.out.println("Business unit" +businessunit);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='attr_seq_2663']")), sData[businessunit], "Business unit", driver);
			
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//Type DCH user name
public static void TypeDCHUSERNAME(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(8000);
			int dchuser = TestClass.getColumnIndex(filepath, sheetname,  DCHUSER);
			System.out.println("DCHUSR name index  is" +dchuser);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='filterValue4']")), sData[dchuser], "DCH user", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//Type PA
public static void TypePA(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(8000);
			int pa = TestClass.getColumnIndex(filepath, sheetname,  PA);
			System.out.println("PA name index  is" +pa);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='filterValue4']")), sData[pa], "DCH user", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//Type PAValidate

public static void TypePAValidate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(8000);
			int pavalidate = TestClass.getColumnIndex(filepath, sheetname,  PAVALIDATE);
			System.out.println("PA validate index  is" +pavalidate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='filterValue4']")), sData[pavalidate], "DCH user", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//Type PM

public static void TypePM(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int pm = TestClass.getColumnIndex(filepath, sheetname,  PROPERTYMANAGER);
			System.out.println("PA validate index  is" +pm);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='filterValue4']")), sData[pm], "PM", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//Type tenant organisation
public static void TypeTenant(String filepath, String sheetname, String testcaseID)throws Exception
{
	   Thread.sleep(9000);
			int tenantorganisation = TestClass.getColumnIndex(filepath, sheetname,  TENANTORGANISATION);
			System.out.println("Tanent organisation index is" +tenantorganisation);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")), sData[tenantorganisation], "Tanent", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//TypeLandlord
public static void TypeLandlord(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int landlordorganisation = TestClass.getColumnIndex(filepath, sheetname,  LANDLORDORGANISATION);
			System.out.println("Lanlord organisation index is" +landlordorganisation);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='attr_seq_1934']")), sData[landlordorganisation], "Landlord", driver);
			
} 

/// Type Remit to

public static void TypeRemitTo(String filepath, String sheetname, String testcaseID)throws Exception
{
	       waitTillPageLoad(driver, 30); 
			int remitto = TestClass.getColumnIndex(filepath, sheetname,  REMITTO);
			System.out.println("Remit to organisation index is" +remitto);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='attr_seq_1987']")), sData[remitto], "Remit to", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 


//Type created draft lease

public static void Typecreateddraftlease(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(30000);
			int draftedleaseid = TestClass.getColumnIndex(filepath, sheetname,  DRAFTEDLEASEID);
			System.out.println("drafted lease id" +draftedleaseid);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue0']")), sData[draftedleaseid], "drafted lease id", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//Type payment type

public static void Typepaymenttype(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int paymenttype = TestClass.getColumnIndex(filepath, sheetname,  PAYMENTTYPE1);
			System.out.println("Payment type " +paymenttype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1086']")), sData[paymenttype], "Payment Type", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
}           //WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']"));

//Type invoice type

public static void Typeinvoicetype(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int invoicetype = TestClass.getColumnIndex(filepath, sheetname,  INVOICETYPE);
			System.out.println("Invoice type index is" +invoicetype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1166']")), sData[invoicetype], "Payment Type", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
}       

//Type frequency  Typefrequency

public static void Typefrequency(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(10000);
			int frequency = TestClass.getColumnIndex(filepath, sheetname,  FREQUENCY);
			System.out.println("Frequency index is " +frequency);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1126']")), sData[frequency], "Payment Type", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
			//driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
}   

///PAYMENTDUEON

public static void Typepaymentdueon(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int paymentdueon = TestClass.getColumnIndex(filepath, sheetname,  PAYMENTDUEON);
			System.out.println("Payment due on index is" +paymentdueon);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]")), sData[paymentdueon], "Payment Type", driver);
			
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
			//driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
}   

//Typing number of schedules
public static void TypeNumberofschedules(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int numberofschedules = TestClass.getColumnIndex(filepath, sheetname,  NUMBEROFSCHEDULES);
			System.out.println("Payment due on index is" +numberofschedules);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1105']")), sData[numberofschedules], "Number od schedule", driver);
			
			/// driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
			//driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
}   

//Typing months per schedules
//TypeMonthsperschedules
public static void TypeMonthsperschedules(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int monthsperschedule = TestClass.getColumnIndex(filepath, sheetname,  MONTHSPERSCHEDULE);
			System.out.println("Payment due on index is" +monthsperschedule);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.id("attr_seq_1103")), sData[monthsperschedule], "months per schedules", driver);		
}   

//TypeAmount per basis
public static void TypeAmountperBasis(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int amountperbasis = TestClass.getColumnIndex(filepath, sheetname,  AMOUNTPERBASIS);
			System.out.println("Amount per basis index is" +amountperbasis);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.id("attr_seq_1100")), sData[amountperbasis], "amount is selected", driver);		
			///driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
}  
//Type full FULLPAYMENTSTARTDATE

public static void Typefullpaymentstartdate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int fullpaymentstartdate = TestClass.getColumnIndex(filepath, sheetname,  FULLPAYMENTSTARTDATE);
			System.out.println("Payment due on index is" +fullpaymentstartdate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1133']")), sData[fullpaymentstartdate], "Payment Type", driver);
			
			/// driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
			//driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
}  
//Type Tax group
public static void Typetaxgroup(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(10000);
			int taxgroup = TestClass.getColumnIndex(filepath, sheetname,  TAXGROUP);
			System.out.println("Tax group index is" +taxgroup);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='attr_seq_1150']")), sData[taxgroup], "Tax group", driver);
}  

//TYPE payment method
public static void TypePaymentMethod(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(30000);
			int paymentmethod = TestClass.getColumnIndex(filepath, sheetname,  PAYMENTMETHOD);
			System.out.println("Tax group index is" +paymentmethod);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@name='attr_seq_1256']")), sData[paymentmethod], "Tax group", driver);
			
			/// driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
			//(By.xpath("//input[@name='filterValue4']")
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
			// driver.findElement(By.xpath("//input[@id='attr_seq_1166']")).sendKeys("LANDLORD1");
			//driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
}  

//ProcessPaymentName

public static void TypeProcessPaymentName(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int processpayment = TestClass.getColumnIndex(filepath, sheetname,  PROCESSPAYMENTNAME);
			System.out.println("Process payment index name is" +processpayment);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1096']")), sData[processpayment], "parocesspayment name", driver);
			
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//Type posting date
public static void TypePostingdate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int postingdate = TestClass.getColumnIndex(filepath, sheetname,  POSTINGDATE);
			System.out.println("Posting date index is" +postingdate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1255']")), sData[postingdate], "postingdate", driver);
			
			
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
///Type active Lease id for CPI clause

public static void TypeActiveLeaseid(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(7000);
			int activeleaseid = TestClass.getColumnIndex(filepath, sheetname,  ACTIVELEASE);
			System.out.println("Posting date index is" +activeleaseid);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue0']")), sData[activeleaseid], "activeleaseid", driver);
			
			
			//driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys("10067");
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 



//Type document date

public static void TypeDocumentdate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(5000);
			int documentdate = TestClass.getColumnIndex(filepath, sheetname,  DOCUMENTDATE);
			System.out.println("Document date index is" +documentdate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='attr_seq_1256']")), sData[documentdate], "postingdate", driver);
			
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//type issued process payment name after process payment is done

public static void TypeIssuedProcessPaymentName(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int issuedprocesspayment = TestClass.getColumnIndex(filepath, sheetname,  ISSUEDPROCESSPAYMENTNAME);
			System.out.println("Issued Process payment name index is" +issuedprocesspayment);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			Thread.sleep(1000);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue5']")), sData[issuedprocesspayment], "parocesspayment name", driver);
			
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//Type Procress id to get the status

public static void TypeIssuedProcessid(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(9000);
			int processid = TestClass.getColumnIndex(filepath, sheetname,  PROCESSID);
			System.out.println("Issued Process payment name index is" +processid);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			Thread.sleep(1000);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue4']")), sData[processid], "parocesspayment name", driver);
			
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//Type due date for payment process
public static void TypeDuedate(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(50000);
			int duedate = TestClass.getColumnIndex(filepath, sheetname,  DUEDATE);
			System.out.println("Due date index is" +duedate);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue0' and @value='Before']")), sData[duedate], "due date is", driver);
			
			// driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718");
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//type payment type for payment type
public static void TypePaymenttype(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(50000);
			int paymenttype = TestClass.getColumnIndex(filepath, sheetname,  PAYMENTTYPE);
			System.out.println("Payment type index is" +paymenttype);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue5']")), sData[paymenttype], "payment type is", driver);			
			// driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718");
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 
//Type issued process payment id

public static void TypeProcessPaymnentid(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(50000);
			int processpaymentid = TestClass.getColumnIndex(filepath, sheetname,  PROCESSID);
			System.out.println("process payment id index is" +processpaymentid);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue4']")), sData[processpaymentid], "process payment id is", driver);			
			// driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718");
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//type lease id for process payment
//TypeLeaseid
public static void TypeLeaseid(String filepath, String sheetname, String testcaseID)throws Exception
{
			Thread.sleep(30000);
			int leaseid = TestClass.getColumnIndex(filepath, sheetname,  LEASEID);
			System.out.println("Lease id index is" +leaseid);
			String[] sData = TestClass.toReadExcelData(filepath, sheetname, testcaseID);
			TestClass.type(driver.findElement(By.xpath("//input[@id='filterValue1']")), sData[leaseid], "Lease id is", driver);
			
			// driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys("1006718");
			////driver.findElement(By.xpath("//input[@id='attr_seq_1096']")).sendKeys("TestProcesspayment");
			//WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));  
			//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
			//driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("12/31/2021");
} 

//SBR Lease creation with two payment schedule SBR min and SBR Advance payment




//Lease creation method with multiple payment schedule

public static void LeaseCreationwithmultiplepaymentschedule(String filepath, String sheetname, String testcaseID)throws Exception

{
	TestClass.LoginTest("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_02");
	Thread.sleep(30000); 
	//click on all contracts
	TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
	///click on add button/////////////
	Thread.sleep(20000);
	WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(30000);
    // click on add contract
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");
 
   //////find all windows list and switch on that///////////////////////////////////////////////////////////////
    Set<String> allWindows=driver.getWindowHandles();
    Iterator<String> it=allWindows.iterator();
    String main=it.next();
    String sub=it.next();
    System.out.println(main);
    System.out.println(sub);
    driver.switchTo().window(sub);
    driver.manage().window().maximize();
    driver.switchTo().frame("contentFrame");
   //Generating Random Contract Name/////////////////////////////////////////////////
   // Random ranGenerator=new Random();
   // Integer RanNumber=ranGenerator.nextInt(100);    
   //String ContractName="Lease "+RanNumber;
    TestClass.TypeLeaseName("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    TestClass.TypeLeaseType("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01"); 

    Thread.sleep(20000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");

    Thread.sleep(9000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
    //driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
   // driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
 
  //WebDriverWait wait = new WebDriverWait(driver,90);
  //WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
    Thread.sleep(30000);
    
    driver.switchTo().frame("unMovableLayerFrame");

  //type secondary lease  recheck this one more time creating issue while execution///////////////////
    TestClass.TypesecondaryleaseType("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    Thread.sleep(5000);
    Actions act = new Actions(driver);
    act.moveToElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")));
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")), driver, "secondary lease");
    Thread.sleep(5000);
   
 ////////////////////////// Type Contract status as 'Active'////////////////////////////////////////////////////
    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    Thread.sleep(2000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
   // driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
    Thread.sleep(3000);
    driver.switchTo().frame("unMovableLayerFrame");
    Thread.sleep(5000);
    TestClass.Typecontractstatus("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");
    
   // WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
    //act.moveToElement(active);
    //active.click();
    //Dates
    // Lease CommencementDate
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame"); 
    Thread.sleep(30000);
    TestClass.TypeCommencementDate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
   // driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
    
   // Lease Expiration Date
    TestClass.TypeExpirationdate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    //driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
    
    //adding Business unit////////////////////////////////////////////////////////////////////////////////////////
    Thread.sleep(2000);
    JavascriptExecutor jse=(JavascriptExecutor)driver;
    jse.executeScript("window.scrollBy(0, 500)", "");
    Thread.sleep(4000);
    TestClass.TypeBusinessunit("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    Actions act1=new Actions(driver);
    Thread.sleep(7000);
    act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
    Thread.sleep(4000);
    
  // Go to contact details page// 
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
   // driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
    Thread.sleep(2000);
    driver.switchTo().defaultContent();
        
  // click on data central hub   //////////////////////////////////////////////////////////////////////
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
   driver.switchTo().frame("innerFrame87");
   waitTillPageLoad(driver, 30);
   TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
   // driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
   String contactsWindow = driver.getWindowHandle();
   Set<String> winHandleBefore = driver.getWindowHandles();
    // Perform the click operation that opens new window
    // Switch to new window opened 
    for(String winHandle : winHandleBefore)
    {
       driver.switchTo().window(winHandle);
    }        
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    Thread.sleep(5000);
    TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 
    
   // driver.findElement(By.id("Find_3")).click();
    Thread.sleep(1000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(1000);
    driver.switchTo().frame("frameMain");
    Thread.sleep(2000);
    driver.switchTo().frame("contentFrame");
    
  //  driver.findElement(By.id("repSubList")).sendKeys("All People");
   // driver.switchTo().frame("childFrame");
    //Thread.sleep(1000);
   // driver.switchTo().frame("frameMain");
   // Thread.sleep(1000);
    //driver.switchTo().frame("contentFrame");  
    Thread.sleep(5000); 
  //New code added for selecting all roles 
  //table[@id='subRepLayerTable']//span[@class='bodyText']
    
    driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
    Thread.sleep(5000);
    
    List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
    Thread.sleep(2000);
    System.out.println(Allppl.size());  
    
    Thread.sleep(2000);
  ///// click on All people link////////////////////
    WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//  WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//  	 add.click();
//  
    Actions act2 = new Actions(driver);  
    System.out.println(clicksecondelement.getText());
    act2.moveToElement(clicksecondelement);
    Thread.sleep(10000);
    clicksecondelement.click();
    
   ///////////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////
   
    WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
    TestClass.TypeDCHUSERNAME("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    
    Thread.sleep(9000);
    Actions act3=new Actions(driver);
    act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
    Thread.sleep(2000);
  //////// act2.sendKeys(Keys.TAB).build().perform()///////////////////////////////////////////////
    Thread.sleep(2000);
    driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
    Thread.sleep(5000);
    driver.findElement(By.id("xBtn")).click();
    System.out.println("User Selected for Data Central Validate");  
    
///----------------------------------------------------------------------------------------------------------------------------------------------  
////Portfolio Administrator selection///////////////////////////////////////////////////////////////////
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(5000);
   TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
 // driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
   Set<String> winHandleBefore1 = driver.getWindowHandles();
   for(String winHandle1 : winHandleBefore1)
    {
          driver.switchTo().window(winHandle1);
    }    
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(9000);
  TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
  //driver.findElement(By.id("Find_3")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
 
  driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(5000);
 
 List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
 Thread.sleep(2000);
 System.out.println(Allppl.size());  
 
 Thread.sleep(2000);
 //click on All people link
 WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

 Actions act4 = new Actions(driver);  
 System.out.println(clicksecondelement1.getText());
 act4.moveToElement(clicksecondelement1);
 Thread.sleep(10000);
 TestClass.clickElement(clicksecondelement1, driver, "select All");
 //clicksecondelement1.click();
 
 ///////////selecting PA user  Rekha/////////////////////////////////////////////////////////////////////////////////

 WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
 TestClass.TypePA("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
 
 Thread.sleep(9000);
 Actions act5=new Actions(driver);
 act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
 Thread.sleep(3000);
  
 driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
 Thread.sleep(3000);
 driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
  Thread.sleep(7000);
 driver.findElement(By.id("xBtn")).click();
  System.out.println("User Selected for Portfolio Administrator");   
//  
///-------------------------------------------------------------------------------------------------------------------------------------
 /// //  User Selected for Portfolio Administrator  - Validate
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(7000);
  driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
  System.out.println("Clicked on Portfolio Administrator  - Validate");
  
  Set<String> winHandleBefore2 = driver.getWindowHandles();
  for(String winHandle2 : winHandleBefore2)
  {
         driver.switchTo().window(winHandle2);
      }    
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(7000);
  TestClass.clickElement( driver.findElement(By.id("Find_3")), driver, "find");
 // driver.findElement(By.id("Find_3")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(5000);
 
 List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
 Thread.sleep(2000);
 System.out.println(Allppl3.size());  
 
 Thread.sleep(2000);
 // click on All people link
 WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	 add.click();

 Actions act6 = new Actions(driver);  
 System.out.println(clicksecondelement2.getText());
 act6.moveToElement(clicksecondelement2);
 Thread.sleep(10000);
 TestClass.clickElement(clicksecondelement2, driver, "Select All");
 //clicksecondelement2.click();
 
 //////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

 WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
 TestClass.TypePAValidate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
 
 Thread.sleep(9000);
 Actions act7=new Actions(driver);
 act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
 Thread.sleep(2000);
  
 TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "select role");
 //driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
 Thread.sleep(2000);
  
 TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "selecting role");
  //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  Thread.sleep(5000);
  TestClass.clickElement( driver.findElement(By.id("xBtn")), driver, "click");
 // driver.findElement(By.id("xBtn")).click();
  System.out.println("User Selected for Portfolio Administrator  - Validate");
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Property Manager Selection 
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(9000);
  TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "click on property manager");
 // driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
  System.out.println("Clicked on Property Manager");
// 
   Set<String> winHandleBefore3 = driver.getWindowHandles();
 for(String winHandle3 : winHandleBefore3)
    {
       driver.switchTo().window(winHandle3);
    }    
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
   Thread.sleep(5000);
   TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
  // driver.findElement(By.id("Find_3")).click();
   Thread.sleep(5000);
   driver.switchTo().frame("childFrame");
   driver.switchTo().frame("frameMain");
   driver.switchTo().frame("contentFrame");
   
  TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "Click on button");
 // driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(5000);
  
  List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
  Thread.sleep(2000);
  System.out.println(Allppl4.size());  
  
  Thread.sleep(2000);
  // click on All people link
  WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
 //WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
// add.click();
  Actions act8= new Actions(driver);  
  System.out.println(clicksecondelement3.getText());
  act8.moveToElement(clicksecondelement3);
  Thread.sleep(10000);
  clicksecondelement3.click();
  WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
  TestClass.TypePM("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  
  Thread.sleep(9000);
  Actions act9=new Actions(driver);
  act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
  Thread.sleep(2000);
   
  driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
  Thread.sleep(2000);  
   
  TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "select Role");
   //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
   driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
   Thread.sleep(9000);
   TestClass.clickElement( driver.findElement(By.id("xBtn")), driver, "Click");
  // driver.findElement(By.id("xBtn")).click();
   System.out.println("Property Manager Selected");
   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tenant organization DE01 selection
   Thread.sleep(1000);
   driver.switchTo().window(contactsWindow); 
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");        
 //driver.findElement(By.id("attr_seq_1916_selector")).click(); 
   Thread.sleep(4000);
   TestClass.TypeTenant("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  // driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
   Actions act10=new Actions(driver);
   act10.sendKeys(Keys.TAB).build().perform();
  // act1.sendKeys(Keys.TAB).build().perform()
//   driver.switchTo().frame("childFrame");
//   driver.switchTo().frame("frameMain"); 
//   driver.switchTo().frame("contentFrame");
   System.out.println("Tenant Organization Selected");
   Thread.sleep(4000);  
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //  Landlord Organization Lookup selection
   jse.executeScript("window.scrollBy(0, 500)", "");
   Thread.sleep(4000);
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
  // driver.findElement(By.id("attr_seq_1934_selector")).click();
   Thread.sleep(7000);
   TestClass.TypeLandlord("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  // WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
   Thread.sleep(7000);
  // LandlordOrganisationLookup.sendKeys("68031057");
   Actions act11=new Actions(driver);
   Thread.sleep(7000);
   act11.sendKeys(Keys.TAB).build().perform();
   Thread.sleep(7000);
   act11.sendKeys(Keys.ENTER).build().perform();
   Thread.sleep(2000);
   System.out.println("Landlord Organization Selected");
   
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
   	  jse.executeScript("window.scrollBy(0, 500)", "");
      Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      //Remit to 
      driver.switchTo().defaultContent();
      driver.switchTo().frame("contentFrame");
      Thread.sleep(5000);
      //driver.findElement(By.id("attr_seq_1987_selector")).click();
      Thread.sleep(5000);
      TestClass.TypeRemitTo("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
      //WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
     // Thread.sleep(5000);
     // RemitToLookup.sendKeys("68031057");
      Thread.sleep(6000);
      Actions act12=new Actions(driver);
      Thread.sleep(7000);
      act12.sendKeys(Keys.TAB).build().perform();
 	  System.out.println("Remit Organization Selected");
   	 
///////////////////////////////Click on create draft/////////////////////////////////////////////////////////////////////////////////////////////  
 	 
 	  driver.switchTo().defaultContent();
      Thread.sleep(6000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
      System.out.println("Created draft"); 
////////--Click on location----------------------------------------------------------------------------------------------------------------
      Thread.sleep(9000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();   
///////////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
      JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
      scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
      
      driver.switchTo().frame("contentFrame");
      Thread.sleep(5000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
     // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
      Thread.sleep(5000);
      driver.switchTo().frame("childFrame");
      driver.switchTo().frame("frameMain");
      driver.switchTo().frame("contentFrame");
      driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
      driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
      ////System.out.println("Primary Location Selected");
  
      driver.switchTo().defaultContent();
      driver.switchTo().frame("contentFrame");
      Thread.sleep(5000);
      driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
      Thread.sleep(3000);
      driver.switchTo().frame("childFrame");
      Thread.sleep(1000);
      driver.switchTo().frame("frameMain");
      driver.switchTo().frame("contentFrame");
      driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
      driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
      System.out.println("Primary Location Selected");
 //// /////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
  	        Thread.sleep(6000);
  	       
  	        driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();   
 //// Adding loop for adding multiple payment schedule/////////////////////////////////////////////////////////
  	        
  	    FileInputStream fis = new FileInputStream("C:\\Tririga\\Lease_Data.xlsx");
  		Workbook wb = (Workbook) WorkbookFactory.create(fis);
  		Sheet sht1 = wb.getSheet("Tririga");
  		int iRowNumb = sht1.getLastRowNum();
  		System.out.println("number of rows in xl " +iRowNumb);
  		
  	  for(int K=1;K<=iRowNumb;K++)  		     
  	 {    
//////////Add payment schedule//////////////////////////////////////////////////////////////////////////////////////
   
  	    System.out.println("Creating a Payment Schedule");   
        driver.switchTo().defaultContent();
        Thread.sleep(10000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
        //driver.findElement(By.xpath("//span[text()='Payments']")).click();
        Thread.sleep(6000);
        driver.switchTo().frame("contentFrame");
        Thread.sleep(10000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")), driver, "Generate payment schedule");
       // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
        Thread.sleep(4000);
        driver.switchTo().frame("childFrame");
        Thread.sleep(4000);
        driver.switchTo().frame("contentFrame");
        
       // driver.findElement(By.id("attr_seq_1086_selector")).click();
        Thread.sleep(3000);
      //  driver.switchTo().frame("unMovableLayerFrame");   //removed
        Thread.sleep(20000);
       // WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']")); //added
       //WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
      
        TestClass.Typepaymenttype("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
        Thread.sleep(7000);
        Actions act13=new Actions(driver);
//        Thread.sleep(7000);
//        act13.sendKeys(Keys.TAB).build().perform();
//        Thread.sleep(7000);
        act13.sendKeys(Keys.ENTER).build().perform();
       // act.moveToElement(paymentType);
        Thread.sleep(10000);
       // paymentType.click();
        Thread.sleep(5000);
        System.out.println("Payment Type Selected");   
//////////////////////////////////////////// Invoice Type Selected /////////////////////////////////////////////////////      
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(6000);
        TestClass.Typeinvoicetype("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
        
      // driver.findElement(By.id("attr_seq_1166_selector")).click();
        Thread.sleep(5000);
        Actions act14=new Actions(driver);
        act14.sendKeys(Keys.ENTER).build().perform();
        //Removed code
//        driver.switchTo().frame("unMovableLayerFrame");
//        Thread.sleep(4000); 
//        WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//        act.moveToElement(invoiceType);
//        invoiceType.click();
          System.out.println("Invoice Type Selected"); 
////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
            driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        
	        //driver.findElement(By.id("attr_seq_1126_selector")).click();
	        Thread.sleep(3000);
	    // Removed //  driver.switchTo().frame("unMovableLayerFrame");
	        Thread.sleep(1000);
	        TestClass.Typefrequency("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
	     //   frequency.sendKeys("Monthly");
	        Actions act15=new Actions(driver);
	        act15.sendKeys(Keys.ENTER).build().perform();
	      // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
	      // act.moveToElement(frequency);
	      // frequency.click();
	        System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(5000);
	        TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
	       // driver.findElement(By.id("attr_seq_1134_selector")).click();
	       driver.switchTo().frame("unMovableLayerFrame");
	      //  driver.findElement(By.id("attr_seq_1105")).clear();
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
	        Thread.sleep(6000);
	        TestClass.Typepaymentdueon("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
	       // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
	       // paymentDueOn.sendKeys("First Day of Period");
	        Actions act16=new Actions(driver);
	        act16.sendKeys(Keys.ENTER).build().perform();
	        act.moveToElement(paymentDueOn);
	        TestClass.clickElement(paymentDueOn, driver, "payment due on");
	       // paymentDueOn.click();
	        System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
//// selecting full payment start date///////////////////////////////////////////////////////////////////////////////
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
	        Thread.sleep(6000);
	        TestClass.Typefullpaymentstartdate("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
	        System.out.println("Full Payment Start Date Selected");
////////////////////////////////////// Selecting number of Number of Schedules Entered///////////////////////////////  
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(9000);
	        driver.findElement(By.id("attr_seq_1105")).clear();
	        Thread.sleep(5000);
	        TestClass.TypeNumberofschedules("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");
	       // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
	        System.out.println("Number of Schedules Entered");
 /////////Months per schedules//////////////////////////////////////////////////////////////////////////////////////
	        driver.findElement(By.id("attr_seq_1103")).clear();
	        Thread.sleep(5000);
	        //driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
	        TestClass.TypeMonthsperschedules("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered//////////////////////////////////////////////////////////////////////////////////////////////        
	        JavascriptExecutor jse1=(JavascriptExecutor)driver;
	        jse1.executeScript("window.scrollBy(0, 500)", "");
	        Thread.sleep(5000);
	        driver.findElement(By.id("attr_seq_1100")).clear();
	        TestClass.TypeAmountperBasis("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
	        System.out.println("Amount Per Basis entered");	        
////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////
	        System.out.println("Finding Cost code");
	        driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("frameMain");
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(6000);
	       TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "cost code");
	      //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
	        driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	        System.out.println("cost code Selected");
	        
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
	        System.out.println("Adding Tax Group");
	        //JavascriptExecutor jse1=(JavascriptExecutor)driver;
	        //jse1.executeScript("window.scrollBy(0, 500)", "");
	        //Thread.sleep(4000);
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        TestClass.Typetaxgroup("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
	        Actions act17=new Actions(driver);
	        Thread.sleep(4000);
	        act17.sendKeys(Keys.TAB).build().perform();
	        Thread.sleep(4000);
	        System.out.println("Tax Group is Added");  
	        
//// Generate payment schedule///////////////////////////////////////////////////////////////////////////////// 
	        System.out.println("Generating payment Schedule");
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
	       // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
	        Thread.sleep(3000);
	        System.out.println("Payment Schedules Generated");
//Update payment instructions//////////////////////////////////////////////////////////////////////////////////////   
	      //System.out.println("Payment Instruction");
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("innerFrame7");
	        Thread.sleep(10000); 
	        TestClass.clickElement(driver.findElement(By.xpath("//a[@title='YC00']")), driver, "Generate payment schedule");
	      //  driver.findElement(By.xpath("//a[@title='YC00']")).click();
	        
	        Thread.sleep(4000);
	        System.out.println("Updating Payment Instructions");
	        driver.switchTo().defaultContent();
///////////////find all windows list and switch on that////////////////////////////////////////////////////////////
	        Set<String> allWindows1=driver.getWindowHandles();
	        Iterator<String> it1=allWindows1.iterator();
	        String main1=it1.next();
	        String sub1=it1.next();
	        String sub2=it1.next(); 
            driver.switchTo().window(sub2);        
	        driver.manage().window().maximize();
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
///////Select payment method////////////////////////////////////////////////////////////////////////////////
	       // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
	        driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
	        Actions act18=new Actions(driver);  
	        act18.sendKeys(Keys.TAB).build().perform();       
	        Thread.sleep(4000);
	        //selecting one payment type from that list/////////////////////////////
	        driver.findElement(By.xpath("//tr[@id='129243788']")).click();
	        Thread.sleep(9000);  
	        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Save_&_Close']")), driver, "Save and close");
	        //driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
	        Thread.sleep(2000);    
	        System.out.println("Payment Instructions Updated");
	        driver.switchTo().window(sub1);    
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        Thread.sleep(5000);
	        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
	       // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
	        System.out.println("Created Schedule");
	        Thread.sleep(9000);      
	        driver.switchTo().defaultContent();        
	        driver.switchTo().frame("contentFrame");
	        //driver.switchTo().frame("closeModalPageFrame");
	        Thread.sleep(9000); 
	       TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
//////////// driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
	        Thread.sleep(5000);
	        System.out.println("Window closed");	        
//////////////////////////////////////////////////////////////////////////////refresh page///////////////////////////////////// 
	        Thread.sleep(5000);      
	        driver.switchTo().defaultContent();        
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("innerFrame129");
	        Thread.sleep(3000);  
	        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
	       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
	        Thread.sleep(4000);    
	        System.out.println("Checking Payment Schedule");
  	   }     
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	         
	        /// Get lease id
	// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
       Thread.sleep(60000);
       driver.switchTo().defaultContent();
//	     driver.switchTo().frame("contentFrame");
//	    //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
//	      Thread.sleep(9000);
	      //xpath for general tab to get lease id
	    WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
	    TestClass.clickElement(Generaltab, driver, "General Tab");
	      // Generaltab.click();
	     System.out.println("entered into general tab");
////////// WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));//////////////////////
	       Thread.sleep(9000);
           driver.switchTo().frame("contentFrame");
           Thread.sleep(9000);
	       WebElement leaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
	        Thread.sleep(9000);
	        String Leaseid= leaseid.getText();
	         Thread.sleep(9000);
	         System.out.println("Lease id is " +Leaseid);   
	        
/////////////////////////////////////////submit lease/////////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='General']")), driver, "submit button");
        //driver.findElement(By.xpath("//span[text()='General']")).click();
        Thread.sleep(2000);    
        driver.switchTo().defaultContent();
        Thread.sleep(5000);
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Submit']")), driver, "Submit lease");
        //driver.findElement(By.xpath("//div[@id='Submit']")).click();
        Thread.sleep(5000);    
        System.out.println("Submit Lease Contract");      
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
//        Set<String> allWindowsN=driver.getWindowHandles();
//        Iterator<String> it1=allWindowsN.iterator();
//        String mainN=it1.next();
//        String subN=it1.next();
//        String sub2=it1.next();  
        driver.switchTo().window(main);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(2000);
        TestClass.clickElement( driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(2000);
        
        System.out.println("Activating the Contract");
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        // search by lease id not yby name correct it 
       // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys(ContractName);
        driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
        Actions act19=new Actions(driver);
        act19.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(4000);
        driver.switchTo().defaultContent();
        WebElement frm1=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
        driver.switchTo().frame(frm1);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(50000);
        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(9000);
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")), driver, "Click on draft accounting review");
       // driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")).click();
        Thread.sleep(4000);
///////// Click on activate the lease//////////////////////////////////////////////////////////////////////////
        Set<String> allWindows2=driver.getWindowHandles();
        Iterator<String> it2=allWindows2.iterator();
        String main2=it2.next();
        String sub3=it2.next();
        
        //System.out.println(main2);
        //System.out.println(sub3);
        
        driver.switchTo().window(sub3);                
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Activate']")), driver, "Activate lease");
       // driver.findElement(By.xpath("//div[@id='Activate']")).click();
        Thread.sleep(5000);
//////////////////////////////////////////////////////////////////////Validate status/////////////////////////////////   
        driver.switchTo().window(main);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(3000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
        //driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
        Thread.sleep(9000);
        driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
        Thread.sleep(7000);
        Actions act20=new Actions(driver);
        act20.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
        Thread.sleep(2000);
        System.out.println(allelements.size()); 
        Thread.sleep(5000);	     
        for(int i=0;i<allelements.size();i++)
        {
        	 Thread.sleep(2000);	 
        	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
        	 System.out.println(Status.getText());	
        	 String  statustext= Status.getText();
        	
       if(statustext.equalsIgnoreCase("Active"))
    		   {
    			  System.out.println("Test is Passed,Lease is activated"); 
    		   }		 
    	else	 
    		  {
    			 System.out.println("Test is failed,Lease is not activated");
    		  }		
        }	 
    } 
///Add CPI clause in a lease  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
public static void AddCPIExplease(String filepath, String sheetname, String testcaseID)throws Exception
{	
 TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
 Thread.sleep(20000); 
//click on all contracts
 TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");

//driver.switchTo().window(main);
 driver.switchTo().defaultContent();
 driver.switchTo().frame("data-auto-parent-content-frame");
  //driver.switchTo().frame("contentFrame");
 driver.switchTo().frame("objectsFrame");
 driver.switchTo().frame("listFrame");
 Thread.sleep(3000);
 TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
//driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
 Thread.sleep(5000);
 TestClass.TypeActiveLeaseid("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_16"); 
 ///////// Code to check/validate  only active ids is required  //////////////////////////////////////////////
 
//driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys("10067");
 Thread.sleep(4000);
 Actions act20=new Actions(driver);
 act20.sendKeys(Keys.ENTER).build().perform();
 Thread.sleep(4000);
 List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
 Thread.sleep(2000);
 System.out.println(allelements.size()); 
 Thread.sleep(1000);	     
 for(int i=0;i<allelements.size();i++)
 {
	 Thread.sleep(1000);	 
	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
	 System.out.println(Status.getText());	
	 String  statustext= Status.getText();
	
if(statustext.equalsIgnoreCase("Active"))
	   {
       // Assert.assertTrue(True);
        Assert.assertTrue(statustext.equalsIgnoreCase("Active"));  
        System.out.println("Test is Passed,Lease is activated"); 
	   }		 
else	 
	   {
	     //Assert.fail("Lease is not active " + statustext);
		 System.out.println("Test is failed,Lease is not activated");
	   }		
   }
 
 WebElement Lease =driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(1);
 
 TestClass.clickElement(Lease, driver, "click on Lease id");
 System.out.println("Clicked on Lease id");
 
 Set<String> allWindows1cpi=driver.getWindowHandles();
 System.out.println("Number of windows are"  +allWindows1cpi);
 Iterator<String> itera=allWindows1cpi.iterator();
 String mainwindow=itera.next();
 String subwindow=itera.next();
 System.out.println(mainwindow);
 System.out.println(subwindow);
 driver.switchTo().window(subwindow);
 
 /////////// code to go to option and clauses///////////////////////////////////////////////////////////////////////////
 Thread.sleep(1000);
 driver.switchTo().defaultContent();
 Thread.sleep(2000);
 WebElement Optionancluases = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
 Thread.sleep(2000);
 TestClass.clickElement(Optionancluases, driver, "option and cluases");
 System.out.println("Enter into option and clause section"); 
 
 ///////////////// To revise contract /////////////////////////////////////////////////////////////////////////////////////////////////
 
 Thread.sleep(6000);
 WebElement revisecontract = driver.findElement(By.xpath("//div[@id='Contract_Revise']//span[text()='Contract Revise']"));
 Thread.sleep(4000);
 //revisecontract.click();
 TestClass.clickElement(revisecontract, driver, "click on contract revise");
 Thread.sleep(3000);
 System.out.println("Clicked on contract revised"); 
 Thread.sleep(1000);
 driver.switchTo().frame("contentFrame");
 driver.switchTo().frame("childFrame");
 driver.switchTo().frame("contentFrame");
 
 Thread.sleep(8000);
 WebElement changetypeselector =  driver.findElement(By.xpath("//a[@id='attr_seq_1058_selector']"));
 
 TestClass.clickElement(changetypeselector, driver, "click on selector");

 Thread.sleep(1000);
 driver.switchTo().frame("unMovableLayerFrame");
 
 WebElement datarevise = driver.findElement(By.xpath("//table[@id='listValueTable']//a[@id='a_2']//span[@class='bodyText']"));
 
 TestClass.mouseOverOnElement(driver, datarevise, "datarevise"); 
 Thread.sleep(1000);
 TestClass.clickElement(datarevise, driver, "click on data revise");
 System.out.println("Clicked on data revised drop down"); 
 
 /////////////// Write code to click on continue button /////////////////////////////////////////////////////////////////////
 Thread.sleep(1000);
 driver.switchTo().defaultContent();
 driver.switchTo().frame("contentFrame");
 driver.switchTo().frame("childFrame");
 Thread.sleep(1000);
 WebElement countinue = driver.findElement(By.xpath("//div[@id='Continue']"));
 Thread.sleep(8000);
 TestClass.clickElement(countinue, driver, "countinue button");
 Thread.sleep(1000);
 System.out.println("Clicked on continue button"); 
 

 /////////////////////////////////////////////////////////////////////////////////////////////////////////
 driver.switchTo().defaultContent();
 driver.switchTo().frame("contentFrame");
 Thread.sleep(5000);
 WebElement AddButton = driver.findElement(By.xpath("//div[@id='Add_38']//span[@class='actionButtonText']"));
       
 TestClass.clickElement(AddButton, driver, "Add option and cluases");
 System.out.println("clicked on add button");
 Thread.sleep(2000);
///////////////Type name of the clause//////////////////////////////////////////////////////////////////////
 driver.switchTo().frame("childFrame");
 driver.switchTo().frame("contentFrame");
 Thread.sleep(5000);
 WebElement ClauseName = driver.findElement(By.xpath("//input[@id='attr_seq_1002']"));
 ClauseName.sendKeys("index adjustment");
        
 System.out.println("added clause name");
 Thread.sleep(2000);
 WebElement ClauseType = driver.findElement(By.xpath("//input[@id='attr_seq_1313']"));
       
 ClauseType.sendKeys("Index Adjustment");
       
 System.out.println("added clause type");
       
 Actions act22=new Actions(driver);
 act22.sendKeys(Keys.TAB).build().perform();
       
 WebElement Findpaymentschedules = driver.findElement(By.xpath("//div[@id='Find_16']//span[@class='actionButtonText']"));
       
 TestClass.clickElement(Findpaymentschedules, driver, "find clause");
 System.out.println("clicked on find button");
       
       //List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
       //System.out.println(elements.size()); 
 Thread.sleep(5000);
 driver.switchTo().defaultContent();
 driver.switchTo().frame("contentFrame");
 Thread.sleep(2000);
 driver.switchTo().frame("childFrame");
 driver.switchTo().frame("contentFrame");
 Thread.sleep(2000);
 System.out.println("inside content frame");
 driver.switchTo().frame("childFrame");
 Thread.sleep(2000);
 driver.switchTo().frame("frameMain");
 driver.switchTo().frame("contentFrame");
       
 List<WebElement>elements1 = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
 System.out.println("Size is " +elements1.size());
       for(int j=0;j<elements1.size();j++)
      {
       	 Thread.sleep(1000);	 
       	 WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']")).get(j);
       	 System.out.println(rowcount.getText());	
       	 String  Text= rowcount.getText();
       	 System.out.println(Text);
       	 Thread.sleep(2000);
       	 TestClass.clickElement(rowcount, driver, "click on rows");
      }      
    System.out.println("payment scheduled linked");
    
///////// /// ///// Click on OK button after selecting payment schedule///////////////////////////
    
    Thread.sleep(4000);   
    WebElement OK=  driver.findElement(By.xpath("//table[@id='actionsTable']//tbody//span[@class='actionButtonText' and text()='OK']"));
    TestClass.clickElement(OK, driver, "OK button");
    
    System.out.println("Clicked on ok");
    
    
///////////////////////////////////// Enter details in index adjustment clause///////////////////////////////////////////////////////////////////////   
 ///index adjustment selector
    Thread.sleep(1000);   
    driver.switchTo().defaultContent();
    Thread.sleep(1000);  
    driver.switchTo().frame("contentFrame");
    Thread.sleep(1000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(1000);
    driver.switchTo().frame("contentFrame");
    
    WebElement IndexAdjustmentselector = driver.findElement(By.xpath("//a[@id='attr_seq_1237_selector']"));
    Thread.sleep(3000); 		
    TestClass.clickElement(IndexAdjustmentselector, driver, "click on elemnet");
    
    //mouse hover on CPI index adjustmnet/////
    
    driver.switchTo().frame("unMovableLayerFrame");
    Thread.sleep(5000);  
    WebElement CPIindex = driver.findElement(By.xpath("//a//span[text()='CPI']"));
    
    TestClass.mouseOverOnElement(driver, CPIindex, "CPI index");
    Thread.sleep(1000); 
    TestClass.clickElement(CPIindex, driver, "Click on CPI index");
 
}





///SBR income lease creation  with clause//////////////////////////////////////////////////////

public static void SBRincomeleasecreation(String filepath, String sheetname, String testcaseID)throws Exception
{
TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Thread.sleep(20000); 
//click on all contracts
TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
///click on add button/////////////////////////////////////////////////////////////////////////////////////////
Thread.sleep(20000);
WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
driver.switchTo().frame(frm);
driver.switchTo().frame("objectsFrame");
Thread.sleep(20000);
// click on add contract//////////////////////////////////////////////////////////////////////////////////////
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");

//find all windows list and switch on that////////////////////////////////////////////////////////////////
Set<String> allWindows=driver.getWindowHandles();
Iterator<String> it=allWindows.iterator();
String main=it.next();
String sub=it.next();
System.out.println(main);
System.out.println(sub);
driver.switchTo().window(sub);
driver.manage().window().maximize();
driver.switchTo().frame("contentFrame");

//Generating Random Contract Name
//Random ranGenerator=new Random();
//Integer RanNumber=ranGenerator.nextInt(100);    
//String ContractName="Lease "+RanNumber;
TestClass.TypeLeaseName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_1308_selector']")), driver, "incomeLease Type");
Thread.sleep(4000);
driver.switchTo().frame("unMovableLayerFrame");
Thread.sleep(5000);
TestClass.TypeIncomeLeaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11"); 
Thread.sleep(5000);
Actions act21 = new Actions(driver);
act21.moveToElement(driver.findElement(By.xpath("//span[text()='Income Lease']")));
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Income Lease']")), driver, "income lease type");

Thread.sleep(1000);
driver.switchTo().defaultContent();
Thread.sleep(1000);
driver.switchTo().frame("contentFrame");
Thread.sleep(4000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();

//WebDriverWait wait = new WebDriverWait(driver,90);
//WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
Thread.sleep(8000);

driver.switchTo().frame("unMovableLayerFrame");

/////type secondary lease  recheck this one more time creating issue while execution////////////////////////////////
TestClass.TypesecondaryleaseTypeforincomelease("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Thread.sleep(4000);
Actions act = new Actions(driver);
act.moveToElement(driver.findElement(By.xpath("//span[text()='Tenant Lease']")));
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Tenant Lease']")), driver, "secondary lease type");
Thread.sleep(4000);
///////////////////// Type Contract status as 'Active'/////////////////////////////////////////////////////////////////////////
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
// driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
Thread.sleep(2000);
driver.switchTo().frame("unMovableLayerFrame");
Thread.sleep(5000);
TestClass.Typecontractstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");

// WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
//act.moveToElement(active);
//active.click();
//Dates
// Lease CommencementDate
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame"); 
Thread.sleep(6000);
TestClass.TypeCommencementDate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

// Lease Expiration Date
TestClass.TypeExpirationdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

//Business unit
Thread.sleep(2000);
JavascriptExecutor jse=(JavascriptExecutor)driver;
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
TestClass.TypeBusinessunit("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Actions act1=new Actions(driver);
Thread.sleep(4000);
act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
Thread.sleep(4000);

// Go to contact details page// 
driver.switchTo().defaultContent();
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
// driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
Thread.sleep(2000);
driver.switchTo().defaultContent();
    
// click on data central hub   
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
// driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
String contactsWindow = driver.getWindowHandle();
Set<String> winHandleBefore = driver.getWindowHandles();
// Perform the click operation that opens new window
// Switch to new window opened 
for(String winHandle : winHandleBefore)
{
   driver.switchTo().window(winHandle);
}        
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 

// driver.findElement(By.id("Find_3")).click();
Thread.sleep(1000);
driver.switchTo().frame("childFrame");
Thread.sleep(1000);
driver.switchTo().frame("frameMain");
Thread.sleep(1000);
driver.switchTo().frame("contentFrame");

//  driver.findElement(By.id("repSubList")).sendKeys("All People");
// driver.switchTo().frame("childFrame");
//Thread.sleep(1000);
// driver.switchTo().frame("frameMain");
// Thread.sleep(1000);
//driver.switchTo().frame("contentFrame");  
Thread.sleep(4000); 
//New code added for selecting all roles 
//table[@id='subRepLayerTable']//span[@class='bodyText']
TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(4000);
List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  

Thread.sleep(2000);
///// click on All people link////////////////////
WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	 add.click();////

Actions act2 = new Actions(driver);  
System.out.println(clicksecondelement.getText());
act2.moveToElement(clicksecondelement);
Thread.sleep(8000);
TestClass.clickElement(clicksecondelement, driver, "click");
//clicksecondelement.click();

//////////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////

WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypeDCHUSERNAME("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(8000);
Actions act3=new Actions(driver);
act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);
//////// act2.sendKeys(Keys.TAB).build().perform()//////////////////////
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Data Central Validate");  

///----------------------------------------------------------------------------------------------------------------------------------------------  
////Portfolio Administrator selection////////////////////////////////////////
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
// driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
Set<String> winHandleBefore1 = driver.getWindowHandles();
for(String winHandle1 : winHandleBefore1)
{
      driver.switchTo().window(winHandle1);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(8000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(4000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  
Thread.sleep(2000);
//click on All people link
WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

Actions act4 = new Actions(driver);  
System.out.println(clicksecondelement1.getText());
act4.moveToElement(clicksecondelement1);
Thread.sleep(8000);
TestClass.clickElement(clicksecondelement1, driver, "select All");
//clicksecondelement1.click();

///////////selecting PA user  Rekha//////////////////////////////////////////////////////////////////////////////
WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePA("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(8000);
Actions act5=new Actions(driver);
act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(3000);
TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(3000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator");   
//
///-------------------------------------------------------------------------------------------------------------------------------------
/// //  User Selected for Portfolio Administrator  - Validate
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")), driver, "PA role");
//driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
System.out.println("Clicked on Portfolio Administrator  - Validate");

Set<String> winHandleBefore2 = driver.getWindowHandles();
for(String winHandle2 : winHandleBefore2){
     driver.switchTo().window(winHandle2);
  }    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");
TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "image");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl3.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
// add.click();

Actions act6 = new Actions(driver);  
System.out.println(clicksecondelement2.getText());
act6.moveToElement(clicksecondelement2);
Thread.sleep(8000);
TestClass.clickElement(clicksecondelement2, driver, "click");
//clicksecondelement2.click();

//////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePAValidate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(9000);
Actions act7=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click on role");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "s.no");
//driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator  - Validate");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Property Manager Selection

driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(8000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "property manger");
//driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
System.out.println("Clicked on Property Manager");
//
Set<String> winHandleBefore3 = driver.getWindowHandles();
for(String winHandle3 : winHandleBefore3)
{
   driver.switchTo().window(winHandle3);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(4000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(2000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl4.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	add.click();
Actions act8= new Actions(driver);  
System.out.println(clicksecondelement3.getText());
act8.moveToElement(clicksecondelement3);
Thread.sleep(8000);
clicksecondelement3.click();
WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePM("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(8000);
Actions act9=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(3000);

driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);  

driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(7000);
driver.findElement(By.id("xBtn")).click();
System.out.println("Property Manager Selected");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Tenant organization  selection
Thread.sleep(1000);
driver.switchTo().window(contactsWindow); 
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");        
//driver.findElement(By.id("attr_seq_1916_selector")).click(); 
Thread.sleep(4000);
TestClass.TypeTenant("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
Actions act10=new Actions(driver);
act10.sendKeys(Keys.TAB).build().perform();
// act1.sendKeys(Keys.TAB).build().perform()
//driver.switchTo().frame("childFrame");
//driver.switchTo().frame("frameMain"); 
//driver.switchTo().frame("contentFrame");
System.out.println("Tenant Organization Selected");
Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Landlord Organization Lookup selection
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
// driver.findElement(By.id("attr_seq_1934_selector")).click();
Thread.sleep(7000);
TestClass.TypeLandlord("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
Thread.sleep(7000);
// LandlordOrganisationLookup.sendKeys("68031057");
Actions act11=new Actions(driver);
Thread.sleep(7000);
act11.sendKeys(Keys.TAB).build().perform();
Thread.sleep(7000);
act11.sendKeys(Keys.ENTER).build().perform();
Thread.sleep(2000);
System.out.println("Landlord Organization Selected");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  jse.executeScript("window.scrollBy(0, 500)", "");
  Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Remit to 
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  //driver.findElement(By.id("attr_seq_1987_selector")).click();
  Thread.sleep(3000);
  TestClass.TypeRemitTo("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
 // WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
 // Thread.sleep(5000);
 // RemitToLookup.sendKeys("68031057");
  Thread.sleep(6000);
  Actions act12=new Actions(driver);
  Thread.sleep(6000);
  act12.sendKeys(Keys.TAB).build().perform();
  System.out.println("Remit Organization Selected");
	 
///////////////////////////////Click on crate draft/////////////////////////////////////////////////////////////////////////////////////////////   
  driver.switchTo().defaultContent();
  Thread.sleep(6000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
  System.out.println("Created draft");

////////--Click on location----------------------------------------------------------------------------------------------------------------
  
  Thread.sleep(9000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();
  
//// / / /////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
  JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
  scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
  
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
 // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  ////System.out.println("Primary Location Selected");

  driver.switchTo().defaultContent();
  Thread.sleep(1000);
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
  Thread.sleep(3000);
  driver.switchTo().frame("childFrame");
  Thread.sleep(1000);
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  System.out.println("Primary Location Selected");
//// /////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
	 Thread.sleep(5000);
	       
	 driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();
  
////////Add payment schedule////////////////////////////////////////////////////////////////////////////////////

	System.out.println("Creating a Payment Schedule");
    
    driver.switchTo().defaultContent();
    Thread.sleep(10000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
    //driver.findElement(By.xpath("//span[text()='Payments']")).click();
    Thread.sleep(3000);
    driver.switchTo().frame("contentFrame");
    Thread.sleep(10000);
    TestClass.clickElement( driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")), driver, "generate payment schedule");
  //  driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
    Thread.sleep(2000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(2000);
    driver.switchTo().frame("contentFrame");
    
   // driver.findElement(By.id("attr_seq_1086_selector")).click();
    Thread.sleep(3000);
   // driver.switchTo().frame("unMovableLayerFrame");   //removed
    Thread.sleep(4000);
   WebElement paymentType=driver.findElement(By.id("attr_seq_1086_selector")); 
   TestClass.clickElement(paymentType, driver, "payment type selector");
   //added
   //WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
    
   //TestClass.Typepaymenttype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
    driver.switchTo().frame("unMovableLayerFrame");
    WebElement paymenttype=driver.findElement(By.xpath("//a//span[text()='SBR Minimum[REC]']"));
    
    TestClass.mouseOverOnElement(driver, paymenttype, "payment type");
    
    //driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
    TestClass.clickElement(paymenttype, driver, "click on payment type");
    
   // Thread.sleep(7000);
   // Actions act13=new Actions(driver);
   // Thread.sleep(7000);
  //  act13.sendKeys(Keys.TAB).build().perform();
//    Thread.sleep(7000);
  //  act13.sendKeys(Keys.ENTER).build().perform();
   // act.moveToElement(paymentType);
    Thread.sleep(3000);
   // paymentType.click();
    Thread.sleep(2000);
    System.out.println("Payment Type Selected");
    
////////////////////////////////////////////Invoice Type Selected /////////////////////////////////////////////////////      
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(6000);
    TestClass.Typeinvoicetype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
    
  // driver.findElement(By.id("attr_seq_1166_selector")).click();
    Thread.sleep(5000);
    Actions act14=new Actions(driver);
    act14.sendKeys(Keys.ENTER).build().perform();
    //Removed code
//    driver.switchTo().frame("unMovableLayerFrame");
//    Thread.sleep(4000); 
//    
//    WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//    act.moveToElement(invoiceType);
//    invoiceType.click();
        System.out.println("Invoice Type Selected"); 
////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        
        //driver.findElement(By.id("attr_seq_1126_selector")).click();
        Thread.sleep(3000);
    // Removed //  driver.switchTo().frame("unMovableLayerFrame");
        Thread.sleep(1000);
        TestClass.Typefrequency("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
     //   frequency.sendKeys("Monthly");
        Actions act15=new Actions(driver);
        act15.sendKeys(Keys.ENTER).build().perform();
      // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
      // act.moveToElement(frequency);
      // frequency.click();
        System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
       // driver.findElement(By.id("attr_seq_1134_selector")).click();
       driver.switchTo().frame("unMovableLayerFrame");
      //  driver.findElement(By.id("attr_seq_1105")).clear();
       // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
        Thread.sleep(5000);
        TestClass.Typepaymentdueon("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
       // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
       // paymentDueOn.sendKeys("First Day of Period");
        Actions act16=new Actions(driver);
        act16.sendKeys(Keys.ENTER).build().perform();
        act.moveToElement(paymentDueOn);
        TestClass.clickElement(paymentDueOn, driver, "payment due on");
       // paymentDueOn.click();
        System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
////selecting full payment start date///////////////////////////////////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");   
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
        Thread.sleep(5000);
        TestClass.Typefullpaymentstartdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
        System.out.println("Full Payment Start Date Selected");
//////////////////////////////////////Selecting number of Number of Schedules Entered///////////////////////////////  
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(6000);
        driver.findElement(By.id("attr_seq_1105")).clear();
        Thread.sleep(5000);
        TestClass.TypeNumberofschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");
       // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
        System.out.println("Number of Schedules Entered");
/////////Months per schedules//////////////////////////////////////////////////////////////////////////////////////
        driver.findElement(By.id("attr_seq_1103")).clear();
        Thread.sleep(5000);
        //driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
        TestClass.TypeMonthsperschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered////////////////////////////////////////////////////////////////////////        
        Thread.sleep(5000);
        JavascriptExecutor jse1=(JavascriptExecutor)driver;
        jse1.executeScript("window.scrollBy(0, 500)", "");
        driver.findElement(By.id("attr_seq_1100")).clear();
        TestClass.TypeAmountperBasis("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
        System.out.println("Amount Per Basis entered");       
////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////
        
        System.out.println("Finding Cost code");
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")), driver, "cost code");
       // driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "s.No");
       // driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
      // driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
        System.out.println("cost code Selected");
        
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("Adding Tax Group");
        //JavascriptExecutor jse1=(JavascriptExecutor)driver;
        //jse1.executeScript("window.scrollBy(0, 500)", "");
        //Thread.sleep(4000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.Typetaxgroup("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
        Actions act17=new Actions(driver);
        Thread.sleep(4000);
        act17.sendKeys(Keys.TAB).build().perform();
        Thread.sleep(4000);
        System.out.println("Tax Group is Added");       
////Generate payment schedule/////////////////////////////////////////////////////////////////////////////////
        
        System.out.println("Generating payment Schedule");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
       // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
        Thread.sleep(3000);
        System.out.println("Payment Schedules Generated");
//Update payment instructions//////////////////////////////////////////////////////////////////////////////////////
        
      //System.out.println("Payment Instruction");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame7");
        Thread.sleep(10000); 
        TestClass.clickElement(driver.findElement(By.xpath("//a[@title='Z000']")), driver, "update payment instructions");
      //  driver.findElement(By.xpath("//a[@title='YC00']")).click();
        
        Thread.sleep(4000);
        System.out.println("Updating Payment Instructions");
    
        driver.switchTo().defaultContent();
        //find all windows list and switch on that
        Set<String> allWindows1=driver.getWindowHandles();
        Iterator<String> it1=allWindows1.iterator();
        String main1=it1.next();
        String sub1=it1.next();
        String sub2=it1.next();
        
        driver.switchTo().window(sub2);        
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        ///Select payment method////
       // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
        Actions act18=new Actions(driver);
        
        act18.sendKeys(Keys.TAB).build().perform();       
        Thread.sleep(4000);
        //selecting one payment type from that list
        driver.findElement(By.xpath("//tr[@id='129243788']")).click();
        Thread.sleep(9000);   
        driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
        Thread.sleep(2000);    
        System.out.println("Payment Instructions Updated");
        driver.switchTo().window(sub1);    
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
       // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
        System.out.println("Created Schedule");
        Thread.sleep(5000);    
        
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        //driver.switchTo().frame("closeModalPageFrame");
       TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
       // driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
        Thread.sleep(5000);
        System.out.println("Window closed");	        
//////////////////////////////////////////////////////////////////////////////refresh page///////////////////////////////////// 
        Thread.sleep(3000);      
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame129");
        Thread.sleep(2000);  
        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(2000);    
        System.out.println("Checking Payment Schedule");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        /// Get lease id
// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
       Thread.sleep(10000);
       driver.switchTo().defaultContent();
//     driver.switchTo().frame("contentFrame");
//    //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
//      Thread.sleep(9000);
      //xpath for general tab to get lease id
       WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
       TestClass.clickElement(Generaltab, driver, "General Tab");
      // Generaltab.click();
      System.out.println("entered into general tab");
//////////WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));////////////////////////

       Thread.sleep(1000);
       driver.switchTo().frame("contentFrame");
       Thread.sleep(1000);
       WebElement leaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
       Thread.sleep(1000);
       String Leaseid= leaseid.getText();
       Thread.sleep(2000);
       System.out.println("Lease id is " +Leaseid);   
/////////////////////////////////////Write code for SBR clause////////////////////////////////////////////////////////            
         Thread.sleep(1000);
  	     driver.switchTo().defaultContent();
  	    Thread.sleep(6000);
  	    WebElement Optionancluasesin = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
  	   TestClass.clickElement(Optionancluasesin, driver, "option and cluases");
  	   System.out.println("Enter into option and clause section"); 
  	   driver.switchTo().frame("contentFrame");
  	   Thread.sleep(6000);
  	   WebElement AddButtonin = driver.findElement(By.xpath("//div[@id='Add_38']//span[@class='actionButtonText']"));
  	         
  	   TestClass.clickElement(AddButtonin, driver, "Add option and cluases");
  	   System.out.println("clicked on add button");
  	   Thread.sleep(2000);
///////////////Type name of the clause//////////////////////////////////////////////////////////////////////
  	   driver.switchTo().frame("childFrame");
  	   driver.switchTo().frame("contentFrame");
  	   Thread.sleep(6000);
  	   WebElement ClauseNamein = driver.findElement(By.xpath("//input[@id='attr_seq_1002']"));
  	   ClauseNamein.sendKeys("SBR clause income");
  	          
  	   System.out.println("added clause name");
  	   Thread.sleep(2000);
  	   WebElement ClauseTypein = driver.findElement(By.xpath("//input[@id='attr_seq_1313']"));
  	         
  	   ClauseTypein.sendKeys("Variable Rent");
  	         
  	   System.out.println("added clause type");
  	         
  	   Actions act22=new Actions(driver);
  	   act22.sendKeys(Keys.TAB).build().perform();
  	   
  	 JavascriptExecutor jse2=(JavascriptExecutor)driver;
     jse2.executeScript("window.scrollBy(0, 500)", "");
 /////////////////////////click on find button to link payment schedule/////////////////////////////////////////////////////////////////// 	  
     
       Thread.sleep(5000); 
  	   WebElement FindClauses = driver.findElement(By.xpath("//div[@id='Find_16']//span[@class='actionButtonText']"));
  	   Thread.sleep(1000);      
  	   TestClass.clickElement(FindClauses, driver, "find clause");
  	   System.out.println("clicked on find button");
  	         
  	         //List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
  	         //System.out.println(elements.size()); 
  	   Thread.sleep(5000);
  	   driver.switchTo().defaultContent();
  	   driver.switchTo().frame("contentFrame");
  	   Thread.sleep(2000);
  	   driver.switchTo().frame("childFrame");
  	   driver.switchTo().frame("contentFrame");
  	   Thread.sleep(2000);
  	   System.out.println("inside content frame");
  	   Thread.sleep(4000);
  	   driver.switchTo().frame("childFrame");
  	   Thread.sleep(4000);
  	   driver.switchTo().frame("frameMain");
  	   driver.switchTo().frame("contentFrame");
  	         
  	   List<WebElement>elements1 = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
  	   System.out.println("Size is " +elements1.size());
  	         for(int j=0;j<elements1.size();j++)
  	        {
  	         	 Thread.sleep(2000);	 
  	         	 WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']")).get(j);
  	         	 System.out.println(rowcount.getText());	
  	         	 String  Text= rowcount.getText();
  	         	 System.out.println(Text);
  	         	 Thread.sleep(2000);
  	         	 TestClass.clickElement(rowcount, driver, "click on rows");
  	        }      
            System.out.println("payment scheduled linked");
  	         
  ///////// /// ///// Click on OK button after selecting payment schedule///////////////////////////
  	         
  	         Thread.sleep(4000);   
  	         WebElement OK=  driver.findElement(By.xpath("//table[@id='actionsTable']//tbody//span[@class='actionButtonText' and text()='OK']"));
  	         TestClass.clickElement(OK, driver, "OK button");
  	         
  	         System.out.println("Clicked on ok");
   ///////////////select Billing frequency in variable rent set up//////////////////////////////////////////
  	         
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  	         Thread.sleep(5000);
  	         WebElement Frequencyselector = driver.findElement(By.xpath("//a[@id='attr_seq_1380_selector']"));
  	         Frequencyselector.click();
  	         Thread.sleep(1000);
  	         driver.switchTo().frame("unMovableLayerFrame");
  	         Thread.sleep(2000);
  	         WebElement Billingfrequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
  	         act.moveToElement(Billingfrequency);
  	         Thread.sleep(1000);
  	         Billingfrequency.click();
  	         System.out.println("Selected Billing frequency as monthly in variable rent");
  	        // WebElement Frequency = driver.findElement(By.xpath("//input[@id='attr_seq_1380']"));
  	         
  /////////////////////Typing First Reporting Period Start Date///////////////////////////////////////////////////
  	         
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  	         Thread.sleep(3000);
  	         WebElement firstReportingfrequency= driver.findElement(By.xpath("//input[@id='attr_seq_1252']"));
  	         firstReportingfrequency.clear();
  	         firstReportingfrequency.sendKeys("2/01/2019");
  	         System.out.println("dates are selected");
  	         	   
  	         WebElement VariableRentSetup = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Variable Rent Setup']"));
  	         
  	         TestClass.clickElement(VariableRentSetup, driver, "click on Variable Rent setup");                //click to refresh
  	       //  VariableRentSetup.click();
  	         
  /////////////write a code to click on create button /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	         
//  	         driver.switchTo().defaultContent();
//  		     driver.switchTo().frame("contentFrame");
//  		     driver.switchTo().frame("childFrame");
//  	         Thread.sleep(1000);
//  		     WebElement Create =  driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Create']")); 
//  		     Create.click();
//  		     TestClass.clickElement(Create, driver, "click on create");
//  		    System.out.println("Clicked on created");          	         
  /////////////////go to Min Max tab///////////////////////////////////////////////////////////////////////////////////////////////////	         
  		     driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame"); 
  		    Thread.sleep(3000);
  	        // WebElement MinMax = driver.findElement(By.xpath("//div[@id='sectionTabs44']"));
  	         WebElement MinMax = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Min/Max']"));
  	         
  	         TestClass.clickElement(MinMax, driver, "MinMax tab");
  	         System.out.println("Enter into min max tab");
  //////////////////////// Click on Add button////////////////////////////////////////////////////////////////////////////
  	         Thread.sleep(3000);
  	         WebElement Add = driver.findElement(By.xpath("//div[@id='Add_82']//span[@class='actionButtonText']"));
  	         TestClass.clickElement(Add, driver, "click on Add");
  	         System.out.println("Clicked on add inside min/Max");
  /////// enter effective date///////////////////////////////////////////////////////////////////////////
  	         Thread.sleep(5000);
  	         driver.switchTo().frame("innerFrame82");
  	         System.out.println("inside inner frame");
  	         Thread.sleep(8000);
  //////  WebElement Effectivefrom = driver.findElement(By.xpath("//input[@id='fld_82_133687488_1080']")); 	
  	         List<WebElement>  totalelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
  	         System.out.println( "elemnets are " +totalelements.size());
  	         
  	      	 WebElement Effectivefrom = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(0);
  	         
  	       // WebElement Effectivefrom = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@id='fld_82_133689215_1080']"));		
  	      	 Thread.sleep(4000);
  	         Effectivefrom.sendKeys("01/01/2019");
  	         //input[@id='fld_82_133689061_1080']
  	         Thread.sleep(3000);
  	         WebElement EffectiveTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(1);
  	        // fld_82_133689061_1081
  	         Thread.sleep(3000);
  	         EffectiveTo.sendKeys("12/12/2019");
  	         
  	         Thread.sleep(3000);
  	         WebElement MinAmount= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
  	         
  	         Thread.sleep(3000);
  	         MinAmount.sendKeys("0");
  	         Thread.sleep(3000);
  	         
  	         WebElement MaxAmount= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
  	         MaxAmount.clear();
  	         Thread.sleep(3000);
  	         MaxAmount.sendKeys("3000");
  	         Thread.sleep(3000);
  	         TestClass.clickElement(MinAmount, driver, "click on Min amount");   // to rfersh amount after entering it
  ///////////Go to quantily based rules///////////////////////////////////////////////////////////////////////////	         
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  //////////////////////////////////////Enter into quantity based rules//////////////////////////////////   
  	         WebElement Quatitybasedrules = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Quantity Based Rules']"));
  	         
  	         TestClass.clickElement(Quatitybasedrules, driver, "quantilty based rules");
  	         
  	         Thread.sleep(3000);
  	         WebElement Add2 = driver.findElement(By.xpath("//div[@id='Add_78']//span[@class='actionButtonText']"));
  	         TestClass.clickElement(Add2, driver, "click on Add");
  	         System.out.println("Clicked on add button on quantity based rules");
  	         Thread.sleep(7000);
  	         
  	         driver.switchTo().frame("innerFrame78");
  	         WebElement salescatogeroyselctor = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//a[@title='Select Sales Category']"));
  	         
  	         TestClass.clickElement(salescatogeroyselctor, driver, "select sales catogery");
  	        // salescatogeroyselctor.click();
  	         
  	         Thread.sleep(3000);
  	         driver.switchTo().frame("unMovableLayerFrame");
  	         WebElement Salescat=driver.findElement(By.xpath("//a//span[text()='Fuel - Petrol -All Grds']"));
  	         TestClass.mouseOverOnElement(driver, Salescat, "petrol all grd");
  	        // act.moveToElement(Pertrolallgrds);
  	         TestClass.clickElement(Salescat, driver, "Click on pertol");
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("innerFrame78");
  	         
  	         List<WebElement>  ALLelements =  driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
  	         
  	         System.out.println(ALLelements.size());
  	         
  	         WebElement Effectivefrom1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
  	         Thread.sleep(1000);
  	         Effectivefrom1.sendKeys("01/01/2019");
  	         
  	         WebElement EffectiveTo1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
  	         Thread.sleep(1000);
  	         EffectiveTo1.sendKeys("12/12/2019");
  	         
  	         WebElement Quantityfrom= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(4);
  	         
  	         Quantityfrom.sendKeys("0");
  	         Thread.sleep(1000);
  	         WebElement QuantityTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(5);
  	         Thread.sleep(1000);
  	         QuantityTo.clear();
  	         QuantityTo.sendKeys("1000");
  	         
  	         WebElement MinAmount1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(6);
  	         Thread.sleep(2000);
  	         MinAmount1.clear();
  	         Thread.sleep(1000);
  	         MinAmount1.sendKeys("1000");
  	         Thread.sleep(3000);
  	         TestClass.clickElement(QuantityTo, driver, "to refresh the values"); // just to click on screen to refresh min amount value
  	         
  	         WebElement Multiplier= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(7);
  	        
  	         Multiplier.sendKeys("0.5");
  	         
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  	         Thread.sleep(2000);
  ///////////////////////////////enter into value based Tab///////////////////////////////////////////////////////////////////////////
  	         System.out.println("Enter into value based rules");
  	         WebElement ValueBasedRue = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Value Based Rules']"));
  	         
  	         Thread.sleep(2000);
  	         TestClass.clickElement(ValueBasedRue, driver, "Valued based rules screen");
  	         
  	         WebElement AddValuebasedRul = driver.findElement(By.xpath("//div[@id='Add_45']//span[@class='actionButtonText']"));
  	         Thread.sleep(2000);
  	 
  	         TestClass.clickElement(AddValuebasedRul, driver, "add value based rules");  
  /////////////////////////////////Select sales based catogory elements////////////////////////////////////////////////      
  	         driver.switchTo().frame("innerFrame45");
  	         Thread.sleep(2000);
  	         WebElement salescatogeroyselctor1 = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//a[@title='Select Sales Category']"));
  	         
  	         TestClass.clickElement(salescatogeroyselctor1, driver, "sales catogery");
  	         
  	         driver.switchTo().frame("unMovableLayerFrame");
  	         WebElement Salescat1=driver.findElement(By.xpath("//a//span[text()='Fuel - Petrol -All Grds']"));
  	         TestClass.mouseOverOnElement(driver, Salescat1, "petrol all grd");
  	         TestClass.clickElement(Salescat1, driver, "click on petrol sales grad");
  	         
  	         driver.switchTo().defaultContent();
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("childFrame");
  	         driver.switchTo().frame("contentFrame");
  	         driver.switchTo().frame("innerFrame45");
  	         
             List<WebElement> ALLelementinsalesbased =  driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
  	         
  	         System.out.println(ALLelementinsalesbased.size());
  	         
  	         WebElement Effectivefrom2= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
  	         Thread.sleep(1000);
  	         Effectivefrom2.sendKeys("01/01/2019");
  	         
  	         WebElement EffectiveTo2= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
  	         Thread.sleep(1000);
  	         EffectiveTo2.sendKeys("12/12/2019");  
  	    
             WebElement Baseslesfrom= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(4);
  	         
             Baseslesfrom.sendKeys("0");
  	         Thread.sleep(1000);
  	         
  	         WebElement BaseslesTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(5);
  	         Thread.sleep(1000);
  	         BaseslesTo.clear();
  	         BaseslesTo.sendKeys("1000");
  	         
  	         WebElement MinAmountvaluebasedrules= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(6);
  	         
  	         Thread.sleep(1000);
  	         MinAmountvaluebasedrules.clear();
  	         MinAmountvaluebasedrules.sendKeys("2000");
  	         
  
/////////////////////////////////click on create clause///////////////////////////////////////////////////////////////////////////////////////
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("childFrame");

WebElement Create =  driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Create']"));   
TestClass.clickElement(Create, driver, "click on create");

WebElement Saveandclose = driver.findElement(By.xpath("//table[@id='tabActionTable']//div[@id='Save_&_Close']//span[@class='actionButtonText' and text()='Save & Close']")); 

TestClass.clickElement(Saveandclose, driver, "save and close");     
         
        
/////////////////////////////////////////submit lease/////////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='General']")), driver, "submit button");
    //driver.findElement(By.xpath("//span[text()='General']")).click();
    Thread.sleep(2000);    
    driver.switchTo().defaultContent();
    Thread.sleep(5000);
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Submit']")), driver, "Submit lease");
    //driver.findElement(By.xpath("//div[@id='Submit']")).click();
    Thread.sleep(5000);    
    System.out.println("Submit Lease Contract");      
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////      
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(9000);
    System.out.println("Activating the Contract");
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    //search by lease id not by name correct it  corrected it
   // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys(ContractName);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Actions act19=new Actions(driver);
    act19.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(4000);
    
    driver.switchTo().defaultContent();
    WebElement frm1=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm1);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(50000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
   // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(10000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")), driver, "Click on draft accounting review");
   // driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")).click();
    Thread.sleep(4000);
///////// Click on activate the lease//////////////////////////////////////////////////////////////////////////
    Set<String> allWindows2=driver.getWindowHandles();
    Iterator<String> it2=allWindows2.iterator();
    String main2=it2.next();
    String sub3=it2.next();
    
    //System.out.println(main2);
    //System.out.println(sub3);
    
    driver.switchTo().window(sub3);                
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Activate']")), driver, "Activate lease");
   // driver.findElement(By.xpath("//div[@id='Activate']")).click();
    Thread.sleep(5000);
//////////////////////////////////////////////////////////////////////Validate status////////////////////////////////////////////   
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(3000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
    //driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
    Thread.sleep(10000);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Thread.sleep(7000);
    Actions act20=new Actions(driver);
    act20.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(5000);
    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
    Thread.sleep(2000);
    System.out.println(allelements.size()); 
    Thread.sleep(5000);	     
    for(int i=0;i<allelements.size();i++)
    {
    	 Thread.sleep(2000);	 
    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
    	 System.out.println(Status.getText());	
    	 String  statustext= Status.getText();
    	
   if(statustext.equalsIgnoreCase("Active"))
		   {
	      // Assert.assertTrue(True);
	        System.out.println("Test is Passed,Lease is activated"); 
		   }		 
	else	 
		  {
			 System.out.println("Test is failed,Lease is not activated");
			
		  }		
    }	 
    
    WebElement Lease =driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(1);
    
    TestClass.clickElement(Lease, driver, "click on Lease id");
    System.out.println("Clicked on Lease id");
    
    Set<String> allWindows1in=driver.getWindowHandles();
    System.out.println("Number of windows are"  +allWindows1in);
    Iterator<String> itera=allWindows1in.iterator();
    String mainwindow=itera.next();
    String subwindow=itera.next();
    System.out.println(mainwindow);
    System.out.println(subwindow);
    driver.switchTo().window(subwindow);
    
    Thread.sleep(2000);
    driver.switchTo().defaultContent();
    System.out.println("inside default frame");
    Thread.sleep(8000);
    WebElement  Optionancluases1 = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
  //WebElement Optionancluases = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
    Thread.sleep(2000);
    TestClass.clickElement(Optionancluases1, driver, "option and cluases");
    System.out.println("Enter into option and clause section"); 
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("innerFrame38");
    
    WebElement  SBRclause= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(1);
    
    TestClass.clickElement(SBRclause, driver, "SBRclause");
    
    Set<String> allWindows3=driver.getWindowHandles();
    System.out.println("Number of windows are " +allWindows3.size());
    Iterator<String> itera1=allWindows3.iterator();
    String mainwindow1=itera1.next();
    String subwindow2=itera1.next();
    String subwindow3=itera1.next();
    System.out.println(mainwindow1);
    System.out.println(subwindow2);
    driver.switchTo().window(subwindow3);
    Thread.sleep(2000);
    driver.switchTo().frame("contentFrame");
    WebElement BillingTab = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Billing']"));
    TestClass.clickElement(BillingTab, driver, "Inside billing tab"); 
    System.out.println("inside billing Tab");
  
////////////////////////Click on any of the entry to provide reported sales////////////////////////////////////////////////////////////////////
/////////////////// count the entries in billing tab and click on that///////////////////////////////////////////////////////////////////////
  Thread.sleep(4000);
  driver.switchTo().frame("innerFrame81");
  List<WebElement>Entiesinbillingtab= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Due Date')]//a"));
    
  System.out.println("total Entries in billing tab are  " +Entiesinbillingtab.size());
  Thread.sleep(2000);
for(int j=0;j<Entiesinbillingtab.size();j++)
 {
    Thread.sleep(2000);
    driver.switchTo().window(subwindow3);
    driver.switchTo().defaultContent();
    Thread.sleep(1000);
    driver.switchTo().frame("contentFrame");
    Thread.sleep(6000);
    driver.switchTo().frame("innerFrame81");
    System.out.println("Inside inner Frame81");
   	Thread.sleep(4000);	 
   	WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Due Date')]//a")).get(j);
   	System.out.println(rowcount.getText());	
   	String  Text= rowcount.getText();
   	System.out.println(Text);
   	Thread.sleep(3000);
   	TestClass.clickElement(rowcount, driver, "click on row");;
   	Set<String> allWindows4=driver.getWindowHandles();
    System.out.println("Number of windows are  " +allWindows4.size());
    Iterator<String> itera2=allWindows4.iterator();
    String mainwindows1=itera2.next();
    String subwindows2= itera2.next();
    String subwindows3= itera2.next();
    Thread.sleep(3000);
    String subwindows4=itera2.next();
    Thread.sleep(1000);
    System.out.println(mainwindows1);
    Thread.sleep(1000);
    System.out.println(subwindows2);
    driver.switchTo().window(subwindows4);
    Thread.sleep(2000);
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("innerFrame20");
    WebElement reportedsales = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Reporting From')]//a"));
    Thread.sleep(2000);
    TestClass.clickElement(reportedsales, driver, "reported sales");
    System.out.println("inside reported sales window");
    Set<String> allWindows5=driver.getWindowHandles();
    System.out.println("Number of windows are " +allWindows5.size());
    Iterator<String> itera3=allWindows5.iterator();
    String mainwindow51=itera3.next();
    String subwindows52=itera3.next();
    String subwindows53=itera3.next();
    String subwindows54=itera3.next();
    String subwindows55=itera3.next();
    System.out.println(mainwindow51);
    System.out.println(subwindows52);
    driver.switchTo().window(subwindows55);
    Thread.sleep(1000);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    Thread.sleep(1000);
    driver.switchTo().frame("innerFrame36");
    Thread.sleep(3000);
    
    WebElement reportedsalestextbox = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText']//input[@type='text']"));
    
    reportedsalestextbox.sendKeys("1200");
    
    System.out.println("enter reported sales");
    
    Thread.sleep(1000);
    driver.switchTo().defaultContent();  //write to click on complete button
    
    WebElement closewindow = driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Complete']"));
    
    TestClass.clickElement(closewindow, driver, "  Complete");
    System.out.println(" enter reportes sales and closed wondow");
    Thread.sleep(1000);
    driver.switchTo().window(subwindows54);
//// click on create estimate//////////////////////////////////////////////////////////////////////////////     
    driver.switchTo().frame("contentFrame");
    WebElement Createestimate = driver.findElement(By.xpath("//div[@id='Create Estimate_26']//span[@class='actionButtonText']"));
    Thread.sleep(1000);
    TestClass.clickElement(Createestimate, driver, "Closereported sales window"); 

    System.out.println("Clicked on create estimate");
    Thread.sleep(2000);
    driver.switchTo().defaultContent(); 
    Thread.sleep(2000); 
    WebElement Issue = driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Issue']"));          
/////////click on issue//////////////////////////////////////////////////////////////////////////////////////////////
    Thread.sleep(2000);
    Issue.click();
   // TestClass.clickElement(Issue, driver, "click on issue");
    
    System.out.println("  Clicked in issue");
    Thread.sleep(10000);
    
    System.out.println("window is closed");
   }    
        
  //////////////////////logout code////////////////////////////////////////////////////////////////////////

     driver.switchTo().window(main1);
     int size = driver.findElements(By.tagName("iframe")).size();
    // driver.switchTo().frame(0);
     Thread.sleep(9000);
    //driver.switchTo().frame("loginMain");
     driver.switchTo().defaultContent();
     System.out.println(driver.getTitle());
	 waitTillPageLoad(driver, 30);
	 Thread.sleep(10000);
	 WebElement Logout = driver.findElement(By.xpath("//a[@id='auto-sign-out-button']"));
     TestClass.clickElement(Logout, driver, "Logout button");
     System.out.println(driver.getTitle());
    
}



//IncomeLease Creation
public static void incomeleasecreation(String filepath, String sheetname, String testcaseID)throws Exception
{
TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Thread.sleep(20000); 
//click on all contracts
TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
///click on add button/////////////////////////////////////////////
Thread.sleep(20000);
WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
driver.switchTo().frame(frm);
driver.switchTo().frame("objectsFrame");
Thread.sleep(30000);
// click on add contract/////////////////////////////////////////////////////////////////////////////////////////
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");

//find all windows list and switch on that///////////////////////////////////////////////////////////////////////////
Set<String> allWindows=driver.getWindowHandles();
Iterator<String> it=allWindows.iterator();
String main=it.next();
String sub=it.next();
System.out.println(main);
System.out.println(sub);
driver.switchTo().window(sub);
driver.manage().window().maximize();
driver.switchTo().frame("contentFrame");

//Generating Random Contract Name
//Random ranGenerator=new Random();
//Integer RanNumber=ranGenerator.nextInt(100);    
//String ContractName="Lease "+RanNumber;
TestClass.TypeLeaseName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_1308_selector']")), driver, "incomeLease Type");
Thread.sleep(4000);
driver.switchTo().frame("unMovableLayerFrame");
Thread.sleep(6000);
TestClass.TypeIncomeLeaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11"); 
Thread.sleep(6000);
Actions act21 = new Actions(driver);
act21.moveToElement(driver.findElement(By.xpath("//span[text()='Income Lease']")));
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Income Lease']")), driver, "income lease type");

Thread.sleep(3000);
driver.switchTo().defaultContent();
Thread.sleep(2000);
driver.switchTo().frame("contentFrame");
Thread.sleep(4000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();

//WebDriverWait wait = new WebDriverWait(driver,90);
//WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
Thread.sleep(7000);

driver.switchTo().frame("unMovableLayerFrame");

/////type secondary lease  recheck this one more time creating issue while execution////////////////////////////////
TestClass.TypesecondaryleaseTypeforincomelease("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Thread.sleep(5000);
Actions act = new Actions(driver);
act.moveToElement(driver.findElement(By.xpath("//span[text()='Tenant Lease']")));
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Tenant Lease']")), driver, "secondary lease type");
Thread.sleep(5000);

///////////////////// Type Contract status as 'Active'/////////////////////////////////////////////////////////////////////////

driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
// driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
Thread.sleep(3000);
driver.switchTo().frame("unMovableLayerFrame");
Thread.sleep(5000);
TestClass.Typecontractstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");

// WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
//act.moveToElement(active);
//active.click();
//Dates
// Lease CommencementDate
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame"); 
Thread.sleep(2000);
TestClass.TypeCommencementDate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

// Lease Expiration Date
TestClass.TypeExpirationdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

//Business unit
Thread.sleep(2000);
JavascriptExecutor jse=(JavascriptExecutor)driver;
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
TestClass.TypeBusinessunit("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
Actions act1=new Actions(driver);
Thread.sleep(7000);
act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
Thread.sleep(4000);

// Go to contact details page// 
driver.switchTo().defaultContent();
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
// driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
Thread.sleep(1000);
driver.switchTo().defaultContent();
    
// click on data central hub   
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(1000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
// driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
String contactsWindow = driver.getWindowHandle();
Set<String> winHandleBefore = driver.getWindowHandles();
// Perform the click operation that opens new window
// Switch to new window opened 
for(String winHandle : winHandleBefore)
{
   driver.switchTo().window(winHandle);
}        
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 

// driver.findElement(By.id("Find_3")).click();
Thread.sleep(1000);
driver.switchTo().frame("childFrame");
Thread.sleep(1000);
driver.switchTo().frame("frameMain");
Thread.sleep(2000);
driver.switchTo().frame("contentFrame");

//  driver.findElement(By.id("repSubList")).sendKeys("All People");
// driver.switchTo().frame("childFrame");
//Thread.sleep(1000);
// driver.switchTo().frame("frameMain");
// Thread.sleep(1000);
//driver.switchTo().frame("contentFrame");  
Thread.sleep(5000); 
//New code added for selecting all roles 
//table[@id='subRepLayerTable']//span[@class='bodyText']
TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  

Thread.sleep(2000);
///// click on All people link////////////////////
WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	 add.click();////

Actions act2 = new Actions(driver);  
System.out.println(clicksecondelement.getText());
act2.moveToElement(clicksecondelement);
Thread.sleep(9000);
TestClass.clickElement(clicksecondelement, driver, "click");
//clicksecondelement.click();

//////////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////

WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypeDCHUSERNAME("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(8000);
Actions act3=new Actions(driver);
act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);
//////// act2.sendKeys(Keys.TAB).build().perform()//////////////////////
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Data Central Validate");  

///----------------------------------------------------------------------------------------------------------------------------------------------  
////Portfolio Administrator selection////////////////////////////////////////
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
// driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
Set<String> winHandleBefore1 = driver.getWindowHandles();
for(String winHandle1 : winHandleBefore1)
{
      driver.switchTo().window(winHandle1);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(8000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  
Thread.sleep(2000);
//click on All people link
WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

Actions act4 = new Actions(driver);  
System.out.println(clicksecondelement1.getText());
act4.moveToElement(clicksecondelement1);
Thread.sleep(9000);
TestClass.clickElement(clicksecondelement1, driver, "select All");
//clicksecondelement1.click();

///////////selecting PA user  Rekha//////////////////////////////////////////////////////////////////////////////
WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePA("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(9000);
Actions act5=new Actions(driver);
act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(3000);
TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(3000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator");   
//
///-------------------------------------------------------------------------------------------------------------------------------------
/// //  User Selected for Portfolio Administrator  - Validate
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")), driver, "PA role");
//driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
System.out.println("Clicked on Portfolio Administrator  - Validate");

Set<String> winHandleBefore2 = driver.getWindowHandles();
for(String winHandle2 : winHandleBefore2){
     driver.switchTo().window(winHandle2);
  }    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");
TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "image");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl3.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
// add.click();

Actions act6 = new Actions(driver);  
System.out.println(clicksecondelement2.getText());
act6.moveToElement(clicksecondelement2);
Thread.sleep(8000);
TestClass.clickElement(clicksecondelement2, driver, "click");
//clicksecondelement2.click();

//////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePAValidate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(9000);
Actions act7=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click on role");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "s.no");
//driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator  - Validate");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Property Manager Selection

driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(9000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "property manger");
//driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
System.out.println("Clicked on Property Manager");
//
Set<String> winHandleBefore3 = driver.getWindowHandles();
for(String winHandle3 : winHandleBefore3)
{
   driver.switchTo().window(winHandle3);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl4.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	add.click();
Actions act8= new Actions(driver);  
System.out.println(clicksecondelement3.getText());
act8.moveToElement(clicksecondelement3);
Thread.sleep(8000);
clicksecondelement3.click();
WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePM("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");

Thread.sleep(7000);
Actions act9=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);

driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);  

driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(7000);
driver.findElement(By.id("xBtn")).click();
System.out.println("Property Manager Selected");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Tenant organization  selection
Thread.sleep(1000);
driver.switchTo().window(contactsWindow); 
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");        
//driver.findElement(By.id("attr_seq_1916_selector")).click(); 
Thread.sleep(4000);
TestClass.TypeTenant("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
Actions act10=new Actions(driver);
act10.sendKeys(Keys.TAB).build().perform();
// act1.sendKeys(Keys.TAB).build().perform()
//driver.switchTo().frame("childFrame");
//driver.switchTo().frame("frameMain"); 
//driver.switchTo().frame("contentFrame");
System.out.println("Tenant Organization Selected");
Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Landlord Organization Lookup selection
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
// driver.findElement(By.id("attr_seq_1934_selector")).click();
Thread.sleep(7000);
TestClass.TypeLandlord("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
// WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
Thread.sleep(6000);
// LandlordOrganisationLookup.sendKeys("68031057");
Actions act11=new Actions(driver);
Thread.sleep(6000);
act11.sendKeys(Keys.TAB).build().perform();
Thread.sleep(6000);
act11.sendKeys(Keys.ENTER).build().perform();
Thread.sleep(2000);
System.out.println("Landlord Organization Selected");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  jse.executeScript("window.scrollBy(0, 500)", "");
  Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Remit to 
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  //driver.findElement(By.id("attr_seq_1987_selector")).click();
  Thread.sleep(5000);
  TestClass.TypeRemitTo("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
 // WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
 // Thread.sleep(5000);
 // RemitToLookup.sendKeys("68031057");
  Thread.sleep(6000);
  Actions act12=new Actions(driver);
  Thread.sleep(7000);
  act12.sendKeys(Keys.TAB).build().perform();
  System.out.println("Remit Organization Selected");
	 
///////////////////////////////Click on crate draft/////////////////////////////////////////////////////////////////////////////////////////////   
  driver.switchTo().defaultContent();
  Thread.sleep(6000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
  System.out.println("Created draft");

////////--Click on location----------------------------------------------------------------------------------------------------------------
  
  Thread.sleep(9000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();
  
//// / / /////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
  JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
  scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
  
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
 // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
  Thread.sleep(4000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  ////System.out.println("Primary Location Selected");

  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
  Thread.sleep(2000);
  driver.switchTo().frame("childFrame");
  Thread.sleep(1000);
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  System.out.println("Primary Location Selected");
//// /////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
	Thread.sleep(6000);
	       
   driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();
  
////////Add payment schedule////////////////////////////////////////////////////////////////////////////////////

	System.out.println("Creating a Payment Schedule");
    
    driver.switchTo().defaultContent();
    Thread.sleep(9000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
    //driver.findElement(By.xpath("//span[text()='Payments']")).click();
    Thread.sleep(4000);
    driver.switchTo().frame("contentFrame");
    Thread.sleep(10000);
    TestClass.clickElement( driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")), driver, "generate payment schedule");
  //  driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
    Thread.sleep(2000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(2000);
    driver.switchTo().frame("contentFrame");
    
   // driver.findElement(By.id("attr_seq_1086_selector")).click();
    Thread.sleep(2000);
  //  driver.switchTo().frame("unMovableLayerFrame");   //removed
    Thread.sleep(10000);
   // WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']")); //added
   //WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
    
    TestClass.Typepaymenttype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
    Thread.sleep(7000);
    Actions act13=new Actions(driver);
//    Thread.sleep(7000);
//    act13.sendKeys(Keys.TAB).build().perform();
//    Thread.sleep(7000);
    act13.sendKeys(Keys.ENTER).build().perform();
   // act.moveToElement(paymentType);
    Thread.sleep(5000);
   // paymentType.click();
    Thread.sleep(3000);
    System.out.println("Payment Type Selected");
    
////////////////////////////////////////////Invoice Type Selected /////////////////////////////////////////////////////      
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(6000);
    TestClass.Typeinvoicetype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
    
  // driver.findElement(By.id("attr_seq_1166_selector")).click();
    Thread.sleep(5000);
    Actions act14=new Actions(driver);
    act14.sendKeys(Keys.ENTER).build().perform();
    //Removed code
//    driver.switchTo().frame("unMovableLayerFrame");
//    Thread.sleep(4000); 
//    
//    WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//    act.moveToElement(invoiceType);
//    invoiceType.click();
      System.out.println("Invoice Type Selected"); 
////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        
        //driver.findElement(By.id("attr_seq_1126_selector")).click();
        Thread.sleep(3000);
    // Removed //  driver.switchTo().frame("unMovableLayerFrame");
        Thread.sleep(1000);
        TestClass.Typefrequency("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
     //   frequency.sendKeys("Monthly");
        Actions act15=new Actions(driver);
        act15.sendKeys(Keys.ENTER).build().perform();
      // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
      // act.moveToElement(frequency);
      // frequency.click();
        System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
       // driver.findElement(By.id("attr_seq_1134_selector")).click();
       driver.switchTo().frame("unMovableLayerFrame");
      //  driver.findElement(By.id("attr_seq_1105")).clear();
       // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
        Thread.sleep(6000);
        TestClass.Typepaymentdueon("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
       // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
       // paymentDueOn.sendKeys("First Day of Period");
        Actions act16=new Actions(driver);
        act16.sendKeys(Keys.ENTER).build().perform();
        act.moveToElement(paymentDueOn);
        TestClass.clickElement(paymentDueOn, driver, "payment due on");
       // paymentDueOn.click();
        System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
////selecting full payment start date///////////////////////////////////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
        Thread.sleep(4000);
        TestClass.Typefullpaymentstartdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
        System.out.println("Full Payment Start Date Selected");
//////////////////////////////////////Selecting number of Number of Schedules Entered///////////////////////////////  
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(7000);
        driver.findElement(By.id("attr_seq_1105")).clear();
        Thread.sleep(5000);
        TestClass.TypeNumberofschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");
       // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
        System.out.println("Number of Schedules Entered");
/////////Months per schedules////////////////////////////////////////////////////////////////////////////////////////////
        driver.findElement(By.id("attr_seq_1103")).clear();
        Thread.sleep(5000);
        //driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
        TestClass.TypeMonthsperschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered////////////////////////////////////////////////////////////////////////////        
        Thread.sleep(5000);
        JavascriptExecutor jse1=(JavascriptExecutor)driver;
        jse1.executeScript("window.scrollBy(0, 500)", "");
        driver.findElement(By.id("attr_seq_1100")).clear();
        TestClass.TypeAmountperBasis("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
        //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
        System.out.println("Amount Per Basis entered");       
////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////
        
        System.out.println("Finding Cost code");
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")), driver, "cost code");
       // driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "s.No");
       // driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
        TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "ok");
      // driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
        System.out.println("cost code Selected");
        
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("Adding Tax Group");
        //JavascriptExecutor jse1=(JavascriptExecutor)driver;
        //jse1.executeScript("window.scrollBy(0, 500)", "");
        //Thread.sleep(4000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.Typetaxgroup("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_11");
       // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
        Actions act17=new Actions(driver);
        Thread.sleep(4000);
        act17.sendKeys(Keys.TAB).build().perform();
        Thread.sleep(4000);
        System.out.println("Tax Group is Added");  
        
////Generate payment schedule/////////////////////////////////////////////////////////////////////////////////
        
        System.out.println("Generating payment Schedule");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
       // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
        Thread.sleep(3000);
        System.out.println("Payment Schedules Generated");
//Update payment instructions//////////////////////////////////////////////////////////////////////////////////////
        
      //System.out.println("Payment Instruction");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame7");
        Thread.sleep(9000); 
        TestClass.clickElement(driver.findElement(By.xpath("//a[@title='Z000']")), driver, "update payment instructions");
      //  driver.findElement(By.xpath("//a[@title='YC00']")).click();
        
        Thread.sleep(4000);
        System.out.println("Updating Payment Instructions");
    
        driver.switchTo().defaultContent();
        //find all windows list and switch on that
        Set<String> allWindows1=driver.getWindowHandles();
        Iterator<String> it1=allWindows1.iterator();
        String main1=it1.next();
        String sub1=it1.next();
        String sub2=it1.next();
        
        driver.switchTo().window(sub2);        
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        ///Select payment method////
       // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
        Actions act18=new Actions(driver);
        
        act18.sendKeys(Keys.TAB).build().perform();       
        Thread.sleep(4000);
        //selecting one payment type from that list
        driver.findElement(By.xpath("//tr[@id='129243788']")).click();
        Thread.sleep(7000);   
        driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
        Thread.sleep(2000);    
        System.out.println("Payment Instructions Updated");
        driver.switchTo().window(sub1);    
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
       // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
        System.out.println("Created Schedule");
        Thread.sleep(4000);    
        
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        //driver.switchTo().frame("closeModalPageFrame");
       TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
       // driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
        Thread.sleep(4000);
        System.out.println("Window closed");	        
//////////////////////////////////////////////////////////////////////////////refresh page///////////////////////////////////// 
        Thread.sleep(1000);      
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame129");
        Thread.sleep(2000);  
        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(2000);    
        System.out.println("Checking Payment Schedule");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        /// Get lease id
// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
   Thread.sleep(10000);
   driver.switchTo().defaultContent();
//     driver.switchTo().frame("contentFrame");
//    //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
//      Thread.sleep(9000);
      //xpath for general tab to get lease id
       WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
       TestClass.clickElement(Generaltab, driver, "General Tab");
      // Generaltab.click();
       System.out.println("entered into general tab");
//////////WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));////////////////////////

       Thread.sleep(1000);
       driver.switchTo().frame("contentFrame");
       Thread.sleep(2000);
         WebElement leaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
         Thread.sleep(2000);
        String Leaseid= leaseid.getText();
         Thread.sleep(2000);
         System.out.println("Lease id is" +Leaseid);   
        
/////////////////////////////////////////submit lease/////////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='General']")), driver, "submit button");
    //driver.findElement(By.xpath("//span[text()='General']")).click();
    Thread.sleep(2000);    
    driver.switchTo().defaultContent();
    Thread.sleep(4000);
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Submit']")), driver, "Submit lease");
    //driver.findElement(By.xpath("//div[@id='Submit']")).click();
    Thread.sleep(4000);    
    System.out.println("Submit Lease Contract");      
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////      
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(9000);
    System.out.println("Activating the Contract");
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    // search by lease id not by name correct it  corrected it
   // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys(ContractName);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Actions act19=new Actions(driver);
    act19.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(4000);
    
    driver.switchTo().defaultContent();
    WebElement frm1=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm1);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(50000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
   // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(10000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")), driver, "Click on draft accounting review");
   // driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")).click();
    Thread.sleep(4000);
///////// Click on activate the lease//////////////////////////////////////////////////////////////////////////
    Set<String> allWindows2=driver.getWindowHandles();
    Iterator<String> it2=allWindows2.iterator();
    String main2=it2.next();
    String sub3=it2.next();
    
    //System.out.println(main2);
    //System.out.println(sub3);
    
    driver.switchTo().window(sub3);                
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Activate']")), driver, "Activate lease");
   // driver.findElement(By.xpath("//div[@id='Activate']")).click();
    Thread.sleep(5000);
//////////////////////////////////////////////////////////////////////Validate status////////////////////////////////////////////   
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(3000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
    //driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
    Thread.sleep(10000);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Thread.sleep(6000);
    Actions act20=new Actions(driver);
    act20.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(5000);
    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
    Thread.sleep(2000);
    System.out.println(allelements.size()); 
    Thread.sleep(5000);	     
    for(int i=0;i<allelements.size();i++)
    {
    	 Thread.sleep(1000);	 
    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
    	 System.out.println(Status.getText());	
    	 String  statustext= Status.getText();
    	
   if(statustext.equalsIgnoreCase("Active"))
		   {
	      // Assert.assertTrue(True);
	        System.out.println("Test is Passed,Lease is activated"); 
		   }		 
	else	 
		  {
			 System.out.println("Test is failed,Lease is not activated");
			
		  }		
    }	 
    
    //logout code
    int size = driver.findElements(By.tagName("iframe")).size();
    // driver.switchTo().frame(0);
     Thread.sleep(9000);
    //driver.switchTo().frame("loginMain");
     driver.switchTo().defaultContent();
     System.out.println(driver.getTitle());
	 waitTillPageLoad(driver, 30);
	 Thread.sleep(20000);
	 WebElement Logout = driver.findElement(By.xpath("//a[@id='auto-sign-out-button']"));
     TestClass.clickElement(Logout, driver, "Logout button");
     System.out.println(driver.getTitle());
    
}
//Create Draft Lease
public static void Createdraftlease(String filepath, String sheetname, String testcaseID)throws Exception
{
	TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
    
	waitTillPageLoad(driver, 30); 
	Thread.sleep(9000);
	//click on all contracts////////////
	TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
	///click on add button////////////////////////////////////////
	waitTillPageLoad(driver, 30);  
	WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
	driver.switchTo().frame(frm);
	driver.switchTo().frame("objectsFrame");
	waitTillPageLoad(driver, 5000);  
	
	//////////////////// click on add contract//////////////////////////////////////////////////////////////
	
	//waitTillPageLoad(driver, 3000); 
	Thread.sleep(20000);
	
	TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");
	waitTillPageLoad(driver, 30);  
	//find all windows list and switch on that
	Set<String> allWindows=driver.getWindowHandles();
	Iterator<String> it=allWindows.iterator();
	String main=it.next();
	String sub=it.next();
	System.out.println(main);
	System.out.println(sub);
	driver.switchTo().window(sub);
	driver.manage().window().maximize();
	driver.switchTo().frame("contentFrame");

	//Generating Random Contract Name

	//Random ranGenerator=new Random();
	//Integer RanNumber=ranGenerator.nextInt(100);    
	//String ContractName="Lease "+RanNumber;
	
	TestClass.TypeLeaseName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	TestClass.TypeLeaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12"); 

	waitTillPageLoad(driver, 30); 
	Thread.sleep(9000);
	TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");

	waitTillPageLoad(driver, 30); 
	Thread.sleep(9000);
	TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
	//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
	// driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();

	//WebDriverWait wait = new WebDriverWait(driver,90);
	//WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
	//Thread.sleep(30000); removed

	driver.switchTo().frame("unMovableLayerFrame");

	//type secondary lease  recheck this one more time creating issue while execution
	TestClass.TypesecondaryleaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	Thread.sleep(5000);
	waitTillPageLoad(driver, 30); 
	
	Actions act = new Actions(driver);
	act.moveToElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")));
	TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")), driver, "secondary lease");
	Thread.sleep(5000);
	waitTillPageLoad(driver, 30); 

///////////////////// Type Contract status as 'Active'//////////////////////////////////////////////////////////

	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30); 
	TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
	// driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
	waitTillPageLoad(driver, 30); 
	driver.switchTo().frame("unMovableLayerFrame");
	waitTillPageLoad(driver, 30); 
	TestClass.Typecontractstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");

	// WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
	//act.moveToElement(active);
	//active.click();
	//Dates
	// Lease CommencementDate
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame"); 
	Thread.sleep(9000);
	waitTillPageLoad(driver, 30); 
	TestClass.TypeCommencementDate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	// driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

	// Lease Expiration Date
	TestClass.TypeExpirationdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

	//Business unit
	waitTillPageLoad(driver, 30);
	JavascriptExecutor jse=(JavascriptExecutor)driver;
	jse.executeScript("window.scrollBy(0, 500)", "");
	waitTillPageLoad(driver, 30);
	TestClass.TypeBusinessunit("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	Actions act1=new Actions(driver);
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
	waitTillPageLoad(driver, 30);

	// Go to contact details page// 
	Thread.sleep(5000);
	driver.switchTo().defaultContent();
	TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
	// driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	driver.switchTo().defaultContent();
	    
	// click on data central hub   
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	driver.switchTo().frame("innerFrame87");
	waitTillPageLoad(driver, 30);
	TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
	// driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
	String contactsWindow = driver.getWindowHandle();
	Set<String> winHandleBefore = driver.getWindowHandles();
	// Perform the click operation that opens new window
	// Switch to new window opened 
	for(String winHandle : winHandleBefore)
	{
	   driver.switchTo().window(winHandle);
	}        
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 

	// driver.findElement(By.id("Find_3")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(1000);
	driver.switchTo().frame("childFrame");
	waitTillPageLoad(driver, 30);
	driver.switchTo().frame("frameMain");
	waitTillPageLoad(driver, 30);
	driver.switchTo().frame("contentFrame");

	//  driver.findElement(By.id("repSubList")).sendKeys("All People");
	// driver.switchTo().frame("childFrame");
	//Thread.sleep(1000);
	// driver.switchTo().frame("frameMain");
	// Thread.sleep(1000);
	//driver.switchTo().frame("contentFrame");  
	waitTillPageLoad(driver, 30); 
	Thread.sleep(7000);
	//New code added for selecting all roles 
	//table[@id='subRepLayerTable']//span[@class='bodyText']
    
	//TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
	Thread.sleep(5000);
	driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
	waitTillPageLoad(driver, 30);

	List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
	System.out.println(Allppl.size());  
	Thread.sleep(2000);
	waitTillPageLoad(driver, 30);
	///// click on All people link////////////////////
	WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
	//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//		 add.click();
	//
	Actions act2 = new Actions(driver);  
	System.out.println(clicksecondelement.getText());
	act2.moveToElement(clicksecondelement);
	waitTillPageLoad(driver, 30);
	Thread.sleep(10000);
	TestClass.clickElement(clicksecondelement, driver, "click on second role");
	//clicksecondelement.click();

	//// ////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////

	WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
	TestClass.TypeDCHUSERNAME("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");

	waitTillPageLoad(driver, 30);
	Thread.sleep(9000);
	Actions act3=new Actions(driver);
	act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
	waitTillPageLoad(driver, 30);
	//////// act2.sendKeys(Keys.TAB).build().perform()//////////////////////
	
	Thread.sleep(2000);
	//TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")), driver, "select radio button");
	driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "select ok");
	//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "click");
	//driver.findElement(By.id("xBtn")).click();
	System.out.println("User Selected for Data Central Validate");  

	///----------------------------------------------------------------------------------------------------------------------------------------------  
	////Portfolio Administrator selection////////////////////////////////////////
	driver.switchTo().window(contactsWindow);
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	Thread.sleep(5000);
	driver.switchTo().frame("innerFrame87");
	waitTillPageLoad(driver, 30);
	
	TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
	// driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
	Set<String> winHandleBefore1 = driver.getWindowHandles();
	for(String winHandle1 : winHandleBefore1)
	{
	      driver.switchTo().window(winHandle1);
	}    
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30);
	Thread.sleep(2000);
	TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
	//driver.findElement(By.id("Find_3")).click();
	Thread.sleep(5000);
	driver.switchTo().frame("childFrame");
	driver.switchTo().frame("frameMain");
	driver.switchTo().frame("contentFrame");
    
	TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click on image");
	//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(2000);
	List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
	waitTillPageLoad(driver, 30);
	Thread.sleep(2000);
	System.out.println(Allppl.size());  

	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
	//click on All people link
	WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
	//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
	//add.click();

	Actions act4 = new Actions(driver);  
	System.out.println(clicksecondelement1.getText());
	act4.moveToElement(clicksecondelement1);
	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
	TestClass.clickElement(clicksecondelement1, driver, "select All");
	//clicksecondelement1.click();

	///////////selecting PA user  Rekha//////////////////////////////////////////////////////////////////////////////
	WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
	TestClass.TypePA("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");

	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	Actions act5=new Actions(driver);
	act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click");
	//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
	//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
	waitTillPageLoad(driver, 30);
	Thread.sleep(8000);
	TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "click");
	//driver.findElement(By.id("xBtn")).click();
	System.out.println("User Selected for Portfolio Administrator");   
	//
	///-------------------------------------------------------------------------------------------------------------------------------------
	/// //  User Selected for Portfolio Administrator  - Validate
	driver.switchTo().window(contactsWindow);
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	driver.switchTo().frame("innerFrame87");
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
	TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")), driver, "click on role");
	//driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
	System.out.println("Clicked on Portfolio Administrator  - Validate");

	Set<String> winHandleBefore2 = driver.getWindowHandles();
	for(String winHandle2 : winHandleBefore2){
	     driver.switchTo().window(winHandle2);
	  }    
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "click");
	//driver.findElement(By.id("Find_3")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	driver.switchTo().frame("childFrame");
	driver.switchTo().frame("frameMain");
	driver.switchTo().frame("contentFrame");
	
	TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
	//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);

	List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
	System.out.println(Allppl3.size());  

	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	// click on All people link
	WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
	//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
	//add.click();

	Actions act6 = new Actions(driver);  
	System.out.println(clicksecondelement2.getText());
	act6.moveToElement(clicksecondelement2);
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	TestClass.clickElement(clicksecondelement2, driver, "click on role");
	//clicksecondelement2.click();

//////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

	WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
	TestClass.TypePAValidate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");

	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
	Actions act7=new Actions(driver);
	act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
	waitTillPageLoad(driver, 30);
	Thread.sleep(3000);
    
	TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "click");
	//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
    
	TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "click");
	//driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
	TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
	//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(5000);
    
	TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "click");
	//driver.findElement(By.id("xBtn")).click();
	System.out.println("User Selected for Portfolio Administrator  - Validate");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Property Manager Selection

	driver.switchTo().window(contactsWindow);
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	driver.switchTo().frame("innerFrame87");
	waitTillPageLoad(driver, 30);
    Thread.sleep(4000);
	TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "click");
	//driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
	System.out.println("Clicked on Property Manager");
	//
	Set<String> winHandleBefore3 = driver.getWindowHandles();
	for(String winHandle3 : winHandleBefore3)
	{
	   driver.switchTo().window(winHandle3);
	}    
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	waitTillPageLoad(driver, 30);   
	Thread.sleep(4000);
	TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "click on find");
	//driver.findElement(By.id("Find_3")).click();
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
	driver.switchTo().frame("childFrame");
	driver.switchTo().frame("frameMain");
	driver.switchTo().frame("contentFrame");

	TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
	//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
	waitTillPageLoad(driver, 30);
    Thread.sleep(4000);

	List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
	waitTillPageLoad(driver, 30);
    Thread.sleep(4000);
	System.out.println(Allppl4.size());  
	waitTillPageLoad(driver, 30);
    Thread.sleep(4000);
	// click on All people link
	WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

	Actions act8= new Actions(driver);  
	System.out.println(clicksecondelement3.getText());
	act8.moveToElement(clicksecondelement3);
	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
    
	TestClass.clickElement(clicksecondelement3, driver, "third roel");
	//clicksecondelement3.click();
	WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
	TestClass.TypePM("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");

	waitTillPageLoad(driver, 30);
	Thread.sleep(4000);
    
	Actions act9=new Actions(driver);
	act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
	waitTillPageLoad(driver, 30);  
    Thread.sleep(2000);
	TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")), driver, "select radio button");
	//driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
	waitTillPageLoad(driver, 30);  
	Thread.sleep(2000);
    
	TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "click");
	//driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
	
	TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "radio");
	//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
	//driver.findElement(By.id("xBtn")).click();
	System.out.println("Property Manager Selected");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Tenant organization DE01 selection
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	driver.switchTo().window(contactsWindow); 
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");        
	//driver.findElement(By.id("attr_seq_1916_selector")).click(); 
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	TestClass.TypeTenant("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	// driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
	Actions act10=new Actions(driver);
	act10.sendKeys(Keys.TAB).build().perform();
	// act1.sendKeys(Keys.TAB).build().perform()
	//driver.switchTo().frame("childFrame");
	//driver.switchTo().frame("frameMain"); 
	//driver.switchTo().frame("contentFrame");
	System.out.println("Tenant Organization Selected");
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Landlord Organization Lookup selection
	jse.executeScript("window.scrollBy(0, 500)", "");
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	driver.switchTo().defaultContent();
	driver.switchTo().frame("contentFrame");
	// driver.findElement(By.id("attr_seq_1934_selector")).click();
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	TestClass.TypeLandlord("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	// WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	// LandlordOrganisationLookup.sendKeys("68031057");
	Actions act11=new Actions(driver);
	waitTillPageLoad(driver, 30); 
	act11.sendKeys(Keys.TAB).build().perform();
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	act11.sendKeys(Keys.ENTER).build().perform();
	waitTillPageLoad(driver, 30); 
	Thread.sleep(4000);
	System.out.println("Landlord Organization Selected");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  jse.executeScript("window.scrollBy(0, 500)", "");
	  waitTillPageLoad(driver, 30); 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  //Remit to 
	  driver.switchTo().defaultContent();
	  driver.switchTo().frame("contentFrame");
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  //driver.findElement(By.id("attr_seq_1987_selector")).click();
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  TestClass.TypeRemitTo("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	 //WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
	 // Thread.sleep(5000);
	 // RemitToLookup.sendKeys("68031057");
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  Actions act12=new Actions(driver);
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(3000);
	  act12.sendKeys(Keys.TAB).build().perform();
	  System.out.println("Remit Organization Selected");
		 
///////////////////////////////Click on crate draft/////////////////////////////////////////////////////////////////////////////////////////////  
		 
	  driver.switchTo().defaultContent();
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
	  System.out.println("Created draft");
	  
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(7000);
	  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
	/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();
	  
//////////////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
	  
	  JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
	  scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
	  
	  driver.switchTo().frame("contentFrame");
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
	 // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
	  waitTillPageLoad(driver, 30);
	  Thread.sleep(4000);
	  driver.switchTo().frame("childFrame");
	  driver.switchTo().frame("frameMain");
	  driver.switchTo().frame("contentFrame");
	  TestClass.clickElement(driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")), driver, "click");
	  waitTillPageLoad(driver, 30);
	 // driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
	  TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "OK");
	 // driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	  ////System.out.println("Primary Location Selected");

	  driver.switchTo().defaultContent();
	  driver.switchTo().frame("contentFrame");
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	  TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")), driver, "click");
	  //driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(3000);
	  driver.switchTo().frame("childFrame");
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(3000);
	  driver.switchTo().frame("frameMain");
	  driver.switchTo().frame("contentFrame");
	  Thread.sleep(3000);
	  TestClass.clickElement(driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")), driver, "click");
	 // driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
	  TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
	 // driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	  System.out.println("Primary Location Selected");
/////////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
	  waitTillPageLoad(driver, 30); 
	  Thread.sleep(4000);
	 TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")), driver, "click");
     //driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();
	  
	     /// Get lease id
// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
	   Thread.sleep(60000);
	   driver.switchTo().defaultContent();
//	   driver.switchTo().frame("contentFrame");
//	   //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
//	   Thread.sleep(9000);
//xpath for general tab to get lease id
	   WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
	   TestClass.clickElement(Generaltab, driver, "General Tab");
	      // Generaltab.click();
	   System.out.println("entered into general tab");
//////////WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));/////////////////////////////////
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    driver.switchTo().frame("contentFrame");
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(3000);
	    WebElement draftedleaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    String draftlease= draftedleaseid.getText();
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    System.out.println("Lease id is" +draftlease);   	         
//////////////////////////////////////Set/Save Lease id in Xl //////////////////////////////////////////////////////////////
	   Thread.sleep(20000);
	   TestClass.setCellData("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12","DRAFTEDLEASEID",draftlease);
//////////////////////// Validate status///////////////////////////////////////////////////////////////
	    driver.switchTo().window(main);
	    driver.switchTo().defaultContent();
	    driver.switchTo().frame(frm);
	    driver.switchTo().frame("objectsFrame");
	    driver.switchTo().frame("listFrame");
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(3000);
	    TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    TestClass.Typecreateddraftlease("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
	    //driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
	    waitTillPageLoad(driver, 30); 
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    Actions act20=new Actions(driver);
	    act20.sendKeys(Keys.ENTER).build().perform();
	    waitTillPageLoad(driver, 30); 
	    Thread.sleep(4000);
	    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
	    Thread.sleep(2000);
	    System.out.println(allelements.size()); 
	    Thread.sleep(9000);	     
	    for(int i=0;i<allelements.size();i++)
	  {
	    	 waitTillPageLoad(driver, 30); 	 
	    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
	    	 System.out.println(Status.getText());	
	    	 String  statustext= Status.getText();
	    	
	   if(statustext.equalsIgnoreCase("Draft"))
			   {
				  System.out.println("Test Case is Passed,Lease is drafted"); 
			   }		 
		else	 
			  {
				 System.out.println("Test Case is failed,Lease is not drafted");
			  }		
	   }	   	   
}

////SBR income lease




///SBR Lease creation Method
public static void SBRExleasecreation(String filepath, String sheetname, String testcaseID)throws Exception
{
	TestClass.LoginTest("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
	Thread.sleep(25000); 
	//click on all contracts
	TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
	///click on add button
	Thread.sleep(30000);
	WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    Thread.sleep(25000);
    // click on add contract
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");
/////////////////////////////////////find all windows list and switch on that/////////////////////////////////////////////////////////////////////////////////
    Set<String> allWindows=driver.getWindowHandles();
    Iterator<String> it=allWindows.iterator();
    String main=it.next();
    String sub=it.next();
    System.out.println(main);
    System.out.println(sub);
    driver.switchTo().window(sub);
    driver.manage().window().maximize();
    driver.switchTo().frame("contentFrame");
   //Generating Random Contract Name////////////////////////////  
   // Random ranGenerator=new Random();
   // Integer RanNumber=ranGenerator.nextInt(100);    
   //String ContractName="Lease "+RanNumber;
    TestClass.TypeLeaseName("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    TestClass.TypeLeaseType("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01"); 

    Thread.sleep(20000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");
    Thread.sleep(9000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
    //driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
   // driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
  //WebDriverWait wait = new WebDriverWait(driver,90);
  //WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
    Thread.sleep(10000);
    driver.switchTo().frame("unMovableLayerFrame");
 /////////type secondary lease  re-check this one more time creating issue while execution////////////////////////////////////////////////////
    TestClass.TypesecondaryleaseType("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    Thread.sleep(4000);
    Actions act = new Actions(driver);
    act.moveToElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")));
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")), driver, "secondary lease");
    Thread.sleep(2000);  
//////////////////////////////// Type Contract status as 'Active'////////////////////////////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    Thread.sleep(2000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
   // driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
    Thread.sleep(2000);
    driver.switchTo().frame("unMovableLayerFrame");
    Thread.sleep(5000);
    TestClass.Typecontractstatus("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");
    
    //WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
    //act.moveToElement(active);
    //active.click();
    //Dates
    //Lease CommencementDate
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame"); 
    Thread.sleep(9000);
    TestClass.TypeCommencementDate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
   // driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
    
   //Lease Expiration Date
    TestClass.TypeExpirationdate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
   //driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");
    
 /////////adding Business unit////////////////////////////////////////////////////////////////////////////////////////
    Thread.sleep(2000);
    JavascriptExecutor jse=(JavascriptExecutor)driver;
    jse.executeScript("window.scrollBy(0, 500)", "");
    Thread.sleep(4000);
    TestClass.TypeBusinessunit("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    Actions act1=new Actions(driver);
    Thread.sleep(3000);
    act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
    Thread.sleep(3000);
    
  // Go to contact details page// 
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
   // driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
    Thread.sleep(1000);
    driver.switchTo().defaultContent();
        
 //// click on data central hub  //////////////////////////////////////////////////////////////////////
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
   Thread.sleep(1000);
   driver.switchTo().frame("innerFrame87");
   TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
   // driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
   String contactsWindow = driver.getWindowHandle();
   Set<String> winHandleBefore = driver.getWindowHandles();
    // Perform the click operation that opens new window
    // Switch to new window opened 
    for(String winHandle : winHandleBefore)
    {
       driver.switchTo().window(winHandle);
    }        
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    Thread.sleep(4000);
    TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 
    
   // driver.findElement(By.id("Find_3")).click();
    Thread.sleep(1000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(1000);
    driver.switchTo().frame("frameMain");
    Thread.sleep(1000);
    driver.switchTo().frame("contentFrame");
    
  //  driver.findElement(By.id("repSubList")).sendKeys("All People");
   // driver.switchTo().frame("childFrame");
    //Thread.sleep(1000);
   // driver.switchTo().frame("frameMain");
   // Thread.sleep(1000);
    //driver.switchTo().frame("contentFrame");  
    Thread.sleep(4000); 
  //New code added for selecting all roles 
  //table[@id='subRepLayerTable']//span[@class='bodyText']
    driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
    Thread.sleep(4000);
    
    List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
    Thread.sleep(2000);
    System.out.println(Allppl.size());  
    
    Thread.sleep(2000);
  ///// click on All people link////////////////////
    WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//  WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//  	 add.click();

    Actions act2 = new Actions(driver);  
    System.out.println(clicksecondelement.getText());
    act2.moveToElement(clicksecondelement);
    Thread.sleep(7000);
    clicksecondelement.click();
    
////////////////////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////
    WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
    TestClass.TypeDCHUSERNAME("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
    
    Thread.sleep(6000);
    Actions act3=new Actions(driver);
    act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
    Thread.sleep(2000);
  //////// act2.sendKeys(Keys.TAB).build().perform()///////////////////////////////////////////////
    Thread.sleep(2000);
    driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
    Thread.sleep(4000);
    driver.findElement(By.id("xBtn")).click();
    System.out.println("User Selected for Data Central Validate");  
    
///----------------------------------------------------------------------------------------------------------------------------------------------  
////Portfolio Administrator selection///////////////////////////////////////////////////////////////////
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(4000);
  TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
 // driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
   Set<String> winHandleBefore1 = driver.getWindowHandles();
   for(String winHandle1 : winHandleBefore1)
    {
          driver.switchTo().window(winHandle1);
    }    
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(8000);
  TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
  //driver.findElement(By.id("Find_3")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
 
  driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(4000);
 
 List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
 Thread.sleep(2000);
 System.out.println(Allppl.size());  
 
 Thread.sleep(2000);
 //click on All people link
 WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

 Actions act4 = new Actions(driver);  
 System.out.println(clicksecondelement1.getText());
 act4.moveToElement(clicksecondelement1);
 Thread.sleep(7000);
 TestClass.clickElement(clicksecondelement1, driver, "select All");
 //clicksecondelement1.click();
 
 //////////////selecting PA user  Rekha/////////////////////////////////////////////////////////////////////////////////

 WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
 TestClass.TypePA("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
 
 Thread.sleep(8000);
 Actions act5=new Actions(driver);
 act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
 Thread.sleep(3000);
  
  driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
  Thread.sleep(3000);
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
  Thread.sleep(6000);
  driver.findElement(By.id("xBtn")).click();
  System.out.println("User Selected for Portfolio Administrator");   

///-------------------------------------------------------------------------------------------------------------------------------------
 /// //  User Selected for Portfolio Administrator  - Validate
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(6000);
  driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
  System.out.println("Clicked on Portfolio Administrator  - Validate");
  
  Set<String> winHandleBefore2 = driver.getWindowHandles();
  for(String winHandle2 : winHandleBefore2)
    {
         driver.switchTo().window(winHandle2);
     }    
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(6000);
  TestClass.clickElement( driver.findElement(By.id("Find_3")), driver, "find");
 // driver.findElement(By.id("Find_3")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(4000);
 
 List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
 Thread.sleep(2000);
 System.out.println(Allppl3.size());  
 
 Thread.sleep(2000);
 // click on All people link
 WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	 add.click();

 Actions act6 = new Actions(driver);  
 System.out.println(clicksecondelement2.getText());
 act6.moveToElement(clicksecondelement2);
 Thread.sleep(8000);
 TestClass.clickElement(clicksecondelement2, driver, "Select All");
 //clicksecondelement2.click();
 //////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

 WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
 TestClass.TypePAValidate("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
 
 Thread.sleep(8000);
 Actions act7=new Actions(driver);
 act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
 Thread.sleep(3000);
  
 TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "select role");
 //driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
 Thread.sleep(2000);
  
 TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "selecting role");
  //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
 driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
 Thread.sleep(5000);
 TestClass.clickElement( driver.findElement(By.id("xBtn")), driver, "click");
 // driver.findElement(By.id("xBtn")).click();
  System.out.println("User Selected for Portfolio Administrator  - Validate");
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Property Manager Selection
  driver.switchTo().window(contactsWindow);
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  driver.switchTo().frame("innerFrame87");
  Thread.sleep(8000);
  TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "click on property manager");
 // driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
  System.out.println("Clicked on Property Manager");
// 
   Set<String> winHandleBefore3 = driver.getWindowHandles();
 for(String winHandle3 : winHandleBefore3)
    {
       driver.switchTo().window(winHandle3);
    }    
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
   Thread.sleep(5000);
   TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
  // driver.findElement(By.id("Find_3")).click();
   Thread.sleep(5000);
   driver.switchTo().frame("childFrame");
   driver.switchTo().frame("frameMain");
   driver.switchTo().frame("contentFrame");
   
  TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "Click on button");
 // driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
  Thread.sleep(5000);
  
  List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
  Thread.sleep(2000);
  System.out.println(Allppl4.size());  
  
  Thread.sleep(2000);
  // click on All people link
  WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
 //WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
// add.click();
  Actions act8= new Actions(driver);  
  System.out.println(clicksecondelement3.getText());
  act8.moveToElement(clicksecondelement3);
  Thread.sleep(7000);
  clicksecondelement3.click();
  WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
  TestClass.TypePM("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  
  Thread.sleep(7000);
  Actions act9=new Actions(driver);
  act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
  Thread.sleep(2000);
   
  driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
  Thread.sleep(2000);   
  TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "select Role");
   //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
   driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
   Thread.sleep(6000);
   TestClass.clickElement( driver.findElement(By.id("xBtn")), driver, "Click");
  // driver.findElement(By.id("xBtn")).click();
   System.out.println("Property Manager Selected");
   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tenant organization DE01 selection
   Thread.sleep(1000);
   driver.switchTo().window(contactsWindow); 
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");        
 //driver.findElement(By.id("attr_seq_1916_selector")).click(); 
   Thread.sleep(4000);
   TestClass.TypeTenant("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  // driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
   Actions act10=new Actions(driver);
   act10.sendKeys(Keys.TAB).build().perform();
  // act1.sendKeys(Keys.TAB).build().perform()
//   driver.switchTo().frame("childFrame");
//   driver.switchTo().frame("frameMain"); 
//   driver.switchTo().frame("contentFrame");
   System.out.println("Tenant Organization Selected");
   Thread.sleep(3000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //  Landlord Organization Lookup selection
   jse.executeScript("window.scrollBy(0, 500)", "");
   Thread.sleep(2000);
   driver.switchTo().defaultContent();
   driver.switchTo().frame("contentFrame");
  // driver.findElement(By.id("attr_seq_1934_selector")).click();
   Thread.sleep(6000);
   TestClass.TypeLandlord("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
  // WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
   Thread.sleep(6000);
  // LandlordOrganisationLookup.sendKeys("68031057");
   Actions act11=new Actions(driver);
   Thread.sleep(7000);
   act11.sendKeys(Keys.TAB).build().perform();
   Thread.sleep(7000);
   act11.sendKeys(Keys.ENTER).build().perform();
   Thread.sleep(2000);
   System.out.println("Landlord Organization Selected");
   
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
   	  jse.executeScript("window.scrollBy(0, 500)", "");
      Thread.sleep(3000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      //Remit to 
      driver.switchTo().defaultContent();
      driver.switchTo().frame("contentFrame");
      Thread.sleep(5000);
      //driver.findElement(By.id("attr_seq_1987_selector")).click();
      Thread.sleep(5000);
      TestClass.TypeRemitTo("C:\\Tririga\\Lease_Data.xlsx","Tririga","TC_01");
      //WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
     // RemitToLookup.sendKeys("68031057");
      Thread.sleep(5000);
      Actions act12=new Actions(driver);
      Thread.sleep(6000);
      act12.sendKeys(Keys.TAB).build().perform();
 	  System.out.println("Remit Organization Selected"); 
///////////////////////////////Click on crate draft/////////////////////////////////////////////////////////////////////////////////////////////  
 	  driver.switchTo().defaultContent();
      Thread.sleep(6000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
      System.out.println("Created draft"); 
////////--Click on location----------------------------------------------------------------------------------------------------------------
      Thread.sleep(9000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();   
///////////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
      JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
      scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
      
      driver.switchTo().frame("contentFrame");
      Thread.sleep(5000);
      TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
     // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
      Thread.sleep(5000);
      driver.switchTo().frame("childFrame");
      driver.switchTo().frame("frameMain");
      driver.switchTo().frame("contentFrame");
      driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
      driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
      ////System.out.println("Primary Location Selected");
  
      driver.switchTo().defaultContent();
      driver.switchTo().frame("contentFrame");
      Thread.sleep(4000);
      driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
      Thread.sleep(3000);
      driver.switchTo().frame("childFrame");
      Thread.sleep(1000);
      driver.switchTo().frame("frameMain");
      driver.switchTo().frame("contentFrame");
      driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
      driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
      System.out.println("Primary Location Selected");
 //// /////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
  	    Thread.sleep(6000);
  	    driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();   
 //// Adding loop for adding multiple payment schedule/////////////////////////////////////////////////////////
  	        
  	    FileInputStream fis = new FileInputStream("C:\\Tririga\\Lease_Data.xlsx");
  		Workbook wb = (Workbook) WorkbookFactory.create(fis);
  		Sheet sht1 = wb.getSheet("Tririga");
  		int iRowNumb = sht1.getLastRowNum();
  		System.out.println("number of rows in xl " +iRowNumb);
  		
  	  for(int K=1;K<=iRowNumb;K++)  		     
  	 {    
//////////Add payment schedule//////////////////////////////////////////////////////////////////////////////////////
  	    System.out.println("Creating a Payment Schedule");   
  	    Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Thread.sleep(10000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
        //driver.findElement(By.xpath("//span[text()='Payments']")).click();
        Thread.sleep(2000);
        driver.switchTo().frame("contentFrame");
        Thread.sleep(10000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")), driver, "Generate payment schedule");
       // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
        Thread.sleep(2000);
        driver.switchTo().frame("childFrame");
        Thread.sleep(2000);
        driver.switchTo().frame("contentFrame");
        
       // driver.findElement(By.id("attr_seq_1086_selector")).click();
        //Thread.sleep(2000);
      //  driver.switchTo().frame("unMovableLayerFrame");   //removed
        Thread.sleep(8000);
       //WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']")); //added
       //WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
      
        TestClass.Typepaymenttype("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
        Thread.sleep(3000);
        Actions act13=new Actions(driver);
//      act13.sendKeys(Keys.TAB).build().perform();
        act13.sendKeys(Keys.ENTER).build().perform();
       // act.moveToElement(paymentType);
        Thread.sleep(5000);
       // paymentType.click();
        System.out.println("Payment Type Selected");   
//////////////////////////////////////////// Invoice Type Selected /////////////////////////////////////////////////////      
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(2000);
        TestClass.Typeinvoicetype("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
      // driver.findElement(By.id("attr_seq_1166_selector")).click();
        Thread.sleep(3000);
        Actions act14=new Actions(driver);
        act14.sendKeys(Keys.ENTER).build().perform();
        /////Removed code
//        driver.switchTo().frame("unMovableLayerFrame");
//        Thread.sleep(4000); 
//        WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//        act.moveToElement(invoiceType);
//        invoiceType.click();
          System.out.println("Invoice Type Selected"); 
////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
            driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	     /////driver.findElement(By.id("attr_seq_1126_selector")).click();
	        Thread.sleep(2000);
	    // Removed //  driver.switchTo().frame("unMovableLayerFrame");
	        Thread.sleep(1000);
	        TestClass.Typefrequency("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
	     //   frequency.sendKeys("Monthly");
	        Actions act15=new Actions(driver);
	        act15.sendKeys(Keys.ENTER).build().perform();
	      // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
	      // act.moveToElement(frequency);
	      // frequency.click();
	        System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(4000);
	        TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
	       // driver.findElement(By.id("attr_seq_1134_selector")).click();
	       driver.switchTo().frame("unMovableLayerFrame");
	      //  driver.findElement(By.id("attr_seq_1105")).clear();
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
	        Thread.sleep(4000);
	        TestClass.Typepaymentdueon("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
	       // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
	       // paymentDueOn.sendKeys("First Day of Period");
	        Actions act16=new Actions(driver);
	        act16.sendKeys(Keys.ENTER).build().perform();
	        act.moveToElement(paymentDueOn);
	        TestClass.clickElement(paymentDueOn, driver, "payment due on");
	       // paymentDueOn.click();
	        System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
//// selecting full payment start date///////////////////////////////////////////////////////////////////////////////
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
	        Thread.sleep(5000);
	        TestClass.Typefullpaymentstartdate("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
	        System.out.println("Full Payment Start Date Selected");
////////////////////////////////////// Selecting number of Number of Schedules Entered///////////////////////////////  
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(4000);
	        driver.findElement(By.id("attr_seq_1105")).clear();
	        Thread.sleep(5000);
	        TestClass.TypeNumberofschedules("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");
	       // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
	        System.out.println("Number of Schedules Entered");
/////////////Months per schedules//////////////////////////////////////////////////////////////////////////////////////
	        driver.findElement(By.id("attr_seq_1103")).clear();
	        Thread.sleep(5000);
	        //driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
	        TestClass.TypeMonthsperschedules("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered//////////////////////////////////////////////////////////////////////////////////////////////        
	        JavascriptExecutor jse1=(JavascriptExecutor)driver;
	        jse1.executeScript("window.scrollBy(0, 500)", "");
	        Thread.sleep(4000);
	        driver.findElement(By.id("attr_seq_1100")).clear();
	        Thread.sleep(1000);
	        TestClass.TypeAmountperBasis("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	        //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
	        System.out.println("Amount Per Basis entered");	        
////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////   
	        System.out.println("Finding Cost code");
	        driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("frameMain");
	        Thread.sleep(1000);
	        driver.switchTo().frame("contentFrame");
	        Thread.sleep(4000);
	        TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "cost code");
	      //driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
	        driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
	        System.out.println("cost code Selected");
	        
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
	        System.out.println("Adding Tax Group");
	        //JavascriptExecutor jse1=(JavascriptExecutor)driver;
	        //jse1.executeScript("window.scrollBy(0, 500)", "");
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        TestClass.Typetaxgroup("C:\\Tririga\\Lease_Data.xlsx","Tririga",sht1.getRow(K).getCell(0).getStringCellValue());
	       // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
	        Actions act17=new Actions(driver);
	        Thread.sleep(4000);
	        act17.sendKeys(Keys.TAB).build().perform();
	        Thread.sleep(4000);
	        System.out.println("Tax Group is Added");        
//// Generate payment schedule///////////////////////////////////////////////////////////////////////////////// 
	        System.out.println("Generating payment Schedule");
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
	       // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
	        Thread.sleep(3000);
	        System.out.println("Payment Schedules Generated");
//Update payment instructions//////////////////////////////////////////////////////////////////////////////////////    
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("innerFrame7");
	        Thread.sleep(8000); 
	        TestClass.clickElement(driver.findElement(By.xpath("//a[@title='YC00']")), driver, "Generate payment schedule");
	      //  driver.findElement(By.xpath("//a[@title='YC00']")).click();   
	        Thread.sleep(3000);
	        System.out.println("Updating Payment Instructions");
	        driver.switchTo().defaultContent();
///////////////find all windows list and switch on that////////////////////////////////////////////////////////////
	        Set<String> allWindows1=driver.getWindowHandles();
	        Iterator<String> it1=allWindows1.iterator();
	        String main1=it1.next();
	        String sub1=it1.next();
	        String sub2=it1.next(); 
            driver.switchTo().window(sub2);        
	        driver.manage().window().maximize();
	        driver.switchTo().defaultContent();
	        driver.switchTo().frame("contentFrame");
///////Select payment method////////////////////////////////////////////////////////////////////////////////
	       // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
	        driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
	        Actions act18=new Actions(driver);  
	        act18.sendKeys(Keys.TAB).build().perform();       
	        Thread.sleep(4000);
//////////////////selecting one payment type from that list/////////////////////////////////////////////////////////
	        driver.findElement(By.xpath("//tr[@id='129243788']")).click();
	        Thread.sleep(9000);  
	        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Save_&_Close']")), driver, "Save and close");
	        //driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
	        Thread.sleep(2000);    
	        System.out.println("Payment Instructions Updated");
	        driver.switchTo().window(sub1);    
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("childFrame");
	        Thread.sleep(5000);
	        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
	        
	        Thread.sleep(7000);   
	       // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
	        System.out.println("Created Schedule");   
	        driver.switchTo().defaultContent();        
	        driver.switchTo().frame("contentFrame");
	        //driver.switchTo().frame("closeModalPageFrame");
	        Thread.sleep(9000); 
	        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
//////// // driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
	        Thread.sleep(3000);
	        System.out.println("Window closed");	        
//////////////////////////////////////////////////////////////////////////////refresh page//////////////////////////////////////////////// 
	        Thread.sleep(2000);      
	        driver.switchTo().defaultContent();        
	        driver.switchTo().frame("contentFrame");
	        driver.switchTo().frame("innerFrame129");
	        Thread.sleep(4000);  
	        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
	       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
	        Thread.sleep(3000);    
	        System.out.println("Checking Payment Schedule");
  	   }     
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	         
	        /// Get lease id
	// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
       Thread.sleep(10000);
       driver.switchTo().defaultContent();
//	    driver.switchTo().frame("contentFrame");
//	    //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 

	      //xpath for general tab to get lease id
	    WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
	    TestClass.clickElement(Generaltab, driver, "General Tab");
	      // Generaltab.click();
	    System.out.println("entered into general tab");
////////// WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));//////////////////////
	    Thread.sleep(2000);
        driver.switchTo().frame("contentFrame");
        Thread.sleep(2000);
	    WebElement leaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
	   Thread.sleep(1000);
	   String Leaseid= leaseid.getText();
	   Thread.sleep(1000);
	   System.out.println("Lease id is " +Leaseid);   
//////Add code to go to option and clauses/////////////////////////////////////////////////////////////////////
	   Thread.sleep(1000);
	   driver.switchTo().defaultContent();
	   Thread.sleep(6000);
	   WebElement Optionancluases = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
	   TestClass.clickElement(Optionancluases, driver, "option and cluases");
	   System.out.println("Enter into option and clause section"); 
	   driver.switchTo().frame("contentFrame");
	   Thread.sleep(6000);
	   WebElement AddButton = driver.findElement(By.xpath("//div[@id='Add_38']//span[@class='actionButtonText']"));
	         
	   TestClass.clickElement(AddButton, driver, "Add option and cluases");
	   System.out.println("clicked on add button");
	   Thread.sleep(2000);
///////////////Type name of the clause//////////////////////////////////////////////////////////////////////
	   driver.switchTo().frame("childFrame");
	   driver.switchTo().frame("contentFrame");
	   Thread.sleep(6000);
	   WebElement ClauseName = driver.findElement(By.xpath("//input[@id='attr_seq_1002']"));
	   ClauseName.sendKeys("SBR clause");
	          
	   System.out.println("added clause name");
	   Thread.sleep(2000);
	   WebElement ClauseType = driver.findElement(By.xpath("//input[@id='attr_seq_1313']"));
	         
	   ClauseType.sendKeys("Variable Rent");
	         
	   System.out.println("added clause type");
	         
	   Actions act22=new Actions(driver);
	   act22.sendKeys(Keys.TAB).build().perform();
	   
	   JavascriptExecutor jse1=(JavascriptExecutor)driver;
       jse1.executeScript("window.scrollBy(0, 500)", "");
	         
	   WebElement FindClauses = driver.findElement(By.xpath("//div[@id='Find_16']//span[@class='actionButtonText']"));
	   FindClauses.click();      
	   //TestClass.clickElement(FindClauses, driver, "find clause");
	   System.out.println("clicked on find button");
	         
	         //List<WebElement>elements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
	         //System.out.println(elements.size()); 
	   Thread.sleep(5000);
	   driver.switchTo().defaultContent();
	   driver.switchTo().frame("contentFrame");
	   Thread.sleep(2000);
	   driver.switchTo().frame("childFrame");
	   driver.switchTo().frame("contentFrame");
	   Thread.sleep(2000);
	   System.out.println("inside content frame");
	   driver.switchTo().frame("childFrame");
	   Thread.sleep(3000);
	   driver.switchTo().frame("frameMain");
	   driver.switchTo().frame("contentFrame");
	         
	   List<WebElement>elements1 = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']"));
	   System.out.println("Size is " +elements1.size());
	         for(int j=0;j<elements1.size();j++)
	        {
	         	 Thread.sleep(2000);	 
	         	 WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//input[@name='sNo']")).get(j);
	         	 System.out.println(rowcount.getText());	
	         	 String  Text= rowcount.getText();
	         	 System.out.println(Text);
	         	 Thread.sleep(2000);
	         	 TestClass.clickElement(rowcount, driver, "click on rows");
	        }      
          System.out.println("payment scheduled linked");
	         
///////// /// ///// Click on OK button after selecting payment schedule///////////////////////////
	         
	         Thread.sleep(4000);   
	         WebElement OK=  driver.findElement(By.xpath("//table[@id='actionsTable']//tbody//span[@class='actionButtonText' and text()='OK']"));
	         TestClass.clickElement(OK, driver, "OK button");
	         
	         System.out.println("Clicked on ok");
 ///////////////select Billing frequency in variable rent set up//////////////////////////////////////////
	         
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
	         Thread.sleep(5000);
	         WebElement Frequencyselector = driver.findElement(By.xpath("//a[@id='attr_seq_1380_selector']"));
	         Frequencyselector.click();
	         driver.switchTo().frame("unMovableLayerFrame");
	         Thread.sleep(2000);
	         WebElement Billingfrequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
	         act.moveToElement(Billingfrequency);
	         Thread.sleep(1000);
	         Billingfrequency.click();
	         System.out.println("Selected Billing frequency as monthly in variable rent");
	        // WebElement Frequency = driver.findElement(By.xpath("//input[@id='attr_seq_1380']"));
	         
/////////////////////Typing First Reporting Period Start Date///////////////////////////////////////////////////
	         
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
	         Thread.sleep(3000);
	         WebElement firstReportingfrequency= driver.findElement(By.xpath("//input[@id='attr_seq_1252']"));
	         firstReportingfrequency.clear();
	         firstReportingfrequency.sendKeys("2/01/2019");
	         System.out.println("dates are selected");
	         	   
	         WebElement VariableRentSetup = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Variable Rent Setup']"));
	         
	         TestClass.clickElement(VariableRentSetup, driver, "click on Variable Rent setup");                //click to refresh
	       //  VariableRentSetup.click();
	         
/////////////write a code to click on create button /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	         
//	         driver.switchTo().defaultContent();
//		     driver.switchTo().frame("contentFrame");
//		     driver.switchTo().frame("childFrame");
//	         Thread.sleep(1000);
//		     WebElement Create =  driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Create']")); 
//		     Create.click();
//		     TestClass.clickElement(Create, driver, "click on create");
//		    System.out.println("Clicked on created");          	         
/////////////////go to Min Max tab///////////////////////////////////////////////////////////////////////////////////////////////////	         
		     driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame"); 
		    Thread.sleep(3000);
	        // WebElement MinMax = driver.findElement(By.xpath("//div[@id='sectionTabs44']"));
	         WebElement MinMax = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Min/Max']"));
	         
	         TestClass.clickElement(MinMax, driver, "MinMax tab");
	         System.out.println("Enter into min max tab");
//////////////////////// Click on Add button////////////////////////////////////////////////////////////////////////////
	         Thread.sleep(3000);
	         WebElement Add = driver.findElement(By.xpath("//div[@id='Add_82']//span[@class='actionButtonText']"));
	         TestClass.clickElement(Add, driver, "click on Add");
	         System.out.println("Clicked on add inside min/Max");
/////// enter effective date///////////////////////////////////////////////////////////////////////////
	         Thread.sleep(5000);
	         driver.switchTo().frame("innerFrame82");
	         System.out.println("inside inner frame");
	         Thread.sleep(8000);
//////  WebElement Effectivefrom = driver.findElement(By.xpath("//input[@id='fld_82_133687488_1080']")); 	
	         List<WebElement>  totalelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
	         System.out.println( "elemnets are " +totalelements.size());
	         
	      	 WebElement Effectivefrom = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(0);
	         
	       // WebElement Effectivefrom = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@id='fld_82_133689215_1080']"));		
	      	 Thread.sleep(4000);
	         Effectivefrom.sendKeys("01/01/2019");
	         //input[@id='fld_82_133689061_1080']
	         Thread.sleep(3000);
	         WebElement EffectiveTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(1);
	        // fld_82_133689061_1081
	         Thread.sleep(3000);
	         EffectiveTo.sendKeys("12/12/2019");
	         
	         Thread.sleep(3000);
	         WebElement MinAmount= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
	         
	         Thread.sleep(3000);
	         MinAmount.sendKeys("0");
	         Thread.sleep(3000);
	         
	         WebElement MaxAmount= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
	         MaxAmount.clear();
	         Thread.sleep(3000);
	         MaxAmount.sendKeys("3000");
	         Thread.sleep(3000);
	         TestClass.clickElement(MinAmount, driver, "click on Min amount");   // to rfersh amount after entering it
///////////Go to quantily based rules///////////////////////////////////////////////////////////////////////////	         
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
//////////////////////////////////////Enter into quantity based rules//////////////////////////////////   
	         WebElement Quatitybasedrules = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Quantity Based Rules']"));
	         
	         TestClass.clickElement(Quatitybasedrules, driver, "quantilty based rules");
	         
	         Thread.sleep(3000);
	         WebElement Add2 = driver.findElement(By.xpath("//div[@id='Add_78']//span[@class='actionButtonText']"));
	         TestClass.clickElement(Add2, driver, "click on Add");
	         System.out.println("Clicked on add button on quantity based rules");
	         Thread.sleep(7000);
	         
	         driver.switchTo().frame("innerFrame78");
	         WebElement salescatogeroyselctor = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//a[@title='Select Sales Category']"));
	         
	         TestClass.clickElement(salescatogeroyselctor, driver, "select sales catogery");
	        // salescatogeroyselctor.click();
	         
	         Thread.sleep(3000);
	         driver.switchTo().frame("unMovableLayerFrame");
	         WebElement Salescat=driver.findElement(By.xpath("//a//span[text()='Fuel - Petrol -All Grds']"));
	         TestClass.mouseOverOnElement(driver, Salescat, "petrol all grd");
	        // act.moveToElement(Pertrolallgrds);
	         TestClass.clickElement(Salescat, driver, "Click on pertol");
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("innerFrame78");
	         
	         List<WebElement>  ALLelements =  driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
	         
	         System.out.println(ALLelements.size());
	         
	         WebElement Effectivefrom1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
	         Thread.sleep(1000);
	         Effectivefrom1.sendKeys("01/01/2019");
	         
	         WebElement EffectiveTo1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
	         Thread.sleep(2000);
	         EffectiveTo1.sendKeys("12/12/2020");
	         
	         WebElement Quantityfrom= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(4);
	         
	         Quantityfrom.sendKeys("0");
	         Thread.sleep(1000);
	         WebElement QuantityTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(5);
	         Thread.sleep(1000);
	         QuantityTo.clear();
	         QuantityTo.sendKeys("1000");
	         
	         WebElement MinAmount1= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(6);
	         Thread.sleep(2000);
	         MinAmount1.clear();
	         Thread.sleep(1000);
	         MinAmount1.sendKeys("1000");
	         Thread.sleep(3000);
	         TestClass.clickElement(QuantityTo, driver, "to refresh the values"); // just to click on screen to refresh min amount value
	         
	         WebElement Multiplier= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(7);
	        
	         Multiplier.sendKeys("0.5");
	         
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
	         Thread.sleep(2000);
///////////////////////////////enter into value based Tab///////////////////////////////////////////////////////////////////////////
	         System.out.println("Enter into value based rules");
	         WebElement ValueBasedRue = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Value Based Rules']"));
	         
	         Thread.sleep(2000);
	         TestClass.clickElement(ValueBasedRue, driver, "Valued based rules screen");
	         
	         WebElement AddValuebasedRul = driver.findElement(By.xpath("//div[@id='Add_45']//span[@class='actionButtonText']"));
	         Thread.sleep(2000);
	 
	         TestClass.clickElement(AddValuebasedRul, driver, "add value based rules");  
/////////////////////////////////Select sales based catogory elements////////////////////////////////////////////////      
	         driver.switchTo().frame("innerFrame45");
	         Thread.sleep(2000);
	         WebElement salescatogeroyselctor1 = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//a[@title='Select Sales Category']"));
	         
	         TestClass.clickElement(salescatogeroyselctor1, driver, "sales catogery");
	         
	         driver.switchTo().frame("unMovableLayerFrame");
	         WebElement Salescat1=driver.findElement(By.xpath("//a//span[text()='Fuel - Petrol -All Grds']"));
	         TestClass.mouseOverOnElement(driver, Salescat1, "petrol all grd");
	         TestClass.clickElement(Salescat1, driver, "click on petrol sales grad");
	         
	         driver.switchTo().defaultContent();
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("childFrame");
	         driver.switchTo().frame("contentFrame");
	         driver.switchTo().frame("innerFrame45");
	         
             List<WebElement> ALLelementinsalesbased =  driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']"));
	         
	         System.out.println(ALLelementinsalesbased.size());
	         
	         WebElement Effectivefrom2= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(2);
	         Thread.sleep(1000);
	         Effectivefrom2.sendKeys("01/01/2019");
	         
	         WebElement EffectiveTo2= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(3);
	         Thread.sleep(1000);
	         EffectiveTo2.sendKeys("12/12/2019");  
	    
             WebElement Baseslesfrom= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(4);
	         
             Baseslesfrom.sendKeys("0");
	         Thread.sleep(1000);
	         
	         WebElement BaseslesTo= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(5);
	         Thread.sleep(1000);
	         BaseslesTo.clear();
	         BaseslesTo.sendKeys("1000");
	         
	         WebElement MinAmountvaluebasedrules= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//span[@class='bodyText']//input[@type='text']")).get(6);
	         
	         Thread.sleep(1000);
	         MinAmountvaluebasedrules.clear();
	         MinAmountvaluebasedrules.sendKeys("2000");
	         
/////////////////////////////////click on create clause///////////////////////////////////////////////////////////////////////////////////////
	       driver.switchTo().defaultContent();
	       driver.switchTo().frame("contentFrame");
	       driver.switchTo().frame("childFrame");
	         
	       WebElement Create =  driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Create']"));   
	       TestClass.clickElement(Create, driver, "click on create");
	         
	       WebElement Saveandclose = driver.findElement(By.xpath("//table[@id='tabActionTable']//div[@id='Save_&_Close']//span[@class='actionButtonText' and text()='Save & Close']")); 
	         
	      TestClass.clickElement(Saveandclose, driver, "save and close");     
	 
/////////////////////////////////////////submit lease/////////////////////////////////////////////////////
             driver.switchTo().defaultContent();
             TestClass.clickElement(driver.findElement(By.xpath("//span[text()='General']")), driver, "submit button");
        //driver.findElement(By.xpath("//span[text()='General']")).click();
             Thread.sleep(2000);    
             driver.switchTo().defaultContent();
             Thread.sleep(5000);
             TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Submit']")), driver, "Submit lease");
        //driver.findElement(By.xpath("//div[@id='Submit']")).click();
             Thread.sleep(5000);    
             System.out.println("Submit Lease Contract");      
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
         
//        Set<String> allWindowsN=driver.getWindowHandles();
//        Iterator<String> it1=allWindowsN.iterator();
//        String mainN=it1.next();
//        String subN=it1.next();
//        String sub2=it1.next();  
        driver.switchTo().window(main);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(2000);
        TestClass.clickElement( driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(2000);
        
        System.out.println("Activating the Contract");
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        // search by lease id not yby name correct it 
       // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys(ContractName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
        Actions act19=new Actions(driver);
        act19.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(4000);
        
        driver.switchTo().defaultContent();
        WebElement frm1=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
        driver.switchTo().frame(frm1);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(50000);
        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(9000);
        TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")), driver, "Click on draft accounting review");
       // driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")).click();
        Thread.sleep(4000);
///////// Click on activate the lease//////////////////////////////////////////////////////////////////////////
        Set<String> allWindows2=driver.getWindowHandles();
        Iterator<String> it2=allWindows2.iterator();
        String main2=it2.next();
        String sub3=it2.next();
        
        //System.out.println(main2);
        //System.out.println(sub3);
        
        driver.switchTo().window(sub3);                
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Activate']")), driver, "Activate lease");
       // driver.findElement(By.xpath("//div[@id='Activate']")).click();
        Thread.sleep(5000);
//////////////////////////////////////////////////////////////////////Validate status//////////////////////////////////////////////////////////////   
        driver.switchTo().window(main);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(frm);
        driver.switchTo().frame("objectsFrame");
        driver.switchTo().frame("listFrame");
        Thread.sleep(3000);
        TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
        //driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
        Thread.sleep(10000);
        driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
        Thread.sleep(7000);
        Actions act20=new Actions(driver);
        act20.sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(6000);
        List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
        Thread.sleep(2000);
        System.out.println(allelements.size()); 
        Thread.sleep(8000);	     
        for(int i=0;i<allelements.size();i++)
        {
        	 Thread.sleep(1000);	 
        	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
        	 System.out.println(Status.getText());	
        	 String  statustext= Status.getText();	
       if(statustext.equalsIgnoreCase("Active"))
    		   {
    			  System.out.println("Test is Passed,Lease is activated"); 
    		   }		 
    	else	 
    		  {
    			 System.out.println("Test is failed,Lease is not activated");
    		  }		
        }	 
    
 ///////Click on Lease id and validate and issue line items for SBR///////////////////////////////////////       
        
        WebElement Lease =driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(1);
        
        TestClass.clickElement(Lease, driver, "click on Lease id");
        System.out.println("Clicked on Lease id");
        
        Set<String> allWindows1=driver.getWindowHandles();
        System.out.println("Number of windows are"  +allWindows1);
        Iterator<String> itera=allWindows1.iterator();
        String mainwindow=itera.next();
        String subwindow=itera.next();
        System.out.println(mainwindow);
        System.out.println(subwindow);
        driver.switchTo().window(subwindow);
        
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        System.out.println("inside default frame");
        Thread.sleep(8000);
        WebElement  Optionancluases1 = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
      //WebElement Optionancluases = driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='Options & Clauses']"));
        Thread.sleep(2000);
        TestClass.clickElement(Optionancluases1, driver, "option and cluases");
        System.out.println("Enter into option and clause section"); 
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame38");
        
        WebElement  SBRclause= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(1);
        
        TestClass.clickElement(SBRclause, driver, "SBRclause");
        
        Set<String> allWindows3=driver.getWindowHandles();
        System.out.println("Number of windows are " +allWindows3.size());
        Iterator<String> itera1=allWindows3.iterator();
        String mainwindow1=itera1.next();
        String subwindow2=itera1.next();
        String subwindow3=itera1.next();
        System.out.println(mainwindow1);
        System.out.println(subwindow2);
        driver.switchTo().window(subwindow3);
        Thread.sleep(2000);
        driver.switchTo().frame("contentFrame");
        WebElement BillingTab = driver.findElement(By.xpath("//span[@class='x-tab-strip-text 'and text()='Billing']"));
        TestClass.clickElement(BillingTab, driver, "Inside billing tab"); 
        System.out.println("inside billing Tab");
      
////////////////////////Click on any of the entry to provide reported sales////////////////////////////////////////////////////////////////////
/////////////////// count the entries in billing tab and click on that///////////////////////////////////////////////////////////////////////
      Thread.sleep(4000);
      driver.switchTo().frame("innerFrame81");
      List<WebElement>Entiesinbillingtab= driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Due Date')]//a"));
        
      System.out.println("total Entries in billing tab are  " +Entiesinbillingtab.size());
      Thread.sleep(2000);
 for(int j=0;j<Entiesinbillingtab.size();j++)
     {
	    Thread.sleep(2000);
	    driver.switchTo().window(subwindow3);
	    driver.switchTo().defaultContent();
	    Thread.sleep(1000);
	    driver.switchTo().frame("contentFrame");
	    Thread.sleep(9000);
	    driver.switchTo().frame("innerFrame81");
	    System.out.println("Inside inner Frame81");
       	Thread.sleep(3000);	 
       	WebElement rowcount = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Due Date')]//a")).get(j);
       	System.out.println(rowcount.getText());	
       	String  Text= rowcount.getText();
       	System.out.println(Text);
       	Thread.sleep(3000);
       	TestClass.clickElement(rowcount, driver, "click on row");;
       	Set<String> allWindows4=driver.getWindowHandles();
        System.out.println("Number of windows are  " +allWindows4.size());
        Iterator<String> itera2=allWindows4.iterator();
        String mainwindows1=itera2.next();
        String subwindows2= itera2.next();
        String subwindows3= itera2.next();
        Thread.sleep(2000);
        String subwindows4=itera2.next();
        Thread.sleep(1000);
        System.out.println(mainwindows1);
        Thread.sleep(1000);
        System.out.println(subwindows2);
        driver.switchTo().window(subwindows4);
        Thread.sleep(2000);
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame20");
        WebElement reportedsales = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText' and contains(@aria-label,'Reporting From')]//a"));
        Thread.sleep(2000);
        TestClass.clickElement(reportedsales, driver, "reported sales");
        System.out.println("inside reported sales window");
        Set<String> allWindows5=driver.getWindowHandles();
        System.out.println("Number of windows are " +allWindows5.size());
        Iterator<String> itera3=allWindows5.iterator();
        String mainwindow51=itera3.next();
        String subwindows52=itera3.next();
        String subwindows53=itera3.next();
        String subwindows54=itera3.next();
        String subwindows55=itera3.next();
        System.out.println(mainwindow51);
        System.out.println(subwindows52);
        driver.switchTo().window(subwindows55);
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        Thread.sleep(1000);
        driver.switchTo().frame("innerFrame36");
        Thread.sleep(2000);
        
        WebElement reportedsalestextbox = driver.findElement(By.xpath("//table[@id='dataTab']//tbody//tr//td//span[@class='bodyText']//input[@type='text']"));
        
        reportedsalestextbox.sendKeys("1200");
        
        System.out.println("enter reported sales");
        
        Thread.sleep(1000);
        driver.switchTo().defaultContent();  //write to click on complete button
        
        WebElement closewindow = driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Complete']"));
        
        TestClass.clickElement(closewindow, driver, "  Complete");
        System.out.println(" enter reportes sales and closed wondow");
        Thread.sleep(1000);
        driver.switchTo().window(subwindows54);
   //// click on create estimate/////////////////////////////////////////////////////////////////     
        driver.switchTo().frame("contentFrame");
        WebElement Createestimate = driver.findElement(By.xpath("//div[@id='Create Estimate_26']//span[@class='actionButtonText']"));
        Thread.sleep(1000);
        TestClass.clickElement(Createestimate, driver, "Closereported sales window"); 
  
        System.out.println("Clicked on create estimate");
        Thread.sleep(2000);
        driver.switchTo().defaultContent(); 
        Thread.sleep(2000);
        
        WebElement Issue = driver.findElement(By.xpath("//span[@class='actionButtonText' and text()='Issue']"));        
       
/////////click on issue//////////////////////////////////////////////////////////////////////////////////////////////
        Thread.sleep(2000);
        Issue.click();
       // TestClass.clickElement(Issue, driver, "click on issue");
        
        System.out.println("  Clicked in issue");
        Thread.sleep(10000);
        
        System.out.println("window is closed");
       } 
       
 ////log out code
 
     int size = driver.findElements(By.tagName("iframe")).size();
 // driver.switchTo().frame(0);
     Thread.sleep(9000);
 //driver.switchTo().frame("loginMain");
     driver.switchTo().defaultContent();
     System.out.println(driver.getTitle());
	 waitTillPageLoad(driver, 30);
	 Thread.sleep(10000);
	 WebElement Logout = driver.findElement(By.xpath("//a[@id='auto-sign-out-button']"));
     TestClass.clickElement(Logout, driver, "Logout button");
     System.out.println(driver.getTitle());
       
//  WebElement statusforlineitem =driver.findElement(By.xpath("//span[@id='attr_seq_1007display']"));
//	if((statusforlineitem.getText()).equalsIgnoreCase("Draft"))
//       {
//	        Assert.fail("status of line item is not changed " + "\'" + (statusforlineitem.getText()).equalsIgnoreCase("Draft") + "\'");
//       }       
}









//Add payment schedule in existing lease which is not active
public static void addpaymentscheduleinlease(String filepath, String sheetname, String testcaseID)throws Exception
{

TestClass.Createdraftlease("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_12");
Thread.sleep(3000); 

/////////////////////////////////// write code to get lease id search and add payment schedule////////////////////////////////////////////////////////////////
Thread.sleep(6000);
driver.switchTo().defaultContent();
Set<String> allWindows=driver.getWindowHandles();
Iterator<String> it=allWindows.iterator();
String main=it.next();
String sub=it.next();
System.out.println(main);
System.out.println(sub);
driver.switchTo().window(sub);
driver.manage().window().maximize();
driver.switchTo().frame("contentFrame");

///////////////adding payment schedule in the created draft lease/////////////////////////////////////////////////////////////////
System.out.println("Creating a Payment Schedule");

driver.switchTo().defaultContent();
Thread.sleep(10000);
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
//driver.findElement(By.xpath("//span[text()='Payments']")).click();
Thread.sleep(6000);
driver.switchTo().frame("contentFrame");
Thread.sleep(9000);
TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")), driver, "Generate payment schedule");
//driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
Thread.sleep(6000);
driver.switchTo().frame("childFrame");
Thread.sleep(4000);
driver.switchTo().frame("contentFrame");
// driver.findElement(By.id("attr_seq_1086_selector")).click();
Thread.sleep(3000);
//  driver.switchTo().frame("unMovableLayerFrame");   //removed
Thread.sleep(20000);
// WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']")); //added
//WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
TestClass.Typepaymenttype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
Thread.sleep(7000);
Actions act13=new Actions(driver);
//Thread.sleep(7000);
//act13.sendKeys(Keys.TAB).build().perform();
//Thread.sleep(7000);
act13.sendKeys(Keys.ENTER).build().perform();
// act.moveToElement(paymentType);
Thread.sleep(10000);
// paymentType.click();
Thread.sleep(5000);
System.out.println("Payment Type Selected");

////////////////////////////////////////////Invoice Type Selected /////////////////////////////////////////////////////      
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("childFrame");
driver.switchTo().frame("contentFrame");
Thread.sleep(6000);
TestClass.Typeinvoicetype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");

// driver.findElement(By.id("attr_seq_1166_selector")).click();
Thread.sleep(5000);
Actions act14=new Actions(driver);
act14.sendKeys(Keys.ENTER).build().perform();
//Removed code
//driver.switchTo().frame("unMovableLayerFrame");
//Thread.sleep(4000); 
//WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//act.moveToElement(invoiceType);
//invoiceType.click();
  System.out.println("Invoice Type Selected"); 
/////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    
 //driver.findElement(By.id("attr_seq_1126_selector")).click();
    Thread.sleep(3000);
// Removed //  driver.switchTo().frame("unMovableLayerFrame");
    Thread.sleep(1000);
    TestClass.Typefrequency("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
   // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
 //   frequency.sendKeys("Monthly");
    Actions act15=new Actions(driver);
    act15.sendKeys(Keys.ENTER).build().perform();
  // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
  // act.moveToElement(frequency);
  // frequency.click();
    System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(5000);
    TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
   // driver.findElement(By.id("attr_seq_1134_selector")).click();
   driver.switchTo().frame("unMovableLayerFrame");
  //  driver.findElement(By.id("attr_seq_1105")).clear();
   // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
    Thread.sleep(6000);
    TestClass.Typepaymentdueon("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
    WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
   // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
   // paymentDueOn.sendKeys("First Day of Period");
    Actions act16=new Actions(driver);
    act16.sendKeys(Keys.ENTER).build().perform();
    act16.moveToElement(paymentDueOn);
    TestClass.clickElement(paymentDueOn, driver, "payment due on");
   // paymentDueOn.click();
    System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
////selecting full payment start date///////////////////////////////////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
    Thread.sleep(6000);
    TestClass.Typefullpaymentstartdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
////// driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");///////////
    System.out.println("Full Payment Start Date Selected");
/////////////////////////////////////////Selecting number of Number of Schedules Entered///////////////////////////////  
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(9000);
    driver.findElement(By.id("attr_seq_1105")).clear();
    Thread.sleep(5000);
    TestClass.TypeNumberofschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
/////// driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");/////////////////
   // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
    System.out.println("Number of Schedules Entered");
//////////Months per schedules//////////////////////////////////////////////////////////////////////////////////////
    driver.findElement(By.id("attr_seq_1103")).clear();
    Thread.sleep(5000);
////driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
    TestClass.TypeMonthsperschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
    System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered////////////////////////////////////////////////////////////////////////        
    JavascriptExecutor jse1=(JavascriptExecutor)driver;
    jse1.executeScript("window.scrollBy(0, 500)", "");
    Thread.sleep(5000);
    driver.findElement(By.id("attr_seq_1100")).clear();
    TestClass.TypeAmountperBasis("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
    //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
    System.out.println("Amount Per Basis entered");    
//////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////
    System.out.println("Finding Cost code");
    TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")), driver, "click");
/////driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("frameMain");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(5000);
    TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "cost code");
   // driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
    TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "select cost code");
   // driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
    System.out.println("cost code Selected");   
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
    System.out.println("Adding Tax Group");
    //JavascriptExecutor jse1=(JavascriptExecutor)driver;
   // jse1.executeScript("window.scrollBy(0, 500)", "");
    Thread.sleep(4000);
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    TestClass.Typetaxgroup("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_13");
   // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
    Actions act17=new Actions(driver);
    Thread.sleep(4000);
    act17.sendKeys(Keys.TAB).build().perform();
    Thread.sleep(4000);
    System.out.println("Tax Group is Added");  
    
////Generate payment schedule/////////////////////////////////////////////////////////////////////////////////
    
    System.out.println("Generating payment Schedule");
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
   // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
    Thread.sleep(3000);
    System.out.println("Payment Schedules Generated");
/////Update payment instructions//////////////////////////////////////////////////////////////////////////////////////
    
  //System.out.println("Payment Instruction");
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("innerFrame7");
    Thread.sleep(10000); 
    TestClass.clickElement(driver.findElement(By.xpath("//a[@title='YC00']")), driver, "Generate payment schedule");
  //  driver.findElement(By.xpath("//a[@title='YC00']")).click();
    
    Thread.sleep(4000);
    System.out.println("Updating Payment Instructions");

    driver.switchTo().defaultContent();
    //find all windows list and switch on that
    Set<String> allWindows1=driver.getWindowHandles();
    Iterator<String> it1=allWindows1.iterator();
    String main1=it1.next();
    String sub1=it1.next();
    String sub2=it1.next();
    
    driver.switchTo().window(sub2);        
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    ///Select payment method////
   // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
    driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
    Actions act18=new Actions(driver);
    
    act18.sendKeys(Keys.TAB).build().perform();       
    Thread.sleep(4000);
    //selecting one payment type from that list
    TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='129243788']")), driver, "click E");
    //driver.findElement(By.xpath("//tr[@id='129243788']")).click();
    Thread.sleep(9000);   
    TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Save_&_Close']")), driver, "click");
   // driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
    Thread.sleep(2000);    
    System.out.println("Payment Instructions Updated");
    driver.switchTo().window(sub1);    
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
   // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
    System.out.println("Created Schedule");
    Thread.sleep(5000);    
    
    driver.switchTo().defaultContent();        
    driver.switchTo().frame("contentFrame");
    //driver.switchTo().frame("closeModalPageFrame");
   TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
   // driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
    Thread.sleep(5000);
    System.out.println("Window closed");
    
////////////////////////////////////////////////////////////////////////////////refresh page///////////////////////////////////// 
    Thread.sleep(3000);      
    driver.switchTo().defaultContent();        
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("innerFrame129");
    Thread.sleep(2000);  
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
   // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(2000);    
    System.out.println("Checking Payment Schedule");


}

///expenseLease creation
public static void LeaseCreation(String filepath, String sheetname, String testcaseID)throws Exception
{

TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
Thread.sleep(30000); 
//click on all contracts
TestClass.clickElement(driver.findElement(By.xpath("//*[@id='large-quick-link-4312']")), driver, "All contacts");
///click on add button
Thread.sleep(30000);
WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
driver.switchTo().frame(frm);
driver.switchTo().frame("objectsFrame");
Thread.sleep(30000);
// click on add contract
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Add']")), driver, "Add contract");

//find all windows list and switch on that//////////////////////////////////////////////////////////////
Set<String> allWindows=driver.getWindowHandles();
Iterator<String> it=allWindows.iterator();
String main=it.next();
String sub=it.next();
System.out.println(main);
System.out.println(sub);
driver.switchTo().window(sub);
driver.manage().window().maximize();
driver.switchTo().frame("contentFrame");

//Generating Random Contract Name
// Random ranGenerator=new Random();
// Integer RanNumber=ranGenerator.nextInt(100);    
//String ContractName="Lease "+RanNumber;
TestClass.TypeLeaseName("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
TestClass.TypeLeaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02"); 

Thread.sleep(20000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "secondary Lease Type");

Thread.sleep(9000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")), driver, "selector");
//driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
// driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();

//WebDriverWait wait = new WebDriverWait(driver,90);
// WebElement lease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='large-quick-link-4312']")));
Thread.sleep(30000);

driver.switchTo().frame("unMovableLayerFrame");

//type secondary lease  recheck this one more time creating issue while execution
TestClass.TypesecondaryleaseType("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
Thread.sleep(5000);
Actions act = new Actions(driver);
act.moveToElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")));
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Landlord Lease']")), driver, "secondary lease");
Thread.sleep(5000);

///////////////////// Type Contract status as 'Active'///////////////////////////////////////////////

driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")), driver, "Status");
// driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
Thread.sleep(3000);
driver.switchTo().frame("unMovableLayerFrame");
Thread.sleep(5000);
TestClass.Typecontractstatus("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Active']")), driver, " status");

// WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
//act.moveToElement(active);
//active.click();
//Dates
// Lease CommencementDate
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame"); 
Thread.sleep(90000);
TestClass.TypeCommencementDate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
// driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

// Lease Expiration Date
TestClass.TypeExpirationdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
//driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("01/01/2018");

//Business unit
Thread.sleep(2000);
JavascriptExecutor jse=(JavascriptExecutor)driver;
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
TestClass.TypeBusinessunit("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
Actions act1=new Actions(driver);
Thread.sleep(7000);
act1.sendKeys(Keys.TAB).build().perform(); ///representation of the pressable keys
Thread.sleep(4000);

// Go to contact details page// 
driver.switchTo().defaultContent();
TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
// driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
Thread.sleep(2000);
driver.switchTo().defaultContent();
    
// click on data central hub ///////////////////////////////////////  
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")), driver, " data Central Hub"); 
// driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click();
String contactsWindow = driver.getWindowHandle();
Set<String> winHandleBefore = driver.getWindowHandles();
// Perform the click operation that opens new window
// Switch to new window opened 
for(String winHandle : winHandleBefore)
{
   driver.switchTo().window(winHandle);
}        
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, " find data cenral hub"); 

// driver.findElement(By.id("Find_3")).click();
Thread.sleep(1000);
driver.switchTo().frame("childFrame");
Thread.sleep(1000);
driver.switchTo().frame("frameMain");
Thread.sleep(2000);
driver.switchTo().frame("contentFrame");

//  driver.findElement(By.id("repSubList")).sendKeys("All People");
// driver.switchTo().frame("childFrame");
//Thread.sleep(1000);
// driver.switchTo().frame("frameMain");
// Thread.sleep(1000);
//driver.switchTo().frame("contentFrame");  
Thread.sleep(5000); 
//New code added for selecting all roles 
//table[@id='subRepLayerTable']//span[@class='bodyText']

TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click on image");

//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  

Thread.sleep(2000);
///// click on All people link////////////////////
WebElement clicksecondelement =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	 add.click();
//
Actions act2 = new Actions(driver);  
System.out.println(clicksecondelement.getText());
act2.moveToElement(clicksecondelement);
Thread.sleep(10000);
clicksecondelement.click();

//// ////selecting DCH user  Rekha//////////////////////////////////////////////////////////////////////////////////

WebElement DCHUSER =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypeDCHUSERNAME("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");

Thread.sleep(9000);
Actions act3=new Actions(driver);
act3.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);
//////// act2.sendKeys(Keys.TAB).build().perform()//////////////////////
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")), driver, "radio button");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_0']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "OK");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Data Central Validate");  

///----------------------------------------------------------------------------------------------------------------------------------------------  
////Portfolio Administrator selection////////////////////////////////////////
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")), driver, "Portfolio Administrator");
// driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();
Set<String> winHandleBefore1 = driver.getWindowHandles();
for(String winHandle1 : winHandleBefore1)
{
      driver.switchTo().window(winHandle1);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(9000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "Click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl1 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl.size());  

Thread.sleep(2000);
//click on All people link
WebElement clicksecondelement1 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//add.click();

Actions act4 = new Actions(driver);  
System.out.println(clicksecondelement1.getText());
act4.moveToElement(clicksecondelement1);
Thread.sleep(10000);
TestClass.clickElement(clicksecondelement1, driver, "select All");
//clicksecondelement1.click();

///////////selecting PA user  Rekha//////////////////////////////////////////////////////////////////////////////
WebElement PA =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePA("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");

Thread.sleep(9000);
Actions act5=new Actions(driver);
act5.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(3000);

TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "Click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(3000);
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator");   
//
///-------------------------------------------------------------------------------------------------------------------------------------
/// //  User Selected for Portfolio Administrator  - Validate///////////////////////////////
driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")), driver, "select PA");
//driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
System.out.println("Clicked on Portfolio Administrator  - Validate");

Set<String> winHandleBefore2 = driver.getWindowHandles();
for(String winHandle2 : winHandleBefore2){
     driver.switchTo().window(winHandle2);
  }    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(7000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");
TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl3 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl3.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement2 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
// add.click();

Actions act6 = new Actions(driver);  
System.out.println(clicksecondelement2.getText());
act6.moveToElement(clicksecondelement2);
Thread.sleep(10000);
TestClass.clickElement(clicksecondelement2, driver, "Second role");
//clicksecondelement2.click();

//////selecting PAvalidate user  Rekha////////////////////////////////////////////////////////////////////////////////////////////

WebElement PAvalidate =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePAValidate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");

Thread.sleep(9000);
Actions act7=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")), driver, "radio");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_2']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
TestClass.clickElement(driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")), driver, "click");
//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("xBtn")), driver, "X");
//driver.findElement(By.id("xBtn")).click();
System.out.println("User Selected for Portfolio Administrator  - Validate");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Property Manager Selection

driver.switchTo().window(contactsWindow);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
driver.switchTo().frame("innerFrame87");
Thread.sleep(9000);
TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Property Manager']")), driver, "property manager");
//driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
System.out.println("Clicked on Property Manager");
//
Set<String> winHandleBefore3 = driver.getWindowHandles();
for(String winHandle3 : winHandleBefore3)
{
   driver.switchTo().window(winHandle3);
}    
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
Thread.sleep(5000);
TestClass.clickElement(driver.findElement(By.id("Find_3")), driver, "find");
//driver.findElement(By.id("Find_3")).click();
Thread.sleep(5000);
driver.switchTo().frame("childFrame");
driver.switchTo().frame("frameMain");
driver.switchTo().frame("contentFrame");

TestClass.clickElement(driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")), driver, "click");
//driver.findElement(By.xpath("//img[@src='/getCompanyFile.jsp?fileLoc=//images/icons/list-drop-down.png']")).click();
Thread.sleep(5000);

List<WebElement> Allppl4 = driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']"));
Thread.sleep(2000);
System.out.println(Allppl4.size());  

Thread.sleep(2000);
// click on All people link
WebElement clicksecondelement3 =driver.findElements(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1);
//WebElement add = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='subRepLayerTable']//span[@class='bodyText']")).get(1));
//	add.click();

Actions act8= new Actions(driver);  
System.out.println(clicksecondelement3.getText());
act8.moveToElement(clicksecondelement3);
Thread.sleep(10000);
TestClass.clickElement(clicksecondelement3, driver, "click");
//clicksecondelement3.click();
WebElement PM =  driver.findElement(By.xpath("//input[@name='filterValue4']"));  
TestClass.TypePM("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");

Thread.sleep(9000);
Actions act9=new Actions(driver);
act7.sendKeys(Keys.ENTER).build().perform(); ///representation of the pressable keys
Thread.sleep(2000);

TestClass.clickElement(driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")), driver, "click");
//driver.findElement(By.xpath("//tr[@id='queryResultRow_3']//input[@type='radio' and @name='sNo']")).click();
Thread.sleep(2000);  

driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
Thread.sleep(9000);
driver.findElement(By.id("xBtn")).click();
System.out.println("Property Manager Selected");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Tenant organization DE01 selection
Thread.sleep(1000);
driver.switchTo().window(contactsWindow); 
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");        
//driver.findElement(By.id("attr_seq_1916_selector")).click(); 
Thread.sleep(4000);
TestClass.TypeTenant("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
// driver.findElement(By.xpath("//input[@type='text'and @id='attr_seq_1916']")).sendKeys("DE01");
Actions act10=new Actions(driver);
act10.sendKeys(Keys.TAB).build().perform();
// act1.sendKeys(Keys.TAB).build().perform()
//driver.switchTo().frame("childFrame");
//driver.switchTo().frame("frameMain"); 
//driver.switchTo().frame("contentFrame");
System.out.println("Tenant Organization Selected");
Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Landlord Organization Lookup selection
jse.executeScript("window.scrollBy(0, 500)", "");
Thread.sleep(4000);
driver.switchTo().defaultContent();
driver.switchTo().frame("contentFrame");
// driver.findElement(By.id("attr_seq_1934_selector")).click();
Thread.sleep(7000);
TestClass.TypeLandlord("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
// WebElement LandlordOrganisationLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1934']"));
Thread.sleep(7000);
// LandlordOrganisationLookup.sendKeys("68031057");
Actions act11=new Actions(driver);
Thread.sleep(7000);
act11.sendKeys(Keys.TAB).build().perform();
Thread.sleep(7000);
act11.sendKeys(Keys.ENTER).build().perform();
Thread.sleep(2000);
System.out.println("Landlord Organization Selected");

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  jse.executeScript("window.scrollBy(0, 500)", "");
  Thread.sleep(4000);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Remit to 
  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  //driver.findElement(By.id("attr_seq_1987_selector")).click();
  Thread.sleep(5000);
  TestClass.TypeRemitTo("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
  //WebElement RemitToLookup=driver.findElement(By.xpath("//input[@name='attr_seq_1987']"));
 // Thread.sleep(5000);
 // RemitToLookup.sendKeys("68031057");
  Thread.sleep(6000);
  Actions act12=new Actions(driver);
  Thread.sleep(7000);
  act12.sendKeys(Keys.TAB).build().perform();
	  System.out.println("Remit Organization Selected");
	 
///////////////////////////////Click on crate draft/////////////////////////////////////////////////////////////////////////////////////////////  
	 
  driver.switchTo().defaultContent();
  Thread.sleep(6000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Create Draft']")), driver, "create draft");
  System.out.println("Created draft");

////////--Click on location----------------------------------------------------------------------------------------------------------------
  
  Thread.sleep(9000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Locations']")), driver, "location tab");
/////-driver.findElement(By.xpath("//span[text()='Locations']")).click();
  
//// / / /////////////// select location ////////////////////////////////////////////////////////////////////////////////////////////////////
  
  JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
  scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
  
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  TestClass.clickElement(driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")), driver, "Find button");
 // driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
  Thread.sleep(5000);
  driver.switchTo().frame("childFrame");
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  TestClass.clickElement(driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")), driver, "check box");
  //driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  ////System.out.println("Primary Location Selected");

  driver.switchTo().defaultContent();
  driver.switchTo().frame("contentFrame");
  Thread.sleep(5000);
  driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
  Thread.sleep(3000);
  driver.switchTo().frame("childFrame");
  Thread.sleep(1000);
  driver.switchTo().frame("frameMain");
  driver.switchTo().frame("contentFrame");
  driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
  driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
  System.out.println("Primary Location Selected");
//// /////// Click on save//////////////////////////////////////////////////////////////////////////////////////////
	   Thread.sleep(6000);      
	   driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();
  
////////Add payment schedule////////////////////////////////////////////////////////////////////////////////////

	System.out.println("Creating a Payment Schedule");
    
    driver.switchTo().defaultContent();
    Thread.sleep(10000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Payments']")), driver, "Payments");
    //driver.findElement(By.xpath("//span[text()='Payments']")).click();
    Thread.sleep(6000);
    driver.switchTo().frame("contentFrame");
    Thread.sleep(9000);
    driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
    Thread.sleep(4000);
    driver.switchTo().frame("childFrame");
    Thread.sleep(4000);
    driver.switchTo().frame("contentFrame");
    
   // driver.findElement(By.id("attr_seq_1086_selector")).click();
    Thread.sleep(3000);
  //  driver.switchTo().frame("unMovableLayerFrame");   //removed
    Thread.sleep(20000);
   // WebElement paymentType=driver.findElement(By.xpath("//input[@id='attr_seq_1086']")); //added
   //WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association[PAY][NI]']"));
  
   
    TestClass.Typepaymenttype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
    Thread.sleep(7000);
    Actions act13=new Actions(driver);
//    Thread.sleep(7000);
//    act13.sendKeys(Keys.TAB).build().perform();
//    Thread.sleep(7000);
    act13.sendKeys(Keys.ENTER).build().perform();
   // act.moveToElement(paymentType);
    Thread.sleep(10000);
   // paymentType.click();
    Thread.sleep(5000);
    System.out.println("Payment Type Selected");
    
////////////////////////////////////////////Invoice Type Selected /////////////////////////////////////////////////////      
    driver.switchTo().defaultContent();
    driver.switchTo().frame("contentFrame");
    driver.switchTo().frame("childFrame");
    driver.switchTo().frame("contentFrame");
    Thread.sleep(6000);
    TestClass.Typeinvoicetype("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
    
  // driver.findElement(By.id("attr_seq_1166_selector")).click();
    Thread.sleep(5000);
    Actions act14=new Actions(driver);
    act14.sendKeys(Keys.ENTER).build().perform();
    //Removed code
//    driver.switchTo().frame("unMovableLayerFrame");
//    Thread.sleep(4000); 
//    WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'LANDLORD1')]"));
//    act.moveToElement(invoiceType);
//    invoiceType.click();
      System.out.println("Invoice Type Selected"); 
////////////////--------Selecting Frequency----------------------------//////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        
     //driver.findElement(By.id("attr_seq_1126_selector")).click();
        Thread.sleep(3000);
    // Removed //  driver.switchTo().frame("unMovableLayerFrame");
        Thread.sleep(1000);
        TestClass.Typefrequency("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
       // WebElement frequency=driver.findElement(By.xpath("//input[@id='attr_seq_1126']"));
     //   frequency.sendKeys("Monthly");
        Actions act15=new Actions(driver);
        act15.sendKeys(Keys.ENTER).build().perform();
      // WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
      // act.moveToElement(frequency);
      // frequency.click();
        System.out.println("Frequency Selected");             
//////////////////////////////////////Selecting payment due date////////////////////////////////////////////////////////////////	    
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        TestClass.clickElement(driver.findElement(By.id("attr_seq_1134_selector")), driver, "Payment due on");
       // driver.findElement(By.id("attr_seq_1134_selector")).click();
       driver.switchTo().frame("unMovableLayerFrame");
      //  driver.findElement(By.id("attr_seq_1105")).clear();
       // driver.findElement(By.xpath("//input[@id='attr_seq_1134']")).clear();
        Thread.sleep(6000);
        TestClass.Typepaymentdueon("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
       // WebElement paymentDueOn=driver.findElement(By.xpath("//input[@id='attr_seq_1134']"));
       // paymentDueOn.sendKeys("First Day of Period");
        Actions act16=new Actions(driver);
        act16.sendKeys(Keys.ENTER).build().perform();
        act.moveToElement(paymentDueOn);
        TestClass.clickElement(paymentDueOn, driver, "payment due on");
       // paymentDueOn.click();
        System.out.println("Payment Due Selected");	  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
////selecting full payment start date///////////////////////////////////////////////////////////////////////////////
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        
//removed // driver.findElement(By.id("attr_seq_1133_selector")).click();        
//removed // driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
        Thread.sleep(6000);
        TestClass.Typefullpaymentstartdate("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1133']")).sendKeys("01/01/2019");
        System.out.println("Full Payment Start Date Selected");
///////////////////////////////////////Selecting number of Number of Schedules Entered///////////////////////////////  
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(9000);
        driver.findElement(By.id("attr_seq_1105")).clear();
        Thread.sleep(5000);
        TestClass.TypeNumberofschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
       // driver.findElement(By.xpath("//input[@id='attr_seq_1105']")).sendKeys("12");
       // old code driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
        System.out.println("Number of Schedules Entered");
//////////Months per schedules//////////////////////////////////////////////////////////////////////////////////////
        driver.findElement(By.id("attr_seq_1103")).clear();
        Thread.sleep(5000);
        //driver.findElement(By.id("attr_seq_1103")).sendKeys("1");
        TestClass.TypeMonthsperschedules("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        System.out.println("Months per Schedule Entered");
///////////////// Amount Per Basis enterered////////////////////////////////////////////////////////////////////////        
        JavascriptExecutor jse1=(JavascriptExecutor)driver;
        jse1.executeScript("window.scrollBy(0, 500)", "");
        Thread.sleep(4000);
        
        Thread.sleep(5000);
        driver.findElement(By.id("attr_seq_1100")).clear();
        TestClass.TypeAmountperBasis("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        //driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
        System.out.println("Amount Per Basis entered");
        
////////////////////////////////////////Cost code--------////////////////////////////////////////////////////////////////////////  
        System.out.println("Finding Cost code");
        driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("frameMain");
        driver.switchTo().frame("contentFrame");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
        driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
        System.out.println("cost code Selected");  
/////////////////Adding Tax///////////////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("Adding Tax Group");
        //JavascriptExecutor jse1=(JavascriptExecutor)driver;
        //jse1.executeScript("window.scrollBy(0, 500)", "");
        //Thread.sleep(4000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.Typetaxgroup("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
       // driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");
        Actions act17=new Actions(driver);
        Thread.sleep(4000);
        act17.sendKeys(Keys.TAB).build().perform();
        Thread.sleep(4000);
        System.out.println("Tax Group is Added");  
        
////Generate payment schedule/////////////////////////////////////////////////////////////////////////////////
        
        System.out.println("Generating payment Schedule");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        TestClass.clickElement(driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")), driver, "Generate payment schedule");
       // driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
        Thread.sleep(3000);
        System.out.println("Payment Schedules Generated");
//Update payment instructions//////////////////////////////////////////////////////////////////////////////////////
        
      //System.out.println("Payment Instruction");
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame7");
        Thread.sleep(10000); 
        TestClass.clickElement(driver.findElement(By.xpath("//a[@title='YC00']")), driver, "Generate payment schedule");
      //  driver.findElement(By.xpath("//a[@title='YC00']")).click();
        
        Thread.sleep(4000);
        System.out.println("Updating Payment Instructions");
    
        driver.switchTo().defaultContent();
        //find all windows list and switch on that
        Set<String> allWindows1=driver.getWindowHandles();
        Iterator<String> it1=allWindows1.iterator();
        String main1=it1.next();
        String sub1=it1.next();
        String sub2=it1.next();
        
        driver.switchTo().window(sub2);        
        driver.manage().window().maximize();
        
        driver.switchTo().defaultContent();
        driver.switchTo().frame("contentFrame");
        ///Select payment method////
       // TestClass.TypePaymentMethod("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_02");
        driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
        Actions act18=new Actions(driver);
        
        act18.sendKeys(Keys.TAB).build().perform();       
        Thread.sleep(4000);
        //selecting one payment type from that list
        driver.findElement(By.xpath("//tr[@id='129243788']")).click();
        Thread.sleep(9000);   
        driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
        Thread.sleep(2000);    
        System.out.println("Payment Instructions Updated");
        driver.switchTo().window(sub1);    
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("childFrame");
        TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")), driver, "Create schedule");
       // driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
        System.out.println("Created Schedule");
        Thread.sleep(5000);    
        
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        //driver.switchTo().frame("closeModalPageFrame");
       TestClass.clickElement(driver.findElement(By.xpath("//a[@id='childLayerCloseX']")), driver, "closeX");
       // driver.findElement(By.xpath("//a[@id='childLayerCloseX']")).click();
        Thread.sleep(5000);
        System.out.println("Window closed");	        
//////////////////////////////////////////////////////////////////////////////refresh page///////////////////////////////////// 
        Thread.sleep(3000);      
        driver.switchTo().defaultContent();        
        driver.switchTo().frame("contentFrame");
        driver.switchTo().frame("innerFrame129");
        Thread.sleep(2000);  
        TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh button");
       // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
        Thread.sleep(2000);    
        System.out.println("Checking Payment Schedule");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        /// Get lease id
// TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
   Thread.sleep(60000);
   driver.switchTo().defaultContent();
//     driver.switchTo().frame("contentFrame");
//    //TestClass.clickElement(driver.findElement(By.xpath("//span[text()='Contact Details']")), driver, " contact details"); 
//      Thread.sleep(9000);
      //xpath for general tab to get lease id
       WebElement Generaltab =  driver.findElement(By.xpath("//span[@class='x-tab-strip-text ' and text()='General']"));
       TestClass.clickElement(Generaltab, driver, "General Tab");
      // Generaltab.click();
       System.out.println("entered into general tab");
//////////WebElement leaseid=driver.findElement(By.xpath("//span[@id='objectPageTitle']"));

       Thread.sleep(9000);
       driver.switchTo().frame("contentFrame");
       Thread.sleep(9000);
         WebElement leaseid =driver.findElement(By.xpath("//span[@id='attr_seq_2381']"));
         Thread.sleep(9000);
        String Leaseid= leaseid.getText();
         Thread.sleep(9000);
         System.out.println("Lease id is" +Leaseid);   
        
/////////////////////////////////////////submit lease/////////////////////////////////////////////////////
    driver.switchTo().defaultContent();
    TestClass.clickElement(driver.findElement(By.xpath("//span[text()='General']")), driver, "submit button");
    //driver.findElement(By.xpath("//span[text()='General']")).click();
    Thread.sleep(2000);    
    driver.switchTo().defaultContent();
    Thread.sleep(5000);
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Submit']")), driver, "Submit lease");
    //driver.findElement(By.xpath("//div[@id='Submit']")).click();
    Thread.sleep(5000);    
    System.out.println("Submit Lease Contract");      
////////////////////////////////////////////////////////////////////////////////////////////////////////////////      
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "refresh");
    //driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(2000);
    
    System.out.println("Activating the Contract");
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    // search by lease id not yby name correct it 
   // driver.findElement(By.xpath("//input[@id='filterValue1']")).sendKeys(ContractName);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Actions act19=new Actions(driver);
    act19.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(4000);
    
    driver.switchTo().defaultContent();
    WebElement frm1=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
    driver.switchTo().frame(frm1);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(50000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[@id='refreshIcon']")), driver, "Refresh");
   // driver.findElement(By.xpath("//a[@id='refreshIcon']")).click();
    Thread.sleep(9000);
    TestClass.clickElement(driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")), driver, "Click on draft accounting review");
   // driver.findElement(By.xpath("//a[text()='Draft Accounting In Review']")).click();
    Thread.sleep(4000);
///////// Click on activate the lease//////////////////////////////////////////////////////////////////////////
    Set<String> allWindows2=driver.getWindowHandles();
    Iterator<String> it2=allWindows2.iterator();
    String main2=it2.next();
    String sub3=it2.next();
    
    //System.out.println(main2);
    //System.out.println(sub3);
    
    driver.switchTo().window(sub3);                
    driver.manage().window().maximize();
    
    driver.switchTo().defaultContent();
    TestClass.clickElement( driver.findElement(By.xpath("//div[@id='Activate']")), driver, "Activate lease");
   // driver.findElement(By.xpath("//div[@id='Activate']")).click();
    Thread.sleep(5000);
////////////////////////////////////////////////////////////////////////Validate status////////////////////////////   
    driver.switchTo().window(main1);
    driver.switchTo().defaultContent();
    driver.switchTo().frame(frm);
    driver.switchTo().frame("objectsFrame");
    driver.switchTo().frame("listFrame");
    Thread.sleep(3000);
    TestClass.clickElement(driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")), driver, "Clear filerts");
    //driver.findElement(By.xpath("//span[@class='tririgaResultsActionButton' and text()='Clear Filters']")).click();
    Thread.sleep(9000);
    driver.findElement(By.xpath("//input[@id='filterValue0']")).sendKeys(Leaseid);
    Thread.sleep(7000);
    Actions act20=new Actions(driver);
    act20.sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(6000);
    List<WebElement>allelements = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a"));
    Thread.sleep(2000);
    System.out.println(allelements.size()); 
    Thread.sleep(9000);	     
    for(int i=0;i<allelements.size();i++)
    {
    	 Thread.sleep(7000);	 
    	 WebElement Status = driver.findElements(By.xpath("//table[@id='dataTab']//tbody//tr[@id='queryResultRow_0']//span[@class='bodyText']//a")).get(i);
    	 System.out.println(Status.getText());	
    	 String  statustext= Status.getText();
    	
   if(statustext.equalsIgnoreCase("Active"))
		   {
			  System.out.println("Test is Passed,Lease is activated"); 
		   }		 
	else	 
		  {
			 System.out.println("Test is failed,Lease is not activated");
		  }		
    }	 

}

/*
 * @author: Rekha Description:Method is used to set data in excel
 * sheet
 */
public static void setCellData(String filePath, String sSheet, String sTestCaseID, String columnName, String value)
		throws Exception {
	int columnNumber = getColumnIndex(filePath, sSheet, columnName);
	try {
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = (Workbook) WorkbookFactory.create(fis);
		Sheet sht = wb.getSheet(sSheet);
		// logger.info("----------Sheet " + sSheet);
		int lastRowNum = sht.getLastRowNum();
		for (int i = 0; i <= lastRowNum; i++) {
			if (sht.getRow(i).getCell(0).toString().equals(sTestCaseID)) {
				Row rowNum = sht.getRow(i);
				Cell cell = rowNum.getCell(columnNumber);
				if (cell == null) {
					cell = rowNum.createCell(columnNumber);
					cell.setCellValue(value);
				} else {
					cell.setCellValue(value);
				}
				break;
			}
		}
		FileOutputStream fileOut = new FileOutputStream(filePath);
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	} catch (Exception e) {
		throw (e);
	}
}
//////Get columnindex
	
public static int getColumnIndex(String filepath, String sSheet, String colName) 
{
				String[] firstRow = TestClass.toReadExcelData(filepath, sSheet, "TEST_CASE_NO");
				int index = 0;
				for (int i = 0; i < firstRow.length; i++) 
				{
					if (firstRow[i].equalsIgnoreCase(colName))
					{
						index = i;
					}
				}
				return index;
}		 
		 public static String[] toReadExcelData(String sFilepath, String sSheet, String sTestCaseID) 
		 {
				String sData[] = null;
				try {
					FileInputStream fis = new FileInputStream(sFilepath);
					Workbook wb = (Workbook) WorkbookFactory.create(fis);
					Sheet sht = wb.getSheet(sSheet);
					int iRowNum = sht.getLastRowNum();
					for (int i = 0; i <= iRowNum; i++) {
						if (sht.getRow(i).getCell(0).toString().equals(sTestCaseID)) 
						{
							int iCellNum = sht.getRow(i).getPhysicalNumberOfCells();
							sData = new String[iCellNum];
							for (int j = 0; j < iCellNum; j++) {
								sData[j] = sht.getRow(i).getCell(j).getStringCellValue();
							}
							break;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return sData;
			}
		 public static void type(WebElement element, String value, String elementName, WebDriver driver) throws Exception 
		 {
				try {
					logger.info("---------Method type  ---------");
					waitTillPageLoad(driver, 30);
					waitForElement(element, driver, elementName); // changed  now
					System.out.println("Element is" +element);
					System.out.println(driver);
					System.out.println(value);
					element.sendKeys(value);
					logger.info("---------hide keyboard  ---------");
//					MyExtentListners.test.pass("Verify user is able to type " + "\'" + value + "\'" + "in " + "\'" + elementName
//							+ "\'" + " || User is able to type " + "\'" + value + "\'" + "in " + "\'" + elementName + "\'");
				} catch (AssertionError error) {
//					MyExtentListners.test.fail(MarkupHelper.createLabel(
//							"Verify user is able to type " + "\'" + value + "\'" + "in " + "\'" + elementName + "\'"
//									+ " || User is not able to type " + "\'" + value + "\'" + "in " + "\'" + elementName + "\'",
//							ExtentColor.RED));

//					MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
      				Assert.fail("Unable to type on " + elementName);
				} catch (Exception e) 
				{
//					MyExtentListners.test.fail(MarkupHelper.createLabel(
//							"Verify user is able to type " + "\'" + value + "\'" + "in " + "\'" + elementName + "\'"
//									+ " || User is not able to type " + "\'" + value + "\'" + "in " + "\'" + elementName + "\'",
//							ExtentColor.RED));

//					MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//					Assert.fail("Unable to type in " + elementName);
				}
		 }		
		 
// Check if element is visible or not
		 
		 public static void isEleClickable(WebElement element, WebDriver driver, String eleName) throws IOException {
				try {
					logger.info("---------Method is Element clickable  ---------");
					System.out.println(element);
					
					long timeout = 30;
					Wait<WebDriver> wait= new
							FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(100))
								  .pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);
						
					if (!(wait.until(ExpectedConditions.elementToBeClickable(element)) == null))
					{
						Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf(element)) != null);
						
						System.out.println("Eleement is Clickable");
					} 
					else 
					{
						System.out.println("Eleement is not Clickable");
					}

					// Assert.assertTrue(wait.until(ExpectedConditions.elementToBeClickable(element))
					// != null) ;

					/*
					 * WebDriverWait wait = new WebDriverWait(driver, 30000);
					 * Assert.assertTrue(wait.until(ExpectedConditions.
					 * elementToBeClickable(element)) != null);
					 */

					/*
					 * Wait<WebDriver> wait = new
					 * FluentWait<WebDriver>(driver).withTimeout(1, TimeUnit.MINUTES)
					 * .pollingEvery(250,
					 * TimeUnit.MICROSECONDS).ignoring(NoSuchElementException.class);
					 * Assert.assertTrue(wait.until(ExpectedConditions.
					 * elementToBeClickable(element)) != null);
					 */

					System.out.println(" element is clickable ");
				} catch (AssertionError e) {
//					MyExtentListners.test.fail(MarkupHelper.createLabel("Verify " + "\'" + eleName + "\'" + " is clickable || "
//							+ "\'" + eleName + "\'" + " is not clickable", ExtentColor.RED));
//
//					MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//					System.out.println(" element is not clickable ");
//					throw e;
				} catch (Exception e) {
//					MyExtentListners.test.fail(MarkupHelper.createLabel("Verify " + "\'" + eleName + "\'" + " is clickable || "
//							+ "\'" + eleName + "\'" + " is not clickable", ExtentColor.RED));
//
//					MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//					System.out.println(" element is not clickable ");
//					throw e;
				}
			}
		 
		 
		 
		 
		 
		 
// Wait for element method // Need to write
		 
		 
		 /*
			 * @author :Rekha 
			 * 
			 * Description : This method has fluent wait implementation for element to
			 * load which is polling every 250 miliseconds
			 */
			@SuppressWarnings("deprecation")
			public static void waitForElement(WebElement element, WebDriver driver, String eleName) throws IOException {
				try {
					logger.info("---------Waiting for visibility of element---------" + element);

					/*
					 * WebDriverWait wait = new WebDriverWait(driver, 60000);
					 * Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf(
					 * element)) != null); System.out.println("");
					 */
					
					// added new code
					
					Wait<WebDriver> wait= new
						FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(100))
							  .pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);
								
					//Removed
	//			  Wait<WebDriver> wait = new
	//	          FluentWait<WebDriver>(driver).withTimeout(2, TimeUnit.MINUTES)
 	//		      .pollingEvery(250,TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
					  
					Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf( element)) != null);
					  
					System.out.println(element.toString());
					waitTillPageLoad(driver, 30);
					long timeout = 60;
//					Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(timeout))
//							.pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);
//					Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf(element)) != null);
					/*
					 * if (element.toString().contains("id")) { String split[] =
					 * element.toString().split("id:"); String value =
					 * split[1].replaceAll("]", "");
					 * Assert.assertTrue(wait.until(ExpectedConditions.
					 * presenceOfElementLocated(By.id(value.trim()))) != null); }else
					 * if(element.toString().contains("name")){ String split[] =
					 * element.toString().split("name:"); String value =
					 * split[1].replaceAll("]", "");
					 * Assert.assertTrue(wait.until(ExpectedConditions.
					 * presenceOfElementLocated(By.name(value.trim()))) != null); }else
					 * if(element.toString().contains("xpath")){ String split[] =
					 * element.toString().split("xpath:"); String value =
					 * split[1].substring(0, split[1].length()-1);
					 * Assert.assertTrue(wait.until(ExpectedConditions.
					 * presenceOfElementLocated(By.xpath(value.trim()))) != null);
					 * 
					 * }
					 */

					logger.info("---------Element is visible---------" + element);
				} catch (Exception e) {

					//MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
					logger.info("---------Element is not visible---------" + element);
					throw e;
				} catch (AssertionError e) {

					//MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
					logger.info("---------Element is not visible---------" + element);
					throw e;
				}
			}

		 
		 
		 
		 
				 
		 
		 	 
////////////////// wait till page load/////////////////////////////////////////////////////////////////////////////////////////////
		 
		 public static void waitTillPageLoad(WebDriver driver, int seconds) {

				/*
				 * Predicate<WebDriver> pageLoaded = wd -> ((JavascriptExecutor)
				 * wd).executeScript("return document.readyState").equals("complete");
				 * new FluentWait<WebDriver>(driver).until(pageLoaded);
				 */

				/*
				 * new WebDriverWait(driver, seconds).until((ExpectedCondition<Boolean>)
				 * wd -> ((JavascriptExecutor) wd)
				 * .executeScript("return document.readyState").equals("complete"));
				 * WebDriverWait wait = new WebDriverWait(driver, 60);
				 * wait.until(pageLoadCondition);
				 */
				/*
				 * JavascriptExecutor js = (JavascriptExecutor) driver;
				 * js.executeAsyncScript(document.onload = function(){
				 * window.location='page.html'; };);
				 */
    //added new code 

     Wait<WebDriver> wait= new FluentWait<WebDriver>(driver)
                  .withTimeout(Duration.ofSeconds(100))
                .pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);

			 
				 //WebDriverWait wait = new WebDriverWait(driver, 2);  //removed
				JavascriptExecutor jsExec = (JavascriptExecutor) driver;

				// Wait for Javascript to load
				ExpectedCondition<Boolean> jsLoad = wd -> ((JavascriptExecutor) driver)
						.executeScript("return document.readyState").toString().equals("complete");

				// Get JS is Ready
				boolean jsReady = (Boolean) jsExec.executeScript("return document.readyState").toString().equals("complete");

				// Wait Javascript until it is Ready!
				if (!jsReady) {
					System.out.println("JS in NOT Ready!");

					// Wait for Javascript to load
					wait.until(jsLoad);

				} else {
					System.out.println("JS is Ready!");

				}
				System.out.println(" page is in ready state ");
			}
		 
		 
		public static void clickElement(WebElement element, WebDriver driver, String elementName) throws IOException 
			{

					try {
						logger.info("---------Verifying element is displayed or not ---------");
					    waitTillPageLoad(driver, 30);
					    waitForElement(element, driver, elementName);
						isEleClickable(element, driver, elementName);
						element.click();
						waitTillPageLoad(driver, 40);
//						MyExtentListners.test.pass("Verify user is able to click on " + "\'" + elementName + "\'"
//								+ " ||  User is able to click on " + "\'" + elementName + "\'");
					} catch (AssertionError error) 
					{
//						MyExtentListners.test.fail(MarkupHelper.createLabel("Verify user is able to click on " + "\'" + elementName
//								+ "\'" + "  || User is not able to click on " + "\'" + elementName + "\'", ExtentColor.RED));

//						MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
						Assert.fail("unable to Click on " + "\'" + elementName + "\'");

//						MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//						throw error;
					} catch (Exception e) 
					{
//						MyExtentListners.test.fail(MarkupHelper.createLabel("Verify user is able to click on " + "\'" + elementName
//								+ "\'" + " || User is not able to click on " + "\'" + elementName + "\'", ExtentColor.RED));
//
//						MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//						throw e;
					}							
					
		}

//					public static void isEleClickable(WebElement element, WebDriver driver, String eleName) throws IOException {
//						try {
//							//logger.info("---------Method is Element clickable  ---------");
//							System.out.println(element);
//							long timeout = 30;
//							Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(timeout))
//									.pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);
//							if (!(wait.until(ExpectedConditions.elementToBeClickable(element)) == null)) {
//								Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf(element)) != null);
//								System.out.println("Eleement is Clickable");
//							} else {
//								System.out.println("Eleement is not Clickable");
//							}
//
//							// Assert.assertTrue(wait.until(ExpectedConditions.elementToBeClickable(element))
//							// != null) ;
//
//							/*
//							 * WebDriverWait wait = new WebDriverWait(driver, 30000);
//							 * Assert.assertTrue(wait.until(ExpectedConditions.
//							 * elementToBeClickable(element)) != null);
//							 */
//
//							/*
//							 * Wait<WebDriver> wait = new
//							 * FluentWait<WebDriver>(driver).withTimeout(1, TimeUnit.MINUTES)
//							 * .pollingEvery(250,
//							 * TimeUnit.MICROSECONDS).ignoring(NoSuchElementException.class);
//							 * Assert.assertTrue(wait.until(ExpectedConditions.
//							 * elementToBeClickable(element)) != null);
//							 */
//
//							System.out.println(" element is clickable ");
//						} catch (AssertionError e) {
//							MyExtentListners.test.fail(MarkupHelper.createLabel("Verify " + "\'" + eleName + "\'" + " is clickable || "
//									+ "\'" + eleName + "\'" + " is not clickable", ExtentColor.RED));
//
//							MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//							System.out.println(" element is not clickable ");
//							throw e;
//						} catch (Exception e) {
//							MyExtentListners.test.fail(MarkupHelper.createLabel("Verify " + "\'" + eleName + "\'" + " is clickable || "
//									+ "\'" + eleName + "\'" + " is not clickable", ExtentColor.RED));
//
//							MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
//							System.out.println(" element is not clickable ");
//							throw e;
//						}
//					}	
		
		
		
		/**
		 * Mouse Hover on Element
		 *
		 */
		public static void mouseOverOnElement(WebDriver driver, WebElement element, String elementName) throws IOException {
			try {
				waitTillPageLoad(driver, 30);
				Actions act = new Actions(driver);
				act.moveToElement(element).build().perform();
//				MyExtentListners.test.pass("Verify user is able to mouse hover on " + "\'" + elementName + "\'"
//						+ " ||  User is able to mouse hover on " + "\'" + elementName + "\'");
			} catch (Exception e) {
//				MyExtentListners.test
//						.fail(MarkupHelper.createLabel(
//								"Verify user is able to mouse hover on " + "\'" + elementName + "\'"
//										+ " ||  User is not able to mouse hover on " + "\'" + elementName + "\'",
//								ExtentColor.RED));
//				MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
				Assert.fail("Unable to to mouse hover on " + elementName);
			}
		}

		/**
		 * Double click on element.
		 * 
		 * @throws IOException
		 */
		public static void doubleClickOnElement(WebDriver driver, WebElement element, String elementName)
				throws IOException {

			try {
				waitTillPageLoad(driver, 30);
				Actions act = new Actions(driver);
				act.doubleClick(element).perform();
//				MyExtentListners.test.pass("Verify user is able to double click on " + "\'" + elementName + "\'"
//						+ " ||  User is  able to double click on " + "\'" + elementName + "\'");
			} catch (Exception e) {
//				MyExtentListners.test.fail(MarkupHelper.createLabel(
//						"Verify user is able to double click on " + "\'" + elementName + "\'"
//								+ " ||  User is not able to double click on " + "\'" + elementName + "\'",
//						ExtentColor.RED));
//				MyExtentListners.test.addScreenCaptureFromPath(capture(driver, element));
				Assert.fail("Unable to to mouse hover on " + elementName);
			}

		}
}