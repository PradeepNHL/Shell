package Test;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Test.TestClass;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoginTest {
	
	//constructor 
	
//	  WebDriver driver;
//	  public LoginTest2(WebDriver driver) {
//			this.driver = driver;
//			PageFactory.initElements(driver, this);
//		}
	
	//public static void main(String[] args) throws InterruptedException
	//static String dataFilePath;
//	static public String dataFilePath = System.getProperty("user.dir");
//	
//	public WebDriver driver;
//    WebElement element;
//    String USERNAME = "USERNAME";
//	String PASSWORD = "PASSWORD";
//    
//    public LoginTest2(WebDriver driver) {
//		this.driver =  driver;
//		PageFactory.initElements(driver, this);
//	}
//    
//    @FindBy(id = "USERNAME")
//   	private WebElement eleUserNameTxtFld;
//
//   	public WebElement getEleUserNameTxtFld() {
//   		return eleUserNameTxtFld;
//   	}
//
//   	@FindBy(name = "PASSWORD")
//   	private WebElement elePasswordTxtFld;
//
//   	public WebElement getElePasswordTxtFld() {
//   		return elePasswordTxtFld;
//   	}
//
//   	@FindBy(id = "loginSubmit")  
//   	private WebElement eleLoginSubmitBtn;
//   	
//   	public WebElement getEleLoginSubmitBtn() {
//		return eleLoginSubmitBtn;
//	}
//	@BeforeClass
//    public static void openBrowser() throws Exception 
//	{
//	    System.setProperty("webdriver.chrome.driver","C:\\Iguru\\I guru\\ChromeDriver\\ChromeDriver.exe");
//        WebDriver driver = new ChromeDriver();
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        driver.manage().deleteAllCookies();
//        driver.manage().window().maximize();
//        driver.get("https://shell-test2.tririga.com");
//        
//        Thread.sleep(50000);
//		 int size = driver.findElements(By.tagName("iframe")).size();
//	     driver.switchTo().frame(0);
//	     driver.switchTo().frame("loginMain");
//        String path = System.getProperty("user.dir");
//    	System.out.println(path);	
//   }	
  @Test
	public void Test2Login() throws Exception 
	{		
	//	Before method code	 
//	  System.setProperty("webdriver.chrome.driver","C:\\Iguru\\I guru\\ChromeDriver\\ChromeDriver.exe");
//      WebDriver driver = new ChromeDriver();
//      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//      driver.manage().deleteAllCookies();
//      driver.manage().window().maximize();
//      driver.get("https://shell-test2.tririga.com");
//      
//      Thread.sleep(50000);
//		 int size = driver.findElements(By.tagName("iframe")).size();
//	     driver.switchTo().frame(0);
//	     driver.switchTo().frame("loginMain");
//      String path = System.getProperty("user.dir");
//  	System.out.println(path);
//  	System.out.println(driver.getTitle());
//	 
//	  
	  //login via xl user name and password   
//		String sDirPath = System.getProperty("user.dir");
//		String dataFilePath  = sDirPath + "/TestData/uat4_dat.xlsx";
//		System.out.println(dataFilePath);
//		//dataFilePath = GenericLib.sFSTTestDataFilePath; 
//		dataFilePath = dataFilePath.toLowerCase();
	//	ExcelDataConfig excel= new ExcelDataConfig("C:\\POI\\TestData\\TestData.xlsx");
		
		TestClass.LoginTest("C:\\Tririga\\uat4_data.xlsx","Tririga","TC_01");
		
		
	}
}