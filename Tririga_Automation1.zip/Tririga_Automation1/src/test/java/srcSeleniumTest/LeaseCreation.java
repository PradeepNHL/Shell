package srcSeleniumTest;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.sun.corba.se.impl.oa.poa.ActiveObjectMap.Key;

public class LeaseCreation {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Testworkspace\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("https://shell-test2.tririga.com/index.html");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.switchTo().frame(0);
		Thread.sleep(3000);
		driver.switchTo().frame("loginMain");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='USERNAME']")).sendKeys("Kamal");
		driver.findElement(By.xpath("//input[@id='PASSWORD']")).sendKeys("password");
		driver.findElement(By.xpath("//*[@id='loginSubmit']/input")).click();
		Thread.sleep(4000);
		driver.switchTo().defaultContent();

		driver.findElement(By.xpath("//*[@id='large-quick-link-4620']")).click();

		WebElement frm=driver.findElement(By.xpath("//iframe[@class='gwt-Frame GDNOS4QBO-']"));
		driver.switchTo().frame(frm);
		driver.switchTo().frame("objectsFrame");
		driver.findElement(By.xpath("//span[text()='Add']")).click();

		//find all windows list and switch on that
		Set<String> allWindows=driver.getWindowHandles();
		Iterator<String> it=allWindows.iterator();
		String main=it.next();
		String sub=it.next();
		System.out.println(main);
		System.out.println(sub);

		driver.switchTo().window(sub);
		driver.manage().window().maximize();

		driver.switchTo().frame("contentFrame");            
		driver.findElement(By.id("attr_seq_1163")).sendKeys("Lease 78");
		driver.findElement(By.xpath("//input[@id='attr_seq_1308']")).sendKeys("Expense Lease"); 

		Actions act = new Actions(driver);

		driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
		driver.findElement(By.xpath("//a[@id='attr_seq_2730_selector']")).click();
		Thread.sleep(5000);
		driver.switchTo().frame("unMovableLayerFrame");
		Thread.sleep(1000);
		WebElement landlordLease=driver.findElement(By.xpath("//span[text()='Landlord Lease']"));
		act.moveToElement(landlordLease);
		landlordLease.click();

		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame"); 
		Thread.sleep(2000);

		driver.findElement(By.xpath("//a[@id='attr_seq_2052_selector']")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("unMovableLayerFrame");
		Thread.sleep(1000);
		WebElement active=driver.findElement(By.xpath("//span[text()='Active']"));
		act.moveToElement(active);
		active.click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");

		driver.findElement(By.xpath("//input[@id='attr_seq_1182']")).sendKeys("06/15/2019");
		driver.findElement(By.xpath("//input[@name='attr_seq_1172']")).sendKeys("06/01/2025");
		Thread.sleep(2000);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(4000);
		WebElement BusinessUnitID=driver.findElement(By.xpath("//input[@name='attr_seq_2663']"));
		BusinessUnitID.sendKeys("DE01");

		Actions act1=new Actions(driver);
		Thread.sleep(4000);
		act1.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(4000);
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Contact Details']")).click();
		Thread.sleep(2000);

		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("innerFrame87");

		driver.findElement(By.xpath("//a[text()='Data Central Hub - Validate']")).click(); 

		String contactsWindow = driver.getWindowHandle();
		Set<String> winHandleBefore = driver.getWindowHandles();
		// Perform the click operation that opens new window
		// Switch to new window opened
		
		for(String winHandle : winHandleBefore){
		   driver.switchTo().window(winHandle);
		}	
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		Thread.sleep(5000);
		driver.findElement(By.id("Find_3")).click();
		Thread.sleep(5000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
		Thread.sleep(5000);
		driver.findElement(By.id("xBtn")).click();
		System.out.println("User Selected for Data Central Validate"); 
		//--------------------------------------
		driver.switchTo().window(contactsWindow);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("innerFrame87");

		driver.findElement(By.xpath("//a[text()='Portfolio Administrator']")).click();

		Set<String> winHandleBefore1 = driver.getWindowHandles();
		for(String winHandle1 : winHandleBefore1){
			   driver.switchTo().window(winHandle1);
			}	

		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		Thread.sleep(5000);
		driver.findElement(By.id("Find_3")).click();
		Thread.sleep(5000);

		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
		Thread.sleep(5000);
		driver.findElement(By.id("xBtn")).click();
		System.out.println("User Selected for Portfolio Administrator"); 
		//--------------------------------------
		driver.switchTo().window(contactsWindow);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("innerFrame87");

		driver.findElement(By.xpath("//a[text()='Portfolio Administrator - Validate']")).click();
		System.out.println("Clicked on Portfolio Administrator  - Validate");
		
		Set<String> winHandleBefore2 = driver.getWindowHandles();
		for(String winHandle2 : winHandleBefore2){
			   driver.switchTo().window(winHandle2);
			}	

		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		Thread.sleep(5000);
		driver.findElement(By.id("Find_3")).click();
		Thread.sleep(5000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("xBtn")).click();
		System.out.println("User Selected for Portfolio Administrator  - Validate"); 
		//--------------------------------------
		driver.switchTo().window(contactsWindow);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("innerFrame87");

		driver.findElement(By.xpath("//a[text()='Property Manager']")).click();
		System.out.println("Clicked on Property Manager");
		
		Set<String> winHandleBefore3 = driver.getWindowHandles();
		for(String winHandle3 : winHandleBefore3){
			   driver.switchTo().window(winHandle3);
			}	

		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		Thread.sleep(5000);
		driver.findElement(By.id("Find_3")).click();
		Thread.sleep(5000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("xBtn")).click();
		System.out.println("Property Manager Selected"); 
		//--------------------------------------
		
		driver.switchTo().window(contactsWindow);
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");		
		driver.findElement(By.id("attr_seq_1916_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
		System.out.println("Tenant Organization Selected");
		//--------------------------------------
		//JavascriptExecutor jse=(JavascriptExecutor)driver;  // scroll down after selection of Tenant
		jse.executeScript("window.scrollBy(0, 500)", "");
		Thread.sleep(4000);
		//-------------------------------------
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1934_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@aria-label='row 6' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();;
		System.out.println("Landlord Organization Lookup Selected");
		//--------------------------------------
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1987_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@aria-label='row 6' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		System.out.println("Remit To Lookup Selected");
		//--------------------------------------
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Create Draft']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Locations']")).click();
		
		//Scroll down ----------------
		JavascriptExecutor scrollDownForAfterRemit=(JavascriptExecutor)driver;
		scrollDownForAfterRemit.executeScript("window.scrollBy(0, 450)", "");
		
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Find')]")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		System.out.println("Primary Location Selected");
	
		driver.switchTo().defaultContent();
	    driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Add')]")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		System.out.println("Premise Location Selected");
		
		//=======click save button on location page
		
		driver.findElement(By.xpath("//div[@id='Save' and @class='brandable-button-center']")).click();
		
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Payments']")).click();
		
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//span[@class='actionButtonText' and contains(text(),'Generate Payment Schedules')]")).click();
		Thread.sleep(3000);
		
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1086_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("unMovableLayerFrame");
		Thread.sleep(1000);
		WebElement paymentType=driver.findElement(By.xpath("//span[text()='Association [PAY][NI]']"));
		act.moveToElement(paymentType);
		paymentType.click();
		System.out.println("Payment Type Selected");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1166_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("unMovableLayerFrame");
		Thread.sleep(1000);
		WebElement invoiceType=driver.findElement(By.xpath("//span[@class='bodyText' and contains(text(),'NOPRINT')]"));
		act.moveToElement(invoiceType);
		invoiceType.click();
		System.out.println("Invoice Type Selected");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1126_selector")).click();
		Thread.sleep(3000);
		driver.switchTo().frame("unMovableLayerFrame");
		Thread.sleep(1000);
		WebElement frequency=driver.findElement(By.xpath("//span[text()='Monthly']"));
		act.moveToElement(frequency);
		frequency.click();
		System.out.println("Frequency Selected");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1134_selector")).click();
		
		driver.switchTo().frame("unMovableLayerFrame");
		WebElement paymentDueOn=driver.findElement(By.xpath("//span[contains(text(),'First Day of Period')]"));
		act.moveToElement(paymentDueOn);
		paymentDueOn.click();
		System.out.println("Payment Due Selected");
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1133_selector")).click();
		
		driver.switchTo().frame("nonScrollableLayerForDatePickerFrame");
		driver.findElement(By.xpath("//td[contains(@class,'dijitCalendarCurrentDate ')]/span")).click();
		System.out.println("Full Payment Start Date Selected");
	
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.id("attr_seq_1105")).clear();
		driver.findElement(By.id("attr_seq_1105")).sendKeys("12");
		System.out.println("Number of Schedule Entered");
		
		driver.findElement(By.id("attr_seq_1100")).clear();
		driver.findElement(By.id("attr_seq_1100")).sendKeys("500");
		System.out.println("Payment schedules for 12 months");
		
		System.out.println("Finding Cost");
		driver.findElement(By.xpath("//span[@class='actionButtonText'  and contains(text(),'Find')]")).click();
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("frameMain");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@type='radio' and @name='sNo']")).click();
		driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		System.out.println("cost code Selected");
		

		System.out.println("Adding Tax Group");
		//JavascriptExecutor jse1=(JavascriptExecutor)driver;
		//jse1.executeScript("window.scrollBy(0, 500)", "");
		//Thread.sleep(4000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@name='attr_seq_1150']")).sendKeys("FULL");

		Actions act2=new Actions(driver);
		Thread.sleep(4000);
		act2.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(4000);		
		
		System.out.println("Generating payment Schedule");
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		
		driver.findElement(By.xpath("//div[@id='Generate Schedule(s)_11']")).click();
		Thread.sleep(4000);	
		//driver.findElement(By.xpath("//table[@id='actionsTable']//span[@class='actionButtonText' and text()='OK']")).click();
		System.out.println("Clicked Generated payment Schedule");
		
		
		System.out.println("Payment Instruction");
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("innerFrame7");
		driver.findElement(By.xpath("//a[@title='YC00']")).click();
		
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//input[@name='attr_seq_1256']")).sendKeys("E");
		Actions act3=new Actions(driver);
		Thread.sleep(4000);
		act3.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(4000);	
		
		System.out.println("Payment Instructions");
		/*
		//String PaymentsInstruction = driver.getWindowHandle();
		Set<String> PaymentsInstruction = driver.getWindowHandles();
		for(String winHandle1 : PaymentsInstruction){
			   driver.switchTo().window(winHandle1);
			}	
			*/
		//find all windows list and switch on that
		Set<String> allWindows1=driver.getWindowHandles();
		Iterator<String> it1=allWindows.iterator();
		String main1=it.next();
		String sub1=it.next();
		String sub2=it.next();
		System.out.println(main1);
		System.out.println(sub1);
		System.out.println(sub2);
		driver.switchTo().window(sub2);		
		driver.manage().window().maximize();
		
		driver.switchTo().frame("contentFrame");
		driver.findElement(By.xpath("//div[@id='Save_&_Close']")).click();
		Thread.sleep(4000);	
		
		driver.switchTo().frame("contentFrame");
		driver.switchTo().frame("childFrame");
		driver.findElement(By.xpath("//div[@id='Create_Schedule(s)']")).click();
		Thread.sleep(2000);	
	}

}
